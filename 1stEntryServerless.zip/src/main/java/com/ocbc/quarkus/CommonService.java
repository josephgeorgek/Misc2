package com.ocbc.quarkus;



import jakarta.enterprise.context.ApplicationScoped;
import org.eclipse.microprofile.rest.client.inject.RestClient;
import jakarta.inject.Inject;


@ApplicationScoped
public class CommonService {

@Inject
@RestClient
 ProcessRequestService processRequestService;

    public String callProcessRequest(String account, String amount) {
        String requestData = "{" +
                "\"account\": \"" + account + "\"," +
                "\"amount\": \"" + amount + "\"" +
                "}";
        return processRequestService.processRequest(requestData);
    }
}