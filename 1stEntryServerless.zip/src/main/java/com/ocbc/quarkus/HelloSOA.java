package com.ocbc.quarkus;

import org.eclipse.microprofile.rest.client.inject.RestClient;


import jakarta.inject.Inject;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Path("/soa")
public class HelloSOA {


     @Inject
     CommonService commonService;

    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String hello() {
        String account = "";
        String amount = "";
        return  commonService.callProcessRequest( account,  amount);
      //  return "Hello from RESTEasy Reactive";
    }
}
