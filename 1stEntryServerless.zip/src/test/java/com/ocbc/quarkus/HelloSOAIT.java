package com.ocbc.quarkus;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
class HelloSOAIT extends HelloSOATest {
    // Execute the same tests but in packaged mode.
}
