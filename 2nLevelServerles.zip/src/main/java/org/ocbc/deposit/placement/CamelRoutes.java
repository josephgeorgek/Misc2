package org.ocbc.deposit.placement;

import java.nio.file.Files;
import java.nio.file.Paths;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.apache.camel.builder.RouteBuilder;

@ApplicationScoped
public class CamelRoutes extends RouteBuilder {

    @Inject
    FixedLengthProcessor fixedLengthProcessor;

    @Override
    public void configure() {
        from("direct:start")
                .process(exchange -> {
                    String body = exchange.getIn().getBody(String.class);
                    String path = exchange.getIn().getHeader("filePath", String.class);
                    String filePath = exchange.getIn().getHeader("filePath", String.class);
                    if (filePath != null) {
                        String content = new String(Files.readAllBytes(Paths.get(filePath)));
                        exchange.getIn().setBody(content);
                    }
                    ;
                })
                .log("1 Received request to process file: ${header.filePath}")
                .log("2 File content: ${body}")
                .to("direct:paymentProcessor");

        from("direct:paymentProcessor")
                .split().tokenize("\n").parallelProcessing()
                .aggregationStrategy(new ListAggregationStrategy()) // Use the custom aggregation strategy
                .log("Processing record ${headers.CamelSplitIndex} with file: ${header.filePath}: ${body}")
                .process(fixedLengthProcessor)
                .end() // End the split here

                .log("Aggregated results: ${body}");
    }

}
