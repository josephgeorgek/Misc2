package org.ocbc.deposit.placement;

import java.util.HashMap;
import java.util.Map;

import jakarta.enterprise.context.ApplicationScoped;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.jboss.logging.Logger;

@ApplicationScoped
public class FixedLengthProcessor implements Processor {

    private static final Logger LOG = Logger.getLogger(FixedLengthProcessor.class);

    @Override
    public void process(Exchange exchange) throws Exception {
        String body = exchange.getIn().getBody(String.class);
        LOG.debugf("body" + body);

        // Assuming the fixed-length fields are as follows:
        // Account: 0-20, Currency: 20-23, Amount: 23-38
        String account = body.substring(0, 20).trim();
        String currency = body.substring(20, 23).trim();
        String amount = body.substring(23, 38).trim();

        // Example processing: Creating a Map from the extracted fields
        Map<String, String> dataMap = new HashMap<>();
        dataMap.put("account", account);
        dataMap.put("currency", currency);
        dataMap.put("amount", amount);

        // Logging extracted data for demonstration purposes
        System.out.println("Processed data: " + dataMap);

        // Setting the processed data back to the message body
        // You might want to transform it into JSON, XML, or any other format depending on your use case
        exchange.getIn().setBody(dataMap);
    }
}
