package org.ocbc.deposit.placement;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.quarkus.funqy.Funq;

public class FixedLengthUtil {

    @Funq
    public String processFixedLengthString(String fixedLengthString) {
        // Implement the conversion logic here
        Map<String, Object> jsonMap = convertFixedLengthToJson(fixedLengthString);

        // Convert the map to JSON string
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            return objectMapper.writeValueAsString(jsonMap);
        } catch (Exception e) {
            // Handle exception
            return "{}";
        }
    }

    private Map<String, Object> convertFixedLengthToJson(String fixedLengthString) {
        // Mock conversion logic - replace with actual implementation
        Map<String, Object> map = new HashMap<>();
        map.put("account", fixedLengthString.substring(0, 20).trim());
        map.put("currency", fixedLengthString.substring(20, 23).trim());
        map.put("amount", fixedLengthString.substring(23, 38).trim());
        return map;
    }
}
