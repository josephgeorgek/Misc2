package org.ocbc.deposit.placement;

import io.quarkus.funqy.Funq;
import jakarta.inject.Inject;
import org.apache.camel.ProducerTemplate;
import org.jboss.logging.Logger;

public class MainController {

    private static final Logger LOG = Logger.getLogger(MainController.class);

    @Inject
    ProducerTemplate producerTemplate;

    @Inject
    FixedLengthUtil fixedLengthUtil;

    @Funq("processRequest")
    public String handlePostRequest(PaymentRequest request) {
        LOG.errorf("Received request body: %s", request);
        // Send requestBody to a Camel direct:start endpoint and get the response
        //  String camelResponse = producerTemplate.requestBody("direct:start", request, String.class);
        String filePath = "/Users/josephgeorge/dev/rnd/serverless/file/payment/fixed_length_data.csv";
        String camelResponse = producerTemplate.requestBodyAndHeader("direct:start", null, "filePath", filePath, String.class);
        //   producerTemplate.sendBodyAndHeader("direct:start", null, "filePath", filePath);
        LOG.errorf("Received camelResponse body: %s", camelResponse);
        // Now, pass the response from Camel to the FixedLengthUtil for further processing
        return camelResponse;//fixedLengthUtil.processFixedLengthString(camelResponse);
    }
}
