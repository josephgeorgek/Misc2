package org.ocbc.deposit.placement;

public class PaymentRequest {
    private String account;
    private String amount;

    // Getters and setters
    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }
}
