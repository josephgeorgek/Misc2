package org.ocbc.file.xml;

import java.time.Duration;
import java.time.Instant;

import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import org.apache.camel.ProducerTemplate;
import org.junit.jupiter.api.Test;

@QuarkusTest
public class CamelRouteTest {

    @Inject
    ProducerTemplate producerTemplate;

    @Test
    public void testSimpleCamelRoute() {
        // Assuming the route returns a modified version of the input message
        String expectedResponse = "Modified Test Message";

        String filePath = "/Users/josephgeorge/dev/rnd/serverless/file/payment/fixed_length_data.csv";
        String camelResponse = producerTemplate.requestBodyAndHeader("direct:start", null, "filePath", filePath, String.class);

        // Send "Test Message" to the "direct:start" endpoint and expect a response
        // Object response = producerTemplate.to("direct:start").withBody("Test Message").request();

        // Verify the response is as expected
        //  Assertions.assertEquals(expectedResponse, response);
    }

    @Test
    public void testPerformance() {
        String filePath = "/Users/josephgeorge/dev/rnd/serverless/file/payment/fixed_length_data.csv";

        // Measure start time
        Instant start = Instant.now();

        int numberOfRequests = 100; // Customize the number of requests for your test
        for (int i = 0; i < numberOfRequests; i++) {
            producerTemplate.requestBodyAndHeader("direct:start", null, "filePath", filePath, String.class);
        }

        // Measure end time
        Instant end = Instant.now();

        // Calculate duration
        Duration duration = Duration.between(start, end);
        System.out.println("Processed " + numberOfRequests + " requests in: " + duration.toMillis() + " milliseconds");
    }
}
