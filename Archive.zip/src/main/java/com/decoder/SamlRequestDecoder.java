package com.decoder;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.zip.InflaterInputStream;

public class SamlRequestDecoder {
    public static void main(String[] args) throws Exception {
    	
    	
    	dsdds
    	
    	String samlResponse = "PHNhbWxwOlJlc3BvbnNlIHhtbG5zOnNhbWxwPSJ1cm46b2FzaXM6bmFtZXM6dGM6U0FNTDoyLjA6cHJvdG9jb2wiIERlc3RpbmF0aW9uPSJodHRwOi8vd3d3LnczLm9yZy8yMDA1LzA1L3htbGRzaWcjIiBEZXN0aW5hdGlvbj0iaHR0cDovL3d3dy53My5vcmcvMjAwMS9YTUxTZXJ2aWNlIj4KICA8c2FtbHA6SXNzdWVyPjxzYW1sOkFzZ291bnQgcmVmZXJlbmNlPSJHZXRUZW1wbGF0ZSIgLz4KICAgIDxwcm90b2NvbDpBc3NlcnRpb24gcmVzcG9uc2U9IkRlc2lnbmVkIj4KICAgICAgPHByb3RvY29sOkFzZWN1cml0eSBkYXRhLXRhZz0iZXh0ZXJuYWxWZXJzaW9uIi8+CiAgICA8L3NhbWxwOklzc3Vlcj4KICA8L3NhbWxwOlJlc3BvbnNlPg==";

        byte[] decodedBytes = Base64.getDecoder().decode(samlResponse);
        String samlResponseDecoded = new String(decodedBytes, StandardCharsets.UTF_8);

        System.out.println("Decoded SAML Response:");
        System.out.println(samlResponseDecoded);
        
        
        
        String samlRequest = "PHNhbWxwOkFkZHJlc3MgeG1sbnM6c2FtbD0idXJuOm9hc2lzOm5hbWVzOnRjOlNBTUw6Mi4wOmFjOmVtYWlsQWRkcmVzcyIgRGVzdGluYXRpb249Imh0dHA6Ly93d3cudzMub3JnLzIwMDEvMDUveG1sZHNpZyNkYXRhLXJlZmVyZW5jZSI+CiAgPHNhbWxwOkFzY3JpYmVyIHhtbG5zOnNhbWxwPSJ1cm46b2FzaXM6bmFtZXM6dGM6U0FNTDoyLjA6YWM6YXNjcmlwdDphY2NlcHRhYmxlIj4KICAgIDxzYW1sOkFzY3JpYmVyQXNzZXJ0aW9uIHhtbG5zOnNhbWxwPSJ1cm46b2FzaXM6bmFtZXM6dGM6U0FNTDoyLjA6YWM6YXNjcmlwdDphY2NlcHRhYmxlIi8+CiAgPC9zYW1scDpBZGRyZXNzPg==";

        decodedBytes = Base64.getDecoder().decode(samlRequest);
        String samlRequestDecoded = new String(decodedBytes, StandardCharsets.UTF_8);

        System.out.println("Decoded SAML Request:");
        System.out.println(samlRequestDecoded);
        
        
        System.exit(0);
   //     String samlResponse = "MEuNbewawaltteaRue...";
        
     //   String samlResponse = "PHNhbWxwOlJlc3BvbnNlIHhtbG5zOnNhbWxwPSJ1cm46b2FzaXM6bmFtZXM6dGM6U0FNTDoyLjA6cHJvdG9jb2wiIERlc3RpbmF0aW9uPSJodHRwOi8vd3d3LnczLm9yZy8yMDA1LzA1L3htbGRzaWcjIiBEZXN0aW5hdGlvbj0iaHR0cDovL3d3dy53My5vcmcvMjAwMS9YTUxTZXJ2aWNlIj4KICA8c2FtbHA6SXNzdWVyPgpTZXJ2aWNlczogCiAgICA8c2FtbHA6SXNzdWVyPjxzYW1sOkFzZ291bnQgcmVmZXJlbmNlPSJHZXRUZW1wbGF0ZSIgLz4KICAgIDxwcm90b2NvbDpBc3NlcnRpb24gcmVzcG9uc2U9IkRlc2lnbmVkIj4KICAgICAgPHByb3RvY29sOkFzZWN1cml0eSBkYXRhLXRhZz0iZXh0ZXJuYWxWZXJzaW9uIi8+CiAgICA8L3NhbWxwOklzc3Vlcj4KICA8L3NhbWxwOlJlc3BvbnNlPg==";

        
        // Decode the Base64-encoded SAML response
        byte[] base64DecodedResponse = Base64.getDecoder().decode(samlResponse);
        
        // Decompress the response using Inflater
        InputStream is = new InflaterInputStream(new ByteArrayInputStream(base64DecodedResponse));
        
        // Read the response as a string
        StringBuilder sb = new StringBuilder();
        byte[] buffer = new byte[1024];
        int bytesRead;
        while ((bytesRead = is.read(buffer)) != -1) {
            sb.append(new String(buffer, 0, bytesRead, StandardCharsets.UTF_8));
        }
        
        // Print the decoded SAML response
        System.out.println("SAML Response: " + sb.toString());
    }
}
