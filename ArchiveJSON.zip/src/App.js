// src/App.js
import React from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';

import Registration from './views/Registration';
import CaseListing from './views/CaseListing';
import CaseDetails from './views/CaseDetails';


const App = () => {
  return (
    <Router>
      <div>
        <nav>
          <ul>
            <li>
              <Link to="/registration">Registration</Link>
            </li>
            <li>
              <Link to="/case-listing">Case Listing</Link>
            </li>
            <li>
              <Link to="/case-details">Case Details</Link>
            </li>
          </ul>
        </nav>
        
        <Routes>
          <Route path="/registration" element={<Registration />} />
          <Route path="/case-listing" element={<CaseListing />} />
          <Route path="/case-details" element={<CaseDetails />} />
          <Route path="/" element={<Registration />} /> {/* Default route */}
        </Routes>
      </div>
    </Router>
  );
};

export default App;
