// src/mockdata/caseData.js
const caseData = [
    {
      caseId: "C123",
      caseTitle: "Issue with Login",
      assignee: "John Doe",
      status: "Open",
      createdDate: "2023-09-01",
      dueDate: "2023-09-05",
      priority: "High"
    },
    {
      caseId: "C124",
      caseTitle: "Payment Failure",
      assignee: "Jane Doe",
      status: "In Progress",
      createdDate: "2023-09-02",
      dueDate: "2023-09-07",
      priority: "Medium"
    }
    // Add more cases as needed
  ];
  
  export default caseData;
  