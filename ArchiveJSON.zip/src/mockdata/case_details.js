
  // src/mockdata/caseData.js
const caseData = [
  {
    "caseId": "C123",
    "caseTitle": "System Failure on Login",
    "assignee": "John Doe",
    "status": "Review",
    "assessment": "False Positive",
    "staffInvolved": "Jane Doe, Mark Smith",
    "anomalySummary": "A login failure occurred due to an unexpected system crash. The issue was isolated to a misconfiguration in the authentication server.",
    "caseFile": "system_failure_report.pdf",
    "reassignNomination": "John Smith"
  }

];
  
export default caseData;
