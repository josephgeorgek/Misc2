// src/components/CaseListing.js
import React from 'react';
import DynamicForm from '../components/CaseDetails';
import caseMgmtSchema from '../schemas/caseDetailsSchema.json'; // Assuming this contains the case listing schema

const CaseDetails = () => {
  return (
    <div>
      <h1>Case Listing Page</h1>
      <DynamicForm jsonSchema={caseMgmtSchema} />
    </div>
  );
};

export default CaseDetails;
