// src/components/CaseListing.js
import React from 'react';
import DynamicForm from '../components/DynamicListing';
import caseMgmtSchema from '../schemas/caselistingSchema'; // Assuming this contains the case listing schema

const CaseListing = () => {
  return (
    <div>
      <h1>Case Listing Page</h1>
      <DynamicForm jsonSchema={caseMgmtSchema} />
    </div>
  );
};

export default CaseListing;
