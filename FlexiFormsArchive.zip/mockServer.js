const express = require('express');
const cors = require('cors');
const app = express();
const port = 3001;

app.use(cors()); // Enable CORS

// Mock data for Reassign Nomination
const mockReassignUsers = [
  { id: 1, name: 'John Tan' },
  { id: 2, name: 'Jane Joseph' },
  { id: 3, name: 'Alice Wong' },
  { id: 4, name: 'Michael Lim' },
  { id: 5, name: 'Emily Chen' },
  { id: 6, name: 'David Lee' },
  { id: 7, name: 'Sophia Ng' },
  { id: 8, name: 'Chris Tan' }
];

// Existing mock tasks data
const mockTasks = [
  {
    "caseId": "C123",
    "priority": "High",
    "channelApplication": "GCM",
    "domain": "SAAM",
    "function": "Assessment",
    "creationDate": "2023-09-15T10:30:00",
    "dueDate": "2023-09-20T12:00:00",
    "assignedTo": "John Tan",
    "status": "Open",
    "ageing": 5,
    "requestType": "System Issue",
    "productServices": "Login Service",
    "process": "Authentication",
    "cif": "CIF12345",
    "customerName": "Jane Joseph",
    "reassignNomination": "John Tan"
  },
  {
    "caseId": "C124",
    "priority": "High",
    "channelApplication": "GCM",
    "domain": "SAAM",
    "function": "Assessment",
    "creationDate": "2023-09-15T10:30:00",
    "dueDate": "2023-09-20T12:00:00",
    "assignedTo": "John Tan",
    "status": "Open",
    "ageing": 5,
    "requestType": "System Issue",
    "productServices": "Login Service",
    "process": "Authentication",
    "cif": "CIF12345",
    "customerName": "Jane Joseph",
    "reassignNomination": "John Tan"
  },
  {
    "caseId": "C125",
    "priority": "Medium",
    "channelApplication": "Mobile App",
    "domain": "Payments",
    "function": "Fraud Detection",
    "creationDate": "2023-09-16T09:15:00",
    "dueDate": "2023-09-22T11:00:00",
    "assignedTo": "Michael Lim",
    "status": "In Progress",
    "ageing": 3,
    "requestType": "Payment Failure",
    "productServices": "Payment Gateway",
    "process": "Transaction Processing",
    "cif": "CIF54321",
    "customerName": "Alice Wong",
    "reassignNomination": "David Lee"
  },
  {
    "caseId": "C126",
    "priority": "Low",
    "channelApplication": "Web Portal",
    "domain": "Accounts",
    "function": "Account Opening",
    "creationDate": "2023-09-17T14:00:00",
    "dueDate": "2023-09-25T13:00:00",
    "assignedTo": "Emily Chen",
    "status": "Pending",
    "ageing": 1,
    "requestType": "Account Creation",
    "productServices": "Account Services",
    "process": "Customer Verification",
    "cif": "CIF67890",
    "customerName": "Chris Tan",
    "reassignNomination": "Sophia Ng"
  },
  {
    "caseId": "C127",
    "priority": "High",
    "channelApplication": "GCM",
    "domain": "SAAM",
    "function": "Assessment",
    "creationDate": "2023-09-18T08:45:00",
    "dueDate": "2023-09-23T16:00:00",
    "assignedTo": "John Tan",
    "status": "Closed",
    "ageing": 4,
    "requestType": "Security Breach",
    "productServices": "Authentication Service",
    "process": "Security Monitoring",
    "cif": "CIF32165",
    "customerName": "Sophia Ng",
    "reassignNomination": "David Lee"
  },
  {
    "caseId": "C128",
    "priority": "Medium",
    "channelApplication": "Mobile App",
    "domain": "Payments",
    "function": "Fraud Detection",
    "creationDate": "2023-09-19T10:20:00",
    "dueDate": "2023-09-24T15:00:00",
    "assignedTo": "Michael Lim",
    "status": "Open",
    "ageing": 2,
    "requestType": "Suspicious Activity",
    "productServices": "Fraud Detection",
    "process": "Transaction Monitoring",
    "cif": "CIF56789",
    "customerName": "Emily Chen",
    "reassignNomination": "Alice Wong"
  }
];

// Endpoint to handle Reassign Nomination users
app.get('/v1/staff-security/user-groups/:groupId/users', (req, res) => {
  const groupId = req.params.groupId; // Simulate the group ID
  console.log(`Mock API hit for user group ${groupId}, responding with mock users.`);
  res.json(mockReassignUsers); // Return mock users
});

// Existing endpoint: Get all tasks (mock data)
app.get('/v1/common-forms/tasks/inquiry/user-id', (req, res) => {
  console.log("Mock API hit for all tasks by user-id, responding with mock task data.");
  res.json(mockTasks); // Send all mock tasks
});

// Existing endpoint: Get task by caseId
app.get('/v1/common-forms/tasks/inquiry/:id', (req, res) => {
  const taskId = req.params.id;
  const task = mockTasks.find(t => t.caseId === taskId); // Find the task with matching caseId
  if (task) {
    console.log(`Mock API hit for task with ID ${taskId}, responding with specific task data.`);
    res.json(task); // Send the specific task data
  } else {
    res.status(404).send('Task not found');
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Mock server running on http://localhost:${port}`);
});
