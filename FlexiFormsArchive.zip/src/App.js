// src/App.js
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import TaskListing from './views/Listing';
import TaskDetails from './views/Details';
import TaskRegistration from './views/Create';

function App() {
  return (
    <Router>
      <div>
        <nav>
          <ul>
            <li>
              <Link to="/task-listing">Task Listing</Link>
            </li>
            <li>
              <Link to="/task-registration">Task Registration</Link>
            </li>
          </ul>
        </nav>

        <Routes>
          <Route path="/task-listing" element={<TaskListing />} />
          <Route path="/task-details/:id" element={<TaskDetails />} /> {/* Accept caseId in URL */}
          <Route path="/task-registration" element={<TaskRegistration />} />
          <Route path="/" element={<TaskListing />} /> {/* Default Route */}
        </Routes>
      </div>
    </Router>
  );
}

export default App;
