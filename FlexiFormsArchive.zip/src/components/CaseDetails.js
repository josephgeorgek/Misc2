// src/components/DynamicForm.js
import React, { useState, useEffect } from 'react';
import { TextField, Select, MenuItem, Button, RadioGroup, FormControlLabel, Radio, TextareaAutosize, InputLabel, FormControl } from '@mui/material';
import caseData from '../mockdata/caseData'; // Import mock data from caseData.js
import caseDetailsSchema from '../schemas/caseDetailsSchema.json'; // Import schema
import axios from 'axios'; // Import axios for API calls

const DynamicForm = () => {
  const [formData, setFormData] = useState(caseData[0]); // Use caseData from mockdata
  const [nominationOptions, setNominationOptions] = useState([]); // Store reassign nomination options

  // Fetch reassign nomination options from the API
  useEffect(() => {
    const fetchNominationOptions = async () => {
      const reassignNominationField = caseDetailsSchema.fields.find(f => f.field === 'reassignNomination');
      if (reassignNominationField.api) {
        try {
          const response = await axios.get(reassignNominationField.api); // Use the API endpoint from the schema
          setNominationOptions(response.data); // Assume response contains the list of users
        } catch (error) {
          console.error("Error fetching reassign nomination options:", error);
        }
      }
    };

    fetchNominationOptions();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleFileChange = (e) => {
    setFormData({
      ...formData,
      caseFile: e.target.files[0] // Handle file change
    });
  };

  const handleReassign = async () => {
    try {
      const apiEndpoint = caseDetailsSchema.fields.find(f => f.field === 'reassignButton').submitApi;
      const response = await axios.post(apiEndpoint, formData); // Submit form data via POST request
      console.log("Form data submitted:", response.data);
    } catch (error) {
      console.error("Error submitting form data:", error);
    }
  };

  return (
    <form style={{ padding: '20px', maxWidth: '600px', margin: 'auto' }}>
      <TextField
        fullWidth
        variant="outlined"
        label="Case ID"
        name="caseId"
        value={formData.caseId}
        disabled
        style={{ marginBottom: '1rem' }}
      />
      
      <TextField
        fullWidth
        variant="outlined"
        label="Case Title"
        name="caseTitle"
        value={formData.caseTitle}
        disabled
        style={{ marginBottom: '1rem' }}
      />
      
      <TextField
        fullWidth
        variant="outlined"
        label="Assignee"
        name="assignee"
        value={formData.assignee}
        disabled
        style={{ marginBottom: '1rem' }}
      />

      <FormControl fullWidth style={{ marginBottom: '1rem' }}>
        <InputLabel>Status</InputLabel>
        <Select
          name="status"
          value={formData.status}
          onChange={handleChange}
        >
          <MenuItem value="Review">Review</MenuItem>
          <MenuItem value="Assessment Done">Assessment Done</MenuItem>
        </Select>
      </FormControl>

      <RadioGroup
        name="assessment"
        value={formData.assessment}
        onChange={handleChange}
        style={{ marginBottom: '1rem' }}
      >
        <FormControlLabel value="False Positive" control={<Radio />} label="False Positive" />
        <FormControlLabel value="True Positive" control={<Radio />} label="True Positive" />
      </RadioGroup>

      <TextField
        fullWidth
        variant="outlined"
        label="Staff Involved"
        name="staffInvolved"
        value={formData.staffInvolved}
        onChange={handleChange}
        style={{ marginBottom: '1rem' }}
      />

      <FormControl fullWidth style={{ marginBottom: '1rem' }}>
        <label>Anomaly Details Summary</label>
        <TextareaAutosize
          minRows={4}
          name="anomalySummary"
          value={formData.anomalySummary}
          onChange={handleChange}
          style={{ width: '100%', padding: '10px' }}
        />
      </FormControl>

      <FormControl fullWidth style={{ marginBottom: '1rem' }}>
        <label>Case File</label>
        <input
          type="file"
          onChange={handleFileChange}
          style={{ marginTop: '0.5rem' }}
        />
      </FormControl>

      <FormControl fullWidth style={{ marginBottom: '1rem' }}>
        <InputLabel>Reassign Nomination</InputLabel>
        <Select
          name="reassignNomination"
          value={formData.reassignNomination}
          onChange={handleChange}
        >
          {nominationOptions.length > 0 ? (
            nominationOptions.map((option) => (
              <MenuItem key={option.id} value={option.name}>
                {option.name}
              </MenuItem>
            ))
          ) : (
            <MenuItem value={formData.reassignNomination}>
              {formData.reassignNomination}
            </MenuItem>
          )}
        </Select>
      </FormControl>

      <Button
        variant="contained"
        color="primary"
        onClick={handleReassign}
        style={{ marginBottom: '1rem' }}
      >
        Reassign
      </Button>
    </form>
  );
};

export default DynamicForm;
