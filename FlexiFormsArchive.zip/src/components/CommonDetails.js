// src/components/CommonDetails.js
import React, { useState, useEffect } from 'react';
import { TextField, Select, MenuItem, Button, Box, Grid, FormControl, InputLabel, Typography } from '@mui/material';
import axios from 'axios';
import detailsSchema from '../schemas/detailsSchema.json';
import '../App.css';  // Import the App.css file

const CommonDetails = ({ caseId }) => {
  const [formData, setFormData] = useState({});
  const [reassignOptions, setReassignOptions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Fetch task details
  const fetchTaskDetails = async () => {
    try {
      if (caseId) {
        const response = await axios.get(`http://localhost:3001/v1/common-forms/tasks/inquiry/${caseId}`);
        setFormData(response.data);
      }
    } catch (err) {
      console.error('Error fetching task details:', err);
      setError('Failed to load task details.');
    }
  };

  // Fetch Reassign Nomination options
  const fetchReassignOptions = async () => {
    try {
      const groupId = 'group-id'; // Replace with actual group ID
      const response = await axios.get(`http://localhost:3001/v1/staff-security/user-groups/${groupId}/users`);
      setReassignOptions(response.data);
    } catch (err) {
      console.error('Error fetching reassign options:', err);
      setError('Failed to load Reassign Nomination options.');
    }
  };

  useEffect(() => {
    fetchTaskDetails();
    if (detailsSchema.sections.some(section => section.fields.some(field => field.field === 'reassignNomination'))) {
      fetchReassignOptions();
    }
  }, [caseId]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleSubmit = async (actionType) => {
    setLoading(true);
    try {
      const apiEndpoint = detailsSchema.sections
        .find(section => section.fields.some(field => field.field === `${actionType}Button`))
        .fields.find(field => field.field === `${actionType}Button`).api;

      const response = await axios.post(apiEndpoint, formData);
      console.log(`${actionType} request successful:`, response.data);
    } catch (err) {
      console.error(`${actionType} request failed:`, err);
    } finally {
      setLoading(false);
    }
  };

  const renderFields = (fields) => {
    return fields.map((field) => {
      if (field.type === 'select') {
        return (
          <Grid item xs={12} md={6} key={field.field}>
            <FormControl fullWidth>
              <InputLabel>{field.label}</InputLabel>
              <Select
                value={formData[field.field] || ''}
                onChange={handleChange}
                name={field.field}
                disabled={!field.editable}
              >
                {reassignOptions.map((option) => (
                  <MenuItem key={option.id} value={option.name}>
                    {option.name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
        );
      }

      if (field.type === 'button') {
        const buttonLength = field.buttonLength === 'short' ? '100px' :
                             field.buttonLength === 'medium' ? '150px' : '200px';
        return (
          <Grid item xs={12} md={4} key={field.field}>
            <Button
              variant="contained"
              onClick={() => handleSubmit(field.field.replace('Button', '').toLowerCase())}
              style={{ marginBottom: '1rem', width: buttonLength }}
              className="custom-button"  // Apply the custom button class
              disabled={loading}
            >
              {field.label}
            </Button>
          </Grid>
        );
      }

      return (
        <Grid item xs={12} md={6} key={field.field}>
          <TextField
            label={field.label}
            value={formData[field.field] || ''}
            variant="outlined"
            fullWidth
            InputProps={{
              readOnly: !field.editable
            }}
            onChange={handleChange}
            type={field.type === 'datetime' ? 'text' : field.type}
          />
        </Grid>
      );
    });
  };

  const renderSection = (section) => {
    const layout = section.layout === '2-column' ? 6 : section.layout === '3-column' ? 4 : 12;
    return (
      <Grid container spacing={2} sx={{ marginBottom: '20px' }}>
        {section.fields.map((field) => (
          <Grid item xs={12} md={layout} key={field.field}>
            {renderFields([field])}
          </Grid>
        ))}
      </Grid>
    );
  };

  return (
    <Box sx={{ padding: '20px' }}>
      {/* Over-title: Task {caseId} under {status} */}
      <Box className="header-title">
        <Typography variant="h5">
          Task {formData.caseId} under {formData.status}
        </Typography>
      </Box>

      <Typography variant="h6">Header</Typography>
      {renderSection(detailsSchema.sections.find(section => section.sectionName === 'header'))}

      <Typography variant="h6">Details</Typography>
      {renderSection(detailsSchema.sections.find(section => section.sectionName === 'details'))}

      <Typography variant="h6">Action Bar</Typography>
      {renderSection(detailsSchema.sections.find(section => section.sectionName === 'actionBar'))}

      {error && <Typography color="error">{error}</Typography>}
    </Box>
  );
};

export default CommonDetails;
