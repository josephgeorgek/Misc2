// src/components/CommonForm.js
import React, { useState } from 'react';
import { TextField, Select, MenuItem, Button, FormControl, InputLabel } from '@mui/material';
import formSchema from '../schemas/formSchema.json';
import axios from 'axios';

const CommonForm = ({ navigate }) => {
  const [formData, setFormData] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleSubmit = async (actionType) => {
    const apiEndpoint = `/v1/common-forms/tasks/${actionType}`;
    try {
      const response = await axios.post(apiEndpoint, formData);
      console.log('Form submitted:', response.data);
    } catch (error) {
      console.error('Error submitting form:', error);
    }
  };

  const handleCancel = () => {
    const navPath = formSchema.fields.find(f => f.field === 'cancelButton').navigateTo;
    navigate(navPath);
  };

  return (
    <form style={{ padding: '20px', maxWidth: '600px', margin: 'auto' }}>
      {formSchema.fields.map((field) => {
        if (!field.display) return null; // Conditional rendering based on display

        switch (field.type) {
          case 'text':
            return (
              <TextField
                key={field.field}
                fullWidth
                variant="outlined"
                label={field.label}
                name={field.field}
                value={formData[field.field] || ''}
                onChange={handleChange}
                required={field.mandatory}
                style={{ marginBottom: '1rem' }}
              />
            );
          case 'select':
            return (
              <FormControl fullWidth key={field.field} style={{ marginBottom: '1rem' }}>
                <InputLabel>{field.label}</InputLabel>
                <Select
                  name={field.field}
                  value={formData[field.field] || ''}
                  onChange={handleChange}
                >
                  {field.options.map(option => (
                    <MenuItem key={option} value={option}>
                      {option}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          case 'button':
            return (
              <Button
                key={field.field}
                variant="contained"
                color="primary"
                onClick={field.field === 'cancelButton' ? handleCancel : () => handleSubmit(field.field)}
                style={{ marginBottom: '1rem' }}
              >
                {field.label}
              </Button>
            );
          default:
            return null;
        }
      })}
    </form>
  );
};

export default CommonForm;
