// src/components/CommonListing.js
import React, { useState, useEffect } from 'react';
import { TextField, Button, Box, Table, TableHead, TableBody, TableRow, TableCell } from '@mui/material';
import axios from 'axios';
import listingSchema from '../schemas/listingSchema.json';  // Import the schema
import { Link } from 'react-router-dom'; // For navigating to detail view
import '../App.css';  // Import the App.css file for custom styling

const CommonListing = () => {
  const [tasks, setTasks] = useState([]);
  const [searchData, setSearchData] = useState({
    startDate: '',
    endDate: '',
    searchTerm: ''
  });

  // Fetch all tasks from the mock API on localhost:3001
  const loadAllTasks = async () => {
    try {
      const response = await axios.get('http://localhost:3001/v1/common-forms/tasks/inquiry/user-id');
      setTasks(response.data);
    } catch (error) {
      console.error('Error loading tasks:', error);
    }
  };

  useEffect(() => {
    loadAllTasks(); // Load tasks on component mount
  }, []);

  const handleSearch = async () => {
    try {
      const { startDate, endDate, searchTerm } = searchData;
      const response = await axios.get('http://localhost:3001/v1/common-forms/tasks/search', {
        params: { startDate, endDate, searchTerm }
      });
      setTasks(response.data);
    } catch (error) {
      console.error('Error during search:', error);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setSearchData((prevData) => ({
      ...prevData,
      [name]: value
    }));
  };

  return (
    <Box sx={{ padding: '20px' }}>
      {/* Search Section */}
      <Box className="search-section">
        {listingSchema.fields.map((field) => (
          <TextField
            key={field.field}
            label={field.label}
            type={field.type}
            name={field.field}
            value={searchData[field.field] || ''}
            onChange={handleChange}
            className="search-field"
            variant="outlined"
            style={{ marginRight: '10px' }}
          />
        ))}
        <Button variant="contained" color="primary" onClick={handleSearch}>
          Search
        </Button>
      </Box>

      {/* Task Listing Table */}
      <Table>
        <TableHead>
          <TableRow>
            {listingSchema.listingFields.map((column) => (
              <TableCell className="column-header" key={column.field}>
                {column.label}
              </TableCell>
            ))}
          </TableRow>
        </TableHead>
        <TableBody>
          {tasks.map((task) => (
            <TableRow key={task.caseId}>
              {listingSchema.listingFields.map((column) => (
                <TableCell key={column.field}>
                  {column.isLink ? (
                    <Link to={`/task-details/${task[column.field]}`}>
                      {task[column.field]}
                    </Link>
                  ) : (
                    task[column.field]
                  )}
                </TableCell>
              ))}
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </Box>
  );
};

export default CommonListing;
