import React, { useState } from 'react';
import { TextField, MenuItem, Button, Grid, InputLabel, FormControl, Select } from '@mui/material';

const DynamicForm = ({ jsonSchema }) => {
  const [formData, setFormData] = useState({});

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const renderField = (field) => {
    switch (field.type) {
      case 'text':
      case 'email':
      case 'date':
        return (
          <Grid item xs={12} sm={jsonSchema.layout === '2-column' ? 6 : 12} key={field.name}>
            <TextField
              fullWidth
              variant="outlined"
              label={field.label}
              type={field.type}
              name={field.name}
              placeholder={field.placeholder || ''}
              onChange={handleChange}
            />
          </Grid>
        );
      case 'select':
        return (
          <Grid item xs={12} sm={jsonSchema.layout === '2-column' ? 6 : 12} key={field.name}>
            <FormControl fullWidth>
              <InputLabel>{field.label}</InputLabel>
              <Select
                label={field.label}
                name={field.name}
                value={formData[field.name] || ''}
                onChange={handleChange}
              >
                {field.options.map((option) => (
                  <MenuItem key={option} value={option}>
                    {option}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
        );
      default:
        return null;
    }
  };

  // Determine the layout based on the schema
  const layoutGrid = jsonSchema.layout === '2-column' ? 6 : 12;

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(formData); // Handle form submission logic here
  };

  return (
    <form onSubmit={handleSubmit}>
      <Grid container spacing={2}>
        {jsonSchema.fields.map((field) => renderField(field))}
        <Grid item xs={12}>
          <Button variant="contained" color="primary" type="submit">
            Submit
          </Button>
        </Grid>
      </Grid>
    </form>
  );
};

export default DynamicForm;
