import React, { useState } from 'react';
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, Select, MenuItem, Button, TextField } from '@mui/material';
import caseData from '../mockdata/caseData'; // Import mock data

const DynamicForm = ({ jsonSchema }) => {
  const [formData, setFormData] = useState(caseData); // Use imported mock data

  const handleChange = (e, index, field) => {
    const updatedData = [...formData];
    updatedData[index][field] = e.target.value;
    setFormData(updatedData);
  };

  const renderCell = (column, value, index) => {
    switch (column.type) {
      case 'text':
      case 'date':
        return (
          <TableCell key={column.field}>
            <TextField
              fullWidth
              variant="outlined"
              type={column.type}
              value={value}
              onChange={(e) => handleChange(e, index, column.field)}
            />
          </TableCell>
        );
      case 'select':
        return (
          <TableCell key={column.field}>
            <Select
              fullWidth
              value={value}
              onChange={(e) => handleChange(e, index, column.field)}
            >
              {column.options.map((option) => (
                <MenuItem key={option} value={option}>
                  {option}
                </MenuItem>
              ))}
            </Select>
          </TableCell>
        );
      default:
        return null;
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(formData); // Handle form submission logic here
  };

  if (jsonSchema.layout === 'tabular') {
    return (
      <form onSubmit={handleSubmit}>
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                {jsonSchema.columns.map((column) => (
                  <TableCell key={column.field}>{column.label}</TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {formData.map((rowData, index) => (
                <TableRow key={index}>
                  {jsonSchema.columns.map((column) =>
                    renderCell(column, rowData[column.field], index)
                  )}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
        <Button variant="contained" color="primary" type="submit">
          Submit
        </Button>
      </form>
    );
  }

  return <div>No layout defined</div>;
};

export default DynamicForm;
