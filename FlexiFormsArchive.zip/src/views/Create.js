// TaskRegistration.js
import React from 'react';
import CommonForm from '../components/CommonForm';
import { useNavigate } from 'react-router-dom';

const TaskRegistration = () => {
  const navigate = useNavigate();
  return <CommonForm navigate={navigate} />;
};

export default TaskRegistration;
