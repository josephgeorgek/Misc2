// src/views/TaskDetails.js
import React from 'react';
import CommonDetails from '../components/CommonDetails';
import { useParams } from 'react-router-dom'; // To get the caseId from the URL

const TaskDetails = () => {
  const { id } = useParams(); // Get the caseId from the URL

  return <CommonDetails caseId={id} />; // Pass the caseId to CommonDetails
};

export default TaskDetails;
