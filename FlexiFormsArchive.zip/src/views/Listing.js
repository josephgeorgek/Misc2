
// TaskListing.js
import React from 'react';
import CommonListing from '../components/CommonListing';

const TaskListing = () => {
  return <CommonListing />;
};

export default TaskListing;
