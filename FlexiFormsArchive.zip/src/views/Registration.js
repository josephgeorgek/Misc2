// src/components/Registration.js
import React from 'react';
import DynamicForm from '../components/DynamicForm';
import formSchema from '../schemas/registrationSchema.json'; // Assuming this contains the registration schema

const Registration = () => {
  return (
    <div>
      <h1>Registration Page</h1>
      <DynamicForm jsonSchema={formSchema} />
    </div>
  );
};

export default Registration;
