# OCBC Business Account Opening Application
## Design Documentation

**Version:** 1.0  
**Last Updated:** January 2026  
**Project Type:** Full-Stack Web Application

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [User Stories](#2-user-stories)
3. [Architecture Details](#3-architecture-details)
4. [Implementation Details](#4-implementation-details)
5. [Data Models](#5-data-models)
6. [API Reference](#6-api-reference)
7. [Security Considerations](#7-security-considerations)

---

## 1. Executive Summary

### 1.1 Project Overview

This application is a comprehensive digital transformation of the 46-page OCBC Unified Business Account Application Form. It provides a modern, user-friendly interface for businesses to open bank accounts, replacing traditional paper-based processes with a streamlined digital workflow.

### 1.2 Key Features

- **10-Step Form Wizard**: Guided application process covering all banking requirements
- **PDF Data Extraction**: Upload existing forms and auto-populate fields using OCR
- **Digital Signature Capture**: Canvas-based signature collection with base64 encoding
- **Draft Management**: Save, search, and resume applications
- **PDF Export**: Generate completed forms matching the original 46-page format
- **Backend Integration**: Optional Spring Boot backend with localStorage fallback

### 1.3 Technology Stack

| Layer | Technology |
|-------|------------|
| Frontend Framework | React 18 with TypeScript |
| UI Components | Material-UI (MUI) v7 + shadcn/ui |
| Styling | Tailwind CSS |
| State Management | React Hooks + React Query |
| Form Handling | React Hook Form + Zod |
| PDF Processing | pdfjs-dist + Tesseract.js (OCR) |
| PDF Generation | jspdf + html2canvas |
| HTTP Client | Axios |
| Backend Framework | Spring Boot 3.x |
| Database | H2 (in-memory) / PostgreSQL |
| ORM | Spring Data JPA |

---

## 2. User Stories

### 2.1 Bank Officer Personas

#### Primary Persona: Relationship Manager (RM)
- Handles corporate client onboarding
- Needs to process multiple applications daily
- Requires quick data entry and validation

#### Secondary Persona: Operations Officer
- Reviews and approves submitted applications
- Needs comprehensive view of all application data
- Exports finalized applications for record-keeping

### 2.2 Epic 1: Application Management

#### US-1.1: View Application Dashboard
```
As a Relationship Manager
I want to see all applications on a dashboard
So that I can quickly access and manage my workload

Acceptance Criteria:
- Display application statistics (total, pending, approved, rejected)
- Show searchable list of recent applications
- Filter by company name or UEN
- Visual status indicators (chips with colors)
```

#### US-1.2: Create New Application
```
As a Relationship Manager
I want to start a new business account application
So that I can onboard a new corporate client

Acceptance Criteria:
- Option for online application (blank form)
- Option to upload PDF for data extraction
- Clear navigation through 10-step wizard
- Progress indicator showing current step
```

#### US-1.3: Save Application as Draft
```
As a Relationship Manager
I want to save an incomplete application as draft
So that I can continue later without losing data

Acceptance Criteria:
- Auto-save functionality on step completion
- Manual save button available
- Draft appears in application list
- Can resume from last saved state
```

#### US-1.4: Search Applications
```
As a Relationship Manager
I want to search for applications by company name or UEN
So that I can quickly find specific records

Acceptance Criteria:
- Real-time search filtering
- Search works across company name and UEN
- Clear search results display
```

### 2.3 Epic 2: PDF Data Extraction

#### US-2.1: Upload PDF Form
```
As a Relationship Manager
I want to upload a filled PDF application form
So that data can be auto-extracted and pre-populated

Acceptance Criteria:
- Support PDF file upload
- Show upload progress indicator
- Handle both text-based and scanned PDFs
- Display extraction status
```

#### US-2.2: Review Extracted Data
```
As a Relationship Manager
I want to review data extracted from PDF
So that I can verify accuracy before proceeding

Acceptance Criteria:
- Form View tab showing organized data
- JSON Editor tab for technical review
- Signatures tab displaying extracted signatures
- Ability to edit extracted data
- Confidence indicators for OCR results
```

#### US-2.3: Extract Signatures from PDF
```
As a Relationship Manager
I want signatures to be automatically extracted from uploaded PDFs
So that I don't need to recollect them digitally

Acceptance Criteria:
- Detect ink-dense signature regions
- Extract as base64 images
- Display with confidence scores
- Auto-assign to appropriate form fields
```

### 2.4 Epic 3: Form Completion

#### US-3.1: Business Details Entry
```
As a Relationship Manager
I want to enter company business details
So that the bank has accurate corporate information

Acceptance Criteria:
- Capture registered name, UEN, contact details
- Validate Singapore business registration format
- Support GST registration status
- Indicate business type/nature
```

#### US-3.2: Account Configuration
```
As a Relationship Manager
I want to configure account types and currencies
So that the client gets appropriate banking products

Acceptance Criteria:
- Select SGD account types
- Select foreign currency accounts
- Configure PayNow/SGQR options
- Define multiple outlet details
```

#### US-3.3: Beneficial Owners Declaration
```
As a Relationship Manager
I want to declare beneficial owners and authorized signatories
So that the bank meets regulatory requirements

Acceptance Criteria:
- Add multiple beneficial owners
- Capture ownership percentage
- Define signatory groupings
- Collect specimen signatures
```

#### US-3.4: Board Resolution Entry
```
As a Relationship Manager
I want to record board resolution details
So that corporate authorization is documented

Acceptance Criteria:
- Record meeting date and resolution
- Define authorized activities
- List authorized persons with signatures
- Capture director and secretary signatures
```

#### US-3.5: Tax Declaration (FATCA/CRS)
```
As a Relationship Manager
I want to complete tax declarations
So that the bank complies with FATCA and CRS regulations

Acceptance Criteria:
- Entity type classification
- Tax residency details
- Controlling person declarations
- TIN/no-TIN explanations
```

#### US-3.6: Business Banking Services
```
As a Relationship Manager
I want to configure OCBC Velocity settings
So that the client has appropriate online banking access

Acceptance Criteria:
- Select service package (Basic/Standard/Classic)
- Configure user roles and permissions
- Define approval matrix
- Set transaction type authorizations
```

#### US-3.7: Additional Services
```
As a Relationship Manager
I want to apply for debit cards and GIRO
So that the client has complete banking setup

Acceptance Criteria:
- Debit card application with cardholder details
- GIRO setup with billing organizations
- eAlerts configuration
```

### 2.5 Epic 4: Digital Signatures

#### US-4.1: Capture Digital Signature
```
As a Relationship Manager
I want to capture digital signatures on canvas
So that authorized persons can sign electronically

Acceptance Criteria:
- Touch/mouse-enabled signature canvas
- Clear and redo functionality
- Preview before saving
- Store as base64 image
```

#### US-4.2: View and Edit Signatures
```
As a Relationship Manager
I want to view and modify captured signatures
So that corrections can be made if needed

Acceptance Criteria:
- Display current signature
- Option to re-capture
- Signatures persist across sessions
- Show in review and PDF export
```

### 2.6 Epic 5: Application Submission

#### US-5.1: Review Complete Application
```
As a Relationship Manager
I want to review all entered data before submission
So that I can verify completeness and accuracy

Acceptance Criteria:
- Summary view of all sections
- Highlight incomplete fields
- Expand/collapse section details
- View all captured signatures
```

#### US-5.2: Export as PDF
```
As a Relationship Manager
I want to export the application as PDF
So that a physical record can be filed

Acceptance Criteria:
- Generate multi-page PDF
- Match original form layout
- Include all data and signatures
- Professional formatting
```

#### US-5.3: Submit Application
```
As a Relationship Manager
I want to submit the completed application
So that it can be processed by operations

Acceptance Criteria:
- Validation of required fields
- Submission confirmation
- Status update to 'Submitted'
- Timestamp recording
```

---

## 3. Architecture Details

### 3.1 System Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────────┐
│                           CLIENT BROWSER                                 │
├─────────────────────────────────────────────────────────────────────────┤
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                    REACT APPLICATION                             │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐  │   │
│  │  │    Pages     │  │  Components  │  │       Hooks          │  │   │
│  │  │  - Landing   │  │  - Form      │  │  - useApplication    │  │   │
│  │  │  - Index     │  │  - Steps     │  │    Storage           │  │   │
│  │  │  - View      │  │  - UI        │  │  - useAllApps        │  │   │
│  │  └──────────────┘  └──────────────┘  └──────────────────────┘  │   │
│  │                              │                                    │   │
│  │  ┌──────────────────────────┴──────────────────────────────┐   │   │
│  │  │                    API CLIENT LAYER                      │   │   │
│  │  │  ┌─────────────────┐     ┌─────────────────────────┐   │   │   │
│  │  │  │   apiClient.ts  │     │   applicationApi.ts     │   │   │   │
│  │  │  │  (Axios config) │     │  (CRUD + Health Check)  │   │   │   │
│  │  │  └─────────────────┘     └─────────────────────────┘   │   │   │
│  │  └──────────────────────────────────────────────────────────┘   │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                    │                                     │
│                        ┌───────────┴───────────┐                        │
│                        │    FALLBACK LOGIC     │                        │
│                        │  Backend Available?   │                        │
│                        └───────────┬───────────┘                        │
│                    YES ┌───────────┴───────────┐ NO                     │
│                        ▼                       ▼                        │
│              ┌─────────────────┐    ┌─────────────────────┐            │
│              │  REST API CALL  │    │   LOCAL STORAGE     │            │
│              └────────┬────────┘    │  - user_drafts      │            │
│                       │             │  - app_signatures_* │            │
└───────────────────────│─────────────└─────────────────────┴─────────────┘
                        │
                        ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                        SPRING BOOT BACKEND                               │
├─────────────────────────────────────────────────────────────────────────┤
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │                      CONTROLLER LAYER                             │  │
│  │  ┌─────────────────┐ ┌─────────────────┐ ┌─────────────────────┐ │  │
│  │  │ ApplicationCtrl │ │ SignatureCtrl   │ │    HealthCtrl       │ │  │
│  │  │ /api/applications│ │ /api/signatures │ │    /api/health      │ │  │
│  │  └────────┬────────┘ └────────┬────────┘ └─────────────────────┘ │  │
│  └───────────│───────────────────│──────────────────────────────────┘  │
│              │                   │                                      │
│  ┌───────────│───────────────────│──────────────────────────────────┐  │
│  │           │    SERVICE LAYER  │                                   │  │
│  │  ┌────────▼────────┐ ┌────────▼────────┐                         │  │
│  │  │ ApplicationSvc  │ │  SignatureSvc   │  ←── Interfaces         │  │
│  │  │     (impl)      │ │     (impl)      │  ←── Implementations    │  │
│  │  └────────┬────────┘ └────────┬────────┘                         │  │
│  └───────────│───────────────────│──────────────────────────────────┘  │
│              │                   │                                      │
│  ┌───────────│───────────────────│──────────────────────────────────┐  │
│  │           │  REPOSITORY LAYER │                                   │  │
│  │  ┌────────▼────────┐ ┌────────▼────────┐ ┌─────────────────────┐ │  │
│  │  │ ApplicationRepo │ │  SignatureRepo  │ │ BeneficialOwnerRepo │ │  │
│  │  │ (JPA Repository)│ │ (JPA Repository)│ │   (JPA Repository)  │ │  │
│  │  └────────┬────────┘ └────────┬────────┘ └──────────┬──────────┘ │  │
│  └───────────│───────────────────│─────────────────────│────────────┘  │
│              │                   │                     │                │
│  ┌───────────▼───────────────────▼─────────────────────▼────────────┐  │
│  │                         H2 DATABASE                               │  │
│  │  ┌─────────────────┐ ┌─────────────────┐ ┌─────────────────────┐ │  │
│  │  │  applications   │ │   signatures    │ │  beneficial_owners  │ │  │
│  │  └─────────────────┘ └─────────────────┘ └─────────────────────┘ │  │
│  └──────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────┘
```

### 3.2 Frontend Architecture

#### 3.2.1 Directory Structure

```
src/
├── api/                      # API communication layer
│   ├── apiClient.ts          # Axios instance with interceptors
│   └── applicationApi.ts     # Application & signature API methods
│
├── components/
│   ├── form/                 # Form-related components
│   │   ├── steps/            # 10-step wizard components
│   │   │   ├── AccountTypeStep.tsx
│   │   │   ├── AccountParticularsStep.tsx
│   │   │   ├── BeneficialOwnersStep.tsx
│   │   │   ├── BoardResolutionStep.tsx
│   │   │   ├── BusinessDetailsStep.tsx
│   │   │   ├── BusinessServicesStep.tsx
│   │   │   ├── DebitCardStep.tsx
│   │   │   ├── GIROStep.tsx
│   │   │   ├── ReviewStep.tsx
│   │   │   └── TaxDeclarationStep.tsx
│   │   ├── BusinessAccountForm.tsx
│   │   ├── FormHeader.tsx
│   │   ├── FormNavigation.tsx
│   │   ├── FormProgress.tsx
│   │   ├── SignatureCanvas.tsx
│   │   └── ViewSignaturesSection.tsx
│   └── ui/                   # Reusable UI components (shadcn)
│
├── data/
│   └── drafts.ts             # Sample draft data
│
├── hooks/
│   ├── useApplicationStorage.ts  # Data persistence hook
│   └── use-toast.ts              # Toast notifications
│
├── layouts/
│   └── MainLayout.tsx        # App layout wrapper
│
├── lib/
│   ├── pdfParser.ts          # PDF extraction & OCR
│   └── utils.ts              # Utility functions
│
├── pages/
│   ├── Index.tsx             # Form wizard page
│   ├── IndexMUI.tsx          # MUI version of form
│   ├── Landing.tsx           # Dashboard (shadcn)
│   ├── LandingMUI.tsx        # Dashboard (MUI)
│   ├── ViewApplication.tsx   # View/edit application
│   └── NotFound.tsx          # 404 page
│
├── types/
│   └── form.ts               # TypeScript interfaces
│
└── theme/
    └── theme.ts              # MUI theme configuration
```

#### 3.2.2 Component Hierarchy

```
App
├── MainLayout
│   ├── Landing/LandingMUI
│   │   ├── StatsCards
│   │   ├── ApplicationTable
│   │   └── OnboardingDialog
│   │       ├── UploadTab
│   │       ├── FormViewTab
│   │       ├── JSONEditorTab
│   │       └── SignaturesTab
│   │
│   ├── Index/IndexMUI (Form Wizard)
│   │   ├── FormHeader
│   │   ├── FormProgress
│   │   ├── [Current Step Component]
│   │   │   └── SignatureCanvas (where needed)
│   │   └── FormNavigation
│   │
│   └── ViewApplication
│       ├── ApplicationDetails
│       ├── ViewSignaturesSection
│       └── PDFExportButton
```

### 3.3 Backend Architecture

#### 3.3.1 Directory Structure

```
spring-boot-backend/
├── src/main/java/com/bank/accountopening/
│   ├── config/
│   │   └── CorsConfig.java       # CORS configuration
│   │
│   ├── controller/
│   │   ├── ApplicationController.java
│   │   ├── SignatureController.java
│   │   └── HealthController.java
│   │
│   ├── entity/
│   │   ├── ApplicationEntity.java
│   │   ├── BeneficialOwnerEntity.java
│   │   └── SignatureEntity.java
│   │
│   ├── exception/
│   │   └── GlobalExceptionHandler.java
│   │
│   ├── model/                    # DTOs
│   │   ├── ApplicationDTO.java
│   │   ├── BusinessDetailsDTO.java
│   │   ├── ContactPersonDTO.java
│   │   ├── AccountTypeDTO.java
│   │   ├── BeneficialOwnerDTO.java
│   │   ├── BoardResolutionDTO.java
│   │   ├── SignatureDTO.java
│   │   └── ApiResponse.java
│   │
│   ├── repository/
│   │   ├── ApplicationRepository.java
│   │   ├── BeneficialOwnerRepository.java
│   │   └── SignatureRepository.java
│   │
│   ├── service/
│   │   ├── ApplicationService.java      # Interface
│   │   ├── SignatureService.java        # Interface
│   │   └── impl/
│   │       ├── ApplicationServiceImpl.java
│   │       └── SignatureServiceImpl.java
│   │
│   └── AccountOpeningApplication.java   # Main class
│
├── src/main/resources/
│   └── application.properties
│
└── src/test/java/
    └── com/bank/accountopening/
        ├── controller/
        │   ├── ApplicationControllerTest.java
        │   └── SignatureControllerTest.java
        └── service/
            └── ApplicationServiceTest.java
```

#### 3.3.2 Layered Architecture

| Layer | Responsibility | Components |
|-------|---------------|------------|
| **Controller** | HTTP request handling, input validation | `@RestController` classes |
| **Service** | Business logic, transaction management | Interface + `@Service` implementations |
| **Repository** | Data access, CRUD operations | `@Repository` extending `JpaRepository` |
| **Entity** | Database table mapping | `@Entity` classes with JPA annotations |
| **Model/DTO** | Data transfer, API contracts | POJOs with Lombok annotations |

### 3.4 Data Flow

#### 3.4.1 Application Submission Flow

```
┌──────────┐     ┌──────────┐     ┌──────────┐     ┌──────────┐
│  User    │────▶│  Form    │────▶│  Hook    │────▶│  API     │
│  Input   │     │  Steps   │     │  Layer   │     │  Client  │
└──────────┘     └──────────┘     └──────────┘     └────┬─────┘
                                                        │
                      ┌─────────────────────────────────┤
                      │                                 │
                      ▼                                 ▼
              ┌──────────────┐               ┌──────────────┐
              │ localStorage │               │  REST API    │
              │  (Fallback)  │               │  (Primary)   │
              └──────────────┘               └──────┬───────┘
                                                    │
                                                    ▼
                                            ┌──────────────┐
                                            │   Database   │
                                            └──────────────┘
```

#### 3.4.2 PDF Extraction Flow

```
┌────────────┐     ┌────────────┐     ┌────────────┐     ┌────────────┐
│   PDF      │────▶│  pdfjs-    │────▶│  Text      │────▶│  Regex     │
│   Upload   │     │  dist      │     │  Extract   │     │  Parsing   │
└────────────┘     └────────────┘     └────────────┘     └─────┬──────┘
                                                               │
                   ┌───────────────────────────────────────────┤
                   │                                           │
                   ▼                                           ▼
           ┌──────────────┐                           ┌──────────────┐
           │ Tesseract.js │                           │  FormData    │
           │    (OCR)     │ ◀── (if text sparse)      │   Object     │
           └──────────────┘                           └──────────────┘
                   │                                           │
                   ▼                                           │
           ┌──────────────┐                                    │
           │  Signature   │                                    │
           │  Detection   │────────────────────────────────────┘
           └──────────────┘
```

---

## 4. Implementation Details

### 4.1 Frontend Implementation

#### 4.1.1 Form Wizard Navigation

The 10-step wizard uses controlled state management:

```typescript
const FORM_STEPS = [
  { id: 'business', label: 'Business Details' },
  { id: 'accountType', label: 'Account Type' },
  { id: 'accountParticulars', label: 'Account Particulars' },
  { id: 'beneficialOwners', label: 'Beneficial Owners' },
  { id: 'boardResolution', label: 'Board Resolution' },
  { id: 'taxDeclaration', label: 'Tax Declaration' },
  { id: 'businessServices', label: 'Business Services' },
  { id: 'debitCard', label: 'Debit Card' },
  { id: 'giro', label: 'GIRO & eAlerts' },
  { id: 'review', label: 'Review & Submit' },
];
```

Navigation is controlled by:
- Step validation before proceeding
- Progress persistence in state
- URL routing for deep linking

#### 4.1.2 Backend Fallback Pattern

The application implements a health-check-based fallback:

```typescript
// Check backend availability with caching
let backendAvailable: boolean | null = null;
const HEALTH_CHECK_INTERVAL = 30000; // 30 seconds

async function checkBackendHealth(): Promise<boolean> {
  if (backendAvailable !== null && recentlyChecked) {
    return backendAvailable;
  }
  
  try {
    await api.get('/health', { timeout: 5000 });
    backendAvailable = true;
  } catch {
    backendAvailable = false;
  }
  return backendAvailable;
}

// Usage in hooks
if (await checkBackendHealth()) {
  // Use REST API
  return await applicationApi.getById(id);
} else {
  // Fallback to localStorage
  return getUserDrafts().find(d => d.id === id);
}
```

#### 4.1.3 PDF Parsing Implementation

```typescript
async function parsePDF(file: File): Promise<ParsedPDFData> {
  const arrayBuffer = await file.arrayBuffer();
  const pdf = await pdfjsLib.getDocument(arrayBuffer).promise;
  
  let fullText = '';
  const signatures: ExtractedSignature[] = [];
  
  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    
    // Extract text
    const textContent = await page.getTextContent();
    const pageText = textContent.items
      .map(item => item.str)
      .join(' ');
    fullText += pageText;
    
    // Extract signatures (render to canvas, detect ink regions)
    const canvas = await renderPageToCanvas(page);
    const pageSignatures = extractSignaturesFromCanvas(canvas, i);
    signatures.push(...pageSignatures);
  }
  
  // OCR fallback if text is sparse
  if (fullText.length < 500) {
    fullText = await extractTextWithOCR(pdf);
  }
  
  // Parse text to FormData
  const formData = parseTextToFormData(fullText);
  
  return { formData, signatures, rawText: fullText };
}
```

#### 4.1.4 Signature Canvas Implementation

```typescript
const SignatureCanvas = ({ onSave, initialSignature }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  
  const startDrawing = (e: MouseEvent | TouchEvent) => {
    const ctx = canvasRef.current?.getContext('2d');
    ctx?.beginPath();
    ctx?.moveTo(getX(e), getY(e));
    setIsDrawing(true);
  };
  
  const draw = (e: MouseEvent | TouchEvent) => {
    if (!isDrawing) return;
    const ctx = canvasRef.current?.getContext('2d');
    ctx?.lineTo(getX(e), getY(e));
    ctx?.stroke();
  };
  
  const saveSignature = () => {
    const dataUrl = canvasRef.current?.toDataURL('image/png');
    onSave(dataUrl); // base64 encoded signature
  };
  
  return (
    <canvas
      ref={canvasRef}
      onMouseDown={startDrawing}
      onMouseMove={draw}
      onMouseUp={() => setIsDrawing(false)}
      onTouchStart={startDrawing}
      onTouchMove={draw}
      onTouchEnd={() => setIsDrawing(false)}
    />
  );
};
```

### 4.2 Backend Implementation

#### 4.2.1 Controller Pattern

```java
@RestController
@RequestMapping("/api/applications")
@CrossOrigin(origins = "*")
public class ApplicationController {
    
    private final ApplicationService applicationService;
    
    @GetMapping
    public ResponseEntity<ApiResponse<List<ApplicationDTO>>> getAllApplications() {
        List<ApplicationDTO> applications = applicationService.getAllApplications();
        return ResponseEntity.ok(ApiResponse.success(applications, "Retrieved all applications"));
    }
    
    @PostMapping
    public ResponseEntity<ApiResponse<ApplicationDTO>> createApplication(
            @Valid @RequestBody ApplicationDTO applicationDTO) {
        ApplicationDTO created = applicationService.createApplication(applicationDTO);
        return ResponseEntity.status(HttpStatus.CREATED)
            .body(ApiResponse.success(created, "Application created successfully"));
    }
    
    @PostMapping("/{id}/submit")
    public ResponseEntity<ApiResponse<ApplicationDTO>> submitApplication(@PathVariable String id) {
        ApplicationDTO submitted = applicationService.submitApplication(id);
        return ResponseEntity.ok(ApiResponse.success(submitted, "Application submitted"));
    }
}
```

#### 4.2.2 Service Layer Pattern

```java
// Interface
public interface ApplicationService {
    List<ApplicationDTO> getAllApplications();
    ApplicationDTO getApplicationById(String id);
    ApplicationDTO createApplication(ApplicationDTO dto);
    ApplicationDTO updateApplication(String id, ApplicationDTO dto);
    ApplicationDTO submitApplication(String id);
    void deleteApplication(String id);
}

// Implementation
@Service
@Transactional
public class ApplicationServiceImpl implements ApplicationService {
    
    private final ApplicationRepository applicationRepository;
    
    @Override
    public ApplicationDTO createApplication(ApplicationDTO dto) {
        ApplicationEntity entity = mapToEntity(dto);
        entity.setId(UUID.randomUUID().toString());
        entity.setStatus("draft");
        entity.setCreatedAt(LocalDateTime.now());
        entity.setUpdatedAt(LocalDateTime.now());
        
        ApplicationEntity saved = applicationRepository.save(entity);
        return mapToDTO(saved);
    }
    
    @Override
    public ApplicationDTO submitApplication(String id) {
        ApplicationEntity entity = applicationRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Application not found"));
        
        entity.setStatus("submitted");
        entity.setSubmittedAt(LocalDateTime.now());
        entity.setUpdatedAt(LocalDateTime.now());
        
        return mapToDTO(applicationRepository.save(entity));
    }
}
```

#### 4.2.3 CORS Configuration

```java
@Configuration
public class CorsConfig implements WebMvcConfigurer {
    
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/api/**")
            .allowedOrigins(
                "http://localhost:5173",
                "http://localhost:3000",
                "https://*.lovable.app"
            )
            .allowedMethods("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS")
            .allowedHeaders("*")
            .allowCredentials(true)
            .maxAge(3600);
    }
}
```

#### 4.2.4 Global Exception Handling

```java
@RestControllerAdvice
public class GlobalExceptionHandler {
    
    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<ApiResponse<Void>> handleNotFound(ResourceNotFoundException ex) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
            .body(ApiResponse.error(ex.getMessage()));
    }
    
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ApiResponse<Map<String, String>>> handleValidation(
            MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getFieldErrors().forEach(error -> 
            errors.put(error.getField(), error.getDefaultMessage())
        );
        return ResponseEntity.badRequest()
            .body(ApiResponse.error("Validation failed", errors));
    }
}
```

---

## 5. Data Models

### 5.1 Core Entity Relationships

```
┌─────────────────────┐       ┌─────────────────────┐
│   ApplicationEntity │       │   SignatureEntity   │
├─────────────────────┤       ├─────────────────────┤
│ id (PK)             │──┐    │ id (PK)             │
│ companyName         │  │    │ applicationId (FK)  │──┐
│ uen                 │  │    │ signatoryName       │  │
│ status              │  │    │ signatureData       │  │
│ formDataJson        │  │    │ signatureType       │  │
│ createdAt           │  │    │ signedAt            │  │
│ updatedAt           │  │    └─────────────────────┘  │
│ submittedAt         │  │                             │
└─────────────────────┘  │    ┌─────────────────────┐  │
                         │    │ BeneficialOwnerEntity│  │
                         └───▶├─────────────────────┤  │
                              │ id (PK)             │  │
                              │ applicationId (FK)  │◀─┘
                              │ fullName            │
                              │ nricPassport        │
                              │ designation         │
                              │ ownershipPercentage │
                              │ isSignatory         │
                              └─────────────────────┘
```

### 5.2 FormData TypeScript Interface (Condensed)

```typescript
interface FormData {
  businessDetails: BusinessDetails;
  primaryContact: ContactPerson;
  secondaryContact: ContactPerson;
  accountType: AccountType;
  accountParticulars: AccountParticulars;
  beneficialOwners: BeneficialOwner[];
  signingCondition: SigningCondition;
  boardResolution: BoardResolution;
  taxDeclarationEntity: TaxDeclarationEntity;
  taxDeclarationIndividual: TaxDeclarationIndividual;
  businessBankingServices: BusinessBankingServices;
  businessDebitCard: BusinessDebitCard;
  giroApplication: GIROApplication;
  eAlerts: EAlerts;
  agreement: Agreement;
}

interface DraftApplication extends FormData {
  id: string;
  status: 'draft' | 'submitted' | 'approved' | 'rejected';
  createdAt: string;
  updatedAt: string;
}
```

---

## 6. API Reference

### 6.1 Application Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/applications` | List all applications |
| GET | `/api/applications/{id}` | Get application by ID |
| GET | `/api/applications/search?query={q}` | Search by name/UEN |
| POST | `/api/applications` | Create new application |
| PUT | `/api/applications/{id}` | Update application |
| POST | `/api/applications/draft` | Save as draft |
| POST | `/api/applications/{id}/submit` | Submit application |
| DELETE | `/api/applications/{id}` | Delete application |

### 6.2 Signature Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/signatures` | List all signatures |
| GET | `/api/signatures/{id}` | Get signature by ID |
| GET | `/api/signatures/application/{appId}` | Get by application |
| POST | `/api/signatures` | Create signature |
| POST | `/api/signatures/batch` | Batch create signatures |
| DELETE | `/api/signatures/{id}` | Delete signature |

### 6.3 Health Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/health` | Health check |
| GET | `/api/info` | Application info |

### 6.4 Response Format

```json
{
  "success": true,
  "data": { /* response data */ },
  "message": "Operation completed successfully",
  "timestamp": "2026-01-14T10:30:00Z"
}
```

---

## 7. Security Considerations

### 7.1 Current Implementation

| Area | Status | Notes |
|------|--------|-------|
| CORS | ✅ Configured | Restricted origins |
| Input Validation | ✅ Implemented | Bean Validation + Zod |
| SQL Injection | ✅ Protected | JPA parameterized queries |
| XSS | ✅ Protected | React auto-escaping |
| Authentication | ⚠️ Not implemented | Planned: JWT tokens |
| Authorization | ⚠️ Not implemented | Planned: Role-based access |
| HTTPS | ⚠️ Environment-dependent | Required for production |
| Rate Limiting | ❌ Not implemented | Consider for production |

### 7.2 Recommended Enhancements

1. **Add JWT Authentication**
   - Spring Security with JWT token validation
   - Token refresh mechanism
   - Role-based access control

2. **Secure Signature Storage**
   - Encrypt base64 signature data at rest
   - Add signature verification/integrity checks

3. **Audit Logging**
   - Track all data modifications
   - Store user actions with timestamps

4. **Data Encryption**
   - Encrypt sensitive fields (NRIC, TIN)
   - Use HTTPS in production

---

## Appendix A: Running the Application

### Frontend (React)

```bash
# Install dependencies
npm install

# Development server
npm run dev

# Production build
npm run build
```

### Backend (Spring Boot)

```bash
cd spring-boot-backend

# Run with Maven
mvn spring-boot:run

# Run tests
mvn test

# Package JAR
mvn package
```

### Environment Variables

```bash
# Frontend (.env)
VITE_API_BASE_URL=http://localhost:8080/api

# Backend (application.properties)
server.port=8080
spring.h2.console.enabled=true
```

---

## Appendix B: Glossary

| Term | Definition |
|------|------------|
| UEN | Unique Entity Number (Singapore business registration) |
| FATCA | Foreign Account Tax Compliance Act |
| CRS | Common Reporting Standard |
| GIRO | General Interbank Recurring Order |
| SGQR | Singapore Quick Response Code |
| PayNow | Singapore's instant payment system |
| OCBC Velocity | Business internet banking platform |
| RLS | Row Level Security |
| DTO | Data Transfer Object |
| JPA | Java Persistence API |

---

*Document maintained by the Development Team*
