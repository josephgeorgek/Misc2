# Business Account Opening - Spring Boot Backend

A Spring Boot REST API for managing business account opening applications.

## Technology Stack

- **Java 17**
- **Spring Boot 3.2.0**
- **Spring Data JPA**
- **H2 In-Memory Database**
- **Lombok**
- **Maven**

## Project Structure

```
src/main/java/com/bank/accountopening/
├── AccountOpeningApplication.java    # Main application entry point
├── config/
│   └── CorsConfig.java               # CORS configuration
├── controller/
│   ├── ApplicationController.java    # Application REST endpoints
│   ├── SignatureController.java      # Signature REST endpoints
│   └── HealthController.java         # Health check endpoints
├── entity/
│   ├── ApplicationEntity.java        # Application JPA entity
│   ├── BeneficialOwnerEntity.java    # Beneficial owner entity
│   └── SignatureEntity.java          # Signature entity
├── exception/
│   └── GlobalExceptionHandler.java   # Global exception handling
├── model/
│   ├── ApplicationDTO.java           # Application data transfer object
│   ├── BusinessDetailsDTO.java       # Business details DTO
│   ├── ContactPersonDTO.java         # Contact person DTO
│   ├── SignatureDTO.java             # Signature DTO
│   ├── ApiResponse.java              # Standard API response wrapper
│   └── ...                           # Other DTOs
├── repository/
│   ├── ApplicationRepository.java    # Application JPA repository
│   ├── BeneficialOwnerRepository.java
│   └── SignatureRepository.java
└── service/
    ├── ApplicationService.java       # Application service interface
    ├── SignatureService.java         # Signature service interface
    └── impl/
        ├── ApplicationServiceImpl.java
        └── SignatureServiceImpl.java
```

## Getting Started

### Prerequisites

- Java 17 or higher
- Maven 3.6 or higher

### Running the Application

1. **Clone and navigate to the backend directory:**
   ```bash
   cd spring-boot-backend
   ```

2. **Build the project:**
   ```bash
   mvn clean install
   ```

3. **Run the application:**
   ```bash
   mvn spring-boot:run
   ```

4. **The API will be available at:** `http://localhost:8080`

### Running Tests

```bash
mvn test
```

## API Endpoints

### Applications

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/applications` | Get all applications |
| GET | `/api/applications/{id}` | Get application by ID |
| POST | `/api/applications` | Create new application |
| PUT | `/api/applications/{id}` | Update application |
| DELETE | `/api/applications/{id}` | Delete application |
| GET | `/api/applications/search?query=` | Search applications |
| GET | `/api/applications/status/{status}` | Get by status |
| PATCH | `/api/applications/{id}/status?status=` | Update status |
| POST | `/api/applications/draft` | Save as draft |
| POST | `/api/applications/{id}/submit` | Submit application |

### Signatures

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/signatures/{id}` | Get signature by ID |
| GET | `/api/signatures/application/{appId}` | Get signatures for app |
| POST | `/api/signatures` | Save signature |
| PUT | `/api/signatures/{id}` | Update signature |
| DELETE | `/api/signatures/{id}` | Delete signature |
| POST | `/api/signatures/application/{appId}/batch` | Batch save signatures |

### Health

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/health` | Health check |
| GET | `/api/info` | API information |

## H2 Console

Access the H2 database console at: `http://localhost:8080/h2-console`

- **JDBC URL:** `jdbc:h2:mem:accountdb`
- **Username:** `sa`
- **Password:** *(empty)*

## CORS Configuration

The API is configured to accept requests from:
- `http://localhost:5173` (Vite dev server)
- `http://localhost:3000`
- `http://localhost:8080`
- Lovable preview URLs

To add more origins, modify `CorsConfig.java`.

## Sample Request

### Create Application

```bash
curl -X POST http://localhost:8080/api/applications \
  -H "Content-Type: application/json" \
  -d '{
    "businessDetails": {
      "registeredName": "Test Company Pte Ltd",
      "registrationNumber": "202012345A",
      "natureOfBusiness": "Technology",
      "countryOfDomicile": "Singapore"
    },
    "primaryContact": {
      "fullName": "John Doe",
      "email": "john.doe@test.com",
      "mobileNumber": "+65 9123 4567"
    }
  }'
```

### Response Format

All API responses follow this structure:

```json
{
  "success": true,
  "message": "Operation successful",
  "data": { ... },
  "timestamp": "2024-01-15T10:30:00"
}
```

## Connecting to React Frontend

Update your React app's API client to point to this backend:

```typescript
// src/api/apiClient.ts
const API_BASE_URL = 'http://localhost:8080/api';

export const applicationApi = {
  getAll: () => fetch(`${API_BASE_URL}/applications`).then(r => r.json()),
  getById: (id: string) => fetch(`${API_BASE_URL}/applications/${id}`).then(r => r.json()),
  create: (data: any) => fetch(`${API_BASE_URL}/applications`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  }).then(r => r.json()),
  // ... etc
};
```

## License

MIT
