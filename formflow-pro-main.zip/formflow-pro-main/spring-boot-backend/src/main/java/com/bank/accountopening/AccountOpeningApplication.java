package com.bank.accountopening;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AccountOpeningApplication {

    public static void main(String[] args) {
        SpringApplication.run(AccountOpeningApplication.class, args);
    }
}
