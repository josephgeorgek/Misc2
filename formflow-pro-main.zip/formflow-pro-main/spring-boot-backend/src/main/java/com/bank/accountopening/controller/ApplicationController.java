package com.bank.accountopening.controller;

import com.bank.accountopening.entity.ApplicationEntity.ApplicationStatus;
import com.bank.accountopening.model.ApiResponse;
import com.bank.accountopening.model.ApplicationDTO;
import com.bank.accountopening.service.ApplicationService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/applications")
@RequiredArgsConstructor
@Slf4j
@CrossOrigin
public class ApplicationController {

    private final ApplicationService applicationService;

    /**
     * Create a new application
     */
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ApiResponse<ApplicationDTO>> createApplication(
            @Valid @RequestBody ApplicationDTO applicationDTO) {
        log.info("Creating new application");
        ApplicationDTO created = applicationService.createApplication(applicationDTO);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Application created successfully", created));
    }

    /**
     * Get all applications
     */
    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ApiResponse<List<ApplicationDTO>>> getAllApplications() {
        log.info("Fetching all applications");
        List<ApplicationDTO> applications = applicationService.getAllApplications();
        return ResponseEntity.ok(ApiResponse.success(applications));
    }

    /**
     * Get application by ID
     */
    @GetMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ApiResponse<ApplicationDTO>> getApplicationById(@PathVariable String id) {
        log.info("Fetching application with ID: {}", id);
        return applicationService.getApplicationById(id)
                .map(app -> ResponseEntity.ok(ApiResponse.success(app)))
                .orElse(ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(ApiResponse.error("Application not found")));
    }

    /**
     * Update an application
     */
    @PutMapping(value = "/{id}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ApiResponse<ApplicationDTO>> updateApplication(
            @PathVariable String id,
            @Valid @RequestBody ApplicationDTO applicationDTO) {
        log.info("Updating application with ID: {}", id);
        try {
            ApplicationDTO updated = applicationService.updateApplication(id, applicationDTO);
            return ResponseEntity.ok(ApiResponse.success("Application updated successfully", updated));
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(ApiResponse.error(e.getMessage()));
        }
    }

    /**
     * Delete an application
     */
    @DeleteMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ApiResponse<Void>> deleteApplication(@PathVariable String id) {
        log.info("Deleting application with ID: {}", id);
        applicationService.deleteApplication(id);
        return ResponseEntity.ok(ApiResponse.success("Application deleted successfully", null));
    }

    /**
     * Search applications
     */
    @GetMapping(value = "/search", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ApiResponse<List<ApplicationDTO>>> searchApplications(
            @RequestParam String query) {
        log.info("Searching applications with query: {}", query);
        List<ApplicationDTO> results = applicationService.searchApplications(query);
        return ResponseEntity.ok(ApiResponse.success(results));
    }

    /**
     * Get applications by status
     */
    @GetMapping(value = "/status/{status}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ApiResponse<List<ApplicationDTO>>> getApplicationsByStatus(
            @PathVariable String status) {
        log.info("Fetching applications with status: {}", status);
        try {
            ApplicationStatus appStatus = ApplicationStatus.valueOf(status.toUpperCase());
            List<ApplicationDTO> applications = applicationService.getApplicationsByStatus(appStatus);
            return ResponseEntity.ok(ApiResponse.success(applications));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Invalid status: " + status));
        }
    }

    /**
     * Update application status
     */
    @PatchMapping(value = "/{id}/status", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ApiResponse<ApplicationDTO>> updateApplicationStatus(
            @PathVariable String id,
            @RequestParam String status) {
        log.info("Updating status of application {} to {}", id, status);
        try {
            ApplicationStatus appStatus = ApplicationStatus.valueOf(status.toUpperCase());
            ApplicationDTO updated = applicationService.updateApplicationStatus(id, appStatus);
            return ResponseEntity.ok(ApiResponse.success("Status updated successfully", updated));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Invalid status: " + status));
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(ApiResponse.error(e.getMessage()));
        }
    }

    /**
     * Save application as draft
     */
    @PostMapping(value = "/draft", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ApiResponse<ApplicationDTO>> saveAsDraft(
            @Valid @RequestBody ApplicationDTO applicationDTO) {
        log.info("Saving application as draft");
        ApplicationDTO saved = applicationService.saveAsDraft(applicationDTO);
        return ResponseEntity.ok(ApiResponse.success("Draft saved successfully", saved));
    }

    /**
     * Submit application for review
     */
    @PostMapping(value = "/{id}/submit", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ApiResponse<ApplicationDTO>> submitApplication(@PathVariable String id) {
        log.info("Submitting application with ID: {}", id);
        try {
            ApplicationDTO submitted = applicationService.submitApplication(id);
            return ResponseEntity.ok(ApiResponse.success("Application submitted successfully", submitted));
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(ApiResponse.error(e.getMessage()));
        }
    }
}
