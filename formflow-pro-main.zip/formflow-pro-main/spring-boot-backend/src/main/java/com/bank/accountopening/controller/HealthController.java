package com.bank.accountopening.controller;

import com.bank.accountopening.model.ApiResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api")
@Slf4j
@CrossOrigin
public class HealthController {

    /**
     * Health check endpoint
     */
    @GetMapping(value = "/health", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ApiResponse<Map<String, String>>> healthCheck() {
        Map<String, String> health = new HashMap<>();
        health.put("status", "UP");
        health.put("service", "Account Opening API");
        health.put("version", "1.0.0");
        return ResponseEntity.ok(ApiResponse.success(health));
    }

    /**
     * API info endpoint
     */
    @GetMapping(value = "/info", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ApiResponse<Map<String, Object>>> apiInfo() {
        Map<String, Object> info = new HashMap<>();
        info.put("name", "Business Account Opening API");
        info.put("version", "1.0.0");
        info.put("description", "REST API for managing business account applications");
        
        Map<String, String> endpoints = new HashMap<>();
        endpoints.put("applications", "/api/applications");
        endpoints.put("signatures", "/api/signatures");
        endpoints.put("health", "/api/health");
        info.put("endpoints", endpoints);
        
        return ResponseEntity.ok(ApiResponse.success(info));
    }
}
