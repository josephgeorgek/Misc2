package com.bank.accountopening.controller;

import com.bank.accountopening.entity.SignatureEntity.SignatureType;
import com.bank.accountopening.model.ApiResponse;
import com.bank.accountopening.model.SignatureDTO;
import com.bank.accountopening.service.SignatureService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/signatures")
@RequiredArgsConstructor
@Slf4j
@CrossOrigin
public class SignatureController {

    private final SignatureService signatureService;

    /**
     * Save a new signature
     */
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ApiResponse<SignatureDTO>> saveSignature(
            @Valid @RequestBody SignatureDTO signatureDTO) {
        log.info("Saving signature for application: {}", signatureDTO.getApplicationId());
        SignatureDTO saved = signatureService.saveSignature(signatureDTO);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Signature saved successfully", saved));
    }

    /**
     * Get signature by ID
     */
    @GetMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ApiResponse<SignatureDTO>> getSignatureById(@PathVariable String id) {
        log.info("Fetching signature with ID: {}", id);
        return signatureService.getSignatureById(id)
                .map(sig -> ResponseEntity.ok(ApiResponse.success(sig)))
                .orElse(ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(ApiResponse.error("Signature not found")));
    }

    /**
     * Get all signatures for an application
     */
    @GetMapping(value = "/application/{applicationId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ApiResponse<List<SignatureDTO>>> getSignaturesByApplicationId(
            @PathVariable String applicationId) {
        log.info("Fetching signatures for application: {}", applicationId);
        List<SignatureDTO> signatures = signatureService.getSignaturesByApplicationId(applicationId);
        return ResponseEntity.ok(ApiResponse.success(signatures));
    }

    /**
     * Get signatures by application and type
     */
    @GetMapping(value = "/application/{applicationId}/type/{type}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ApiResponse<List<SignatureDTO>>> getSignaturesByApplicationAndType(
            @PathVariable String applicationId,
            @PathVariable String type) {
        log.info("Fetching {} signatures for application: {}", type, applicationId);
        try {
            SignatureType signatureType = SignatureType.valueOf(type.toUpperCase());
            List<SignatureDTO> signatures = signatureService.getSignaturesByApplicationAndType(applicationId, signatureType);
            return ResponseEntity.ok(ApiResponse.success(signatures));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Invalid signature type: " + type));
        }
    }

    /**
     * Update a signature
     */
    @PutMapping(value = "/{id}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ApiResponse<SignatureDTO>> updateSignature(
            @PathVariable String id,
            @Valid @RequestBody SignatureDTO signatureDTO) {
        log.info("Updating signature with ID: {}", id);
        try {
            SignatureDTO updated = signatureService.updateSignature(id, signatureDTO);
            return ResponseEntity.ok(ApiResponse.success("Signature updated successfully", updated));
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(ApiResponse.error(e.getMessage()));
        }
    }

    /**
     * Delete a signature
     */
    @DeleteMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ApiResponse<Void>> deleteSignature(@PathVariable String id) {
        log.info("Deleting signature with ID: {}", id);
        signatureService.deleteSignature(id);
        return ResponseEntity.ok(ApiResponse.success("Signature deleted successfully", null));
    }

    /**
     * Batch save signatures for an application
     */
    @PostMapping(value = "/application/{applicationId}/batch", 
                 consumes = MediaType.APPLICATION_JSON_VALUE, 
                 produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ApiResponse<List<SignatureDTO>>> batchSaveSignatures(
            @PathVariable String applicationId,
            @Valid @RequestBody List<SignatureDTO> signatures) {
        log.info("Batch saving {} signatures for application: {}", signatures.size(), applicationId);
        List<SignatureDTO> saved = signatureService.saveSignatures(applicationId, signatures);
        return ResponseEntity.ok(ApiResponse.success("Signatures saved successfully", saved));
    }
}
