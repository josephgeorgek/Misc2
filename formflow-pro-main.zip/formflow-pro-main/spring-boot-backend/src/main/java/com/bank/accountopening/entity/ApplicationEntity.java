package com.bank.accountopening.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "applications")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ApplicationEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @Column(name = "registered_name")
    private String registeredName;

    @Column(name = "registration_number")
    private String registrationNumber;

    @Column(name = "office_number")
    private String officeNumber;

    @Column(name = "fax_number")
    private String faxNumber;

    @Column(name = "nature_of_business")
    private String natureOfBusiness;

    @Column(name = "gst_registered")
    private Boolean gstRegistered;

    @Column(name = "country_of_domicile")
    private String countryOfDomicile;

    @Column(name = "business_type")
    private String businessType;

    // Primary Contact
    @Column(name = "primary_contact_name")
    private String primaryContactName;

    @Column(name = "primary_contact_email")
    private String primaryContactEmail;

    @Column(name = "primary_contact_mobile")
    private String primaryContactMobile;

    @Column(name = "primary_contact_nric")
    private String primaryContactNric;

    // Secondary Contact
    @Column(name = "secondary_contact_name")
    private String secondaryContactName;

    @Column(name = "secondary_contact_email")
    private String secondaryContactEmail;

    @Column(name = "secondary_contact_mobile")
    private String secondaryContactMobile;

    @Column(name = "secondary_contact_nric")
    private String secondaryContactNric;

    // Account Details
    @Column(name = "account_name")
    private String accountName;

    @Column(name = "mailing_address", length = 1000)
    private String mailingAddress;

    @Column(name = "paynow_signup")
    private Boolean payNowSignUp;

    @Column(name = "sgqr_signup")
    private Boolean sgqrSignUp;

    // Form Data as JSON (for complex nested structures)
    @Column(name = "form_data", columnDefinition = "CLOB")
    private String formDataJson;

    // Status
    @Column(name = "status")
    @Enumerated(EnumType.STRING)
    private ApplicationStatus status = ApplicationStatus.DRAFT;

    // Timestamps
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    public enum ApplicationStatus {
        DRAFT,
        SUBMITTED,
        PENDING,
        APPROVED,
        REJECTED
    }
}
