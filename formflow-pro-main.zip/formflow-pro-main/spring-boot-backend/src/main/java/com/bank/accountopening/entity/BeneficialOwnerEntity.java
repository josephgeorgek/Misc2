package com.bank.accountopening.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Entity
@Table(name = "beneficial_owners")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class BeneficialOwnerEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "application_id", nullable = false)
    private ApplicationEntity application;

    @Column(name = "full_name")
    private String fullName;

    @Column(name = "nric_passport")
    private String nricPassport;

    @Column(name = "designation")
    private String designation;

    @Column(name = "is_beneficial_owner")
    private Boolean isBeneficialOwner;

    @Column(name = "is_authorised_signatory")
    private Boolean isAuthorisedSignatory;

    @Column(name = "mobile_number")
    private String mobileNumber;

    @Column(name = "office_number")
    private String officeNumber;

    @Column(name = "email")
    private String email;

    @Column(name = "grouping")
    private String grouping;

    @Column(name = "signature", columnDefinition = "CLOB")
    private String signature;
}
