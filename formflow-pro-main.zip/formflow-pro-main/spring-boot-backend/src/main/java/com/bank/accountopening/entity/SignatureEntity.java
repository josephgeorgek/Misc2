package com.bank.accountopening.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "signatures")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class SignatureEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "application_id", nullable = false)
    private ApplicationEntity application;

    @Column(name = "signer_name")
    private String signerName;

    @Column(name = "signature_type")
    @Enumerated(EnumType.STRING)
    private SignatureType signatureType;

    @Column(name = "signature_data", columnDefinition = "CLOB")
    private String signatureData;

    @Column(name = "signed_at")
    private LocalDateTime signedAt;

    @Column(name = "page_number")
    private Integer pageNumber;

    @Column(name = "confidence")
    private Double confidence;

    public enum SignatureType {
        BENEFICIAL_OWNER,
        DIRECTOR,
        COMPANY_SECRETARY,
        AUTHORISED_PERSON,
        AGREEMENT,
        GIRO,
        DEBIT_CARD
    }
}
