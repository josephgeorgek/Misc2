package com.bank.accountopening.model;

import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AccountParticularsDTO {

    private List<String> sourceOfCapital;
    private String accountName;
    private String mailingAddress;
    private Boolean payNowSignUp;
    private Boolean sgqrSignUp;
    private String sgqrOption;
    private List<SGQROutletDTO> outlets;
}
