package com.bank.accountopening.model;

import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ApplicationDTO {

    private String id;
    private String status;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    // Business Details
    private BusinessDetailsDTO businessDetails;

    // Contact Persons
    private ContactPersonDTO primaryContact;
    private ContactPersonDTO secondaryContact;

    // Account Type
    private AccountTypeDTO accountType;

    // Account Particulars
    private AccountParticularsDTO accountParticulars;

    // Beneficial Owners
    private List<BeneficialOwnerDTO> beneficialOwners;

    // Signing Condition
    private SigningConditionDTO signingCondition;

    // Board Resolution
    private BoardResolutionDTO boardResolution;

    // Full form data as JSON string (for complex nested data)
    private String formDataJson;
}
