package com.bank.accountopening.model;

import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BeneficialOwnerDTO {

    private String id;
    private String fullName;
    private String nricPassport;
    private String designation;
    private Boolean isBeneficialOwner;
    private Boolean isAuthorisedSignatory;
    private String mobileNumber;
    private String officeNumber;
    private String email;
    private String grouping;
    private String signature;
}
