package com.bank.accountopening.model;

import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BoardResolutionDTO {

    private String companyName;
    private String meetingDate;
    private Boolean resolutionPassed;
    
    // Authorized activities
    private Boolean openCloseAccounts;
    private Boolean applyBankingServices;
    private Boolean appointAuthorisedUsers;
    private Boolean appointAuthorisedSignatories;
    private Boolean borrowingAndSecurity;
    private Boolean corporateCreditCard;
    private Boolean electronicSigning;
    
    // Schedule of Authorised Persons
    private List<AuthorisedPersonDTO> authorisedPersons;
    private String signingMandate;
    private String signingLimits;
    
    // Signatures
    private List<DirectorSignatureDTO> directorSignatures;
    private String companySecretarySignature;
    private String companySecretaryName;
    private String certificationDate;
}
