package com.bank.accountopening.model;

import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BusinessDetailsDTO {

    private String registeredName;
    private String registrationNumber;
    private String officeNumber;
    private String faxNumber;
    private String natureOfBusiness;
    private Boolean gstRegistered;
    private String countryOfDomicile;
    private String businessType;
}
