package com.bank.accountopening.model;

import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SGQROutletDTO {

    private String outletName;
    private String sgqrId;
    private String postalCode;
    private String levelUnit;
    private String terminalId;
    private String referenceNo;
}
