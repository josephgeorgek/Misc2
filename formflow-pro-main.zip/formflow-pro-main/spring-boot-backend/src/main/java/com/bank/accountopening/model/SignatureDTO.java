package com.bank.accountopening.model;

import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SignatureDTO {

    private String id;
    private String applicationId;
    private String signerName;
    private String signatureType;
    private String signatureData;
    private LocalDateTime signedAt;
    private Integer pageNumber;
    private Double confidence;
}
