package com.bank.accountopening.repository;

import com.bank.accountopening.entity.ApplicationEntity;
import com.bank.accountopening.entity.ApplicationEntity.ApplicationStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ApplicationRepository extends JpaRepository<ApplicationEntity, String> {

    List<ApplicationEntity> findByStatus(ApplicationStatus status);

    List<ApplicationEntity> findByRegisteredNameContainingIgnoreCase(String name);

    List<ApplicationEntity> findByRegistrationNumberContainingIgnoreCase(String registrationNumber);

    @Query("SELECT a FROM ApplicationEntity a WHERE " +
           "LOWER(a.registeredName) LIKE LOWER(CONCAT('%', :query, '%')) OR " +
           "LOWER(a.registrationNumber) LIKE LOWER(CONCAT('%', :query, '%'))")
    List<ApplicationEntity> searchApplications(@Param("query") String query);

    List<ApplicationEntity> findAllByOrderByUpdatedAtDesc();
}
