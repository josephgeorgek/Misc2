package com.bank.accountopening.repository;

import com.bank.accountopening.entity.BeneficialOwnerEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BeneficialOwnerRepository extends JpaRepository<BeneficialOwnerEntity, String> {

    List<BeneficialOwnerEntity> findByApplicationId(String applicationId);

    void deleteByApplicationId(String applicationId);
}
