package com.bank.accountopening.repository;

import com.bank.accountopening.entity.SignatureEntity;
import com.bank.accountopening.entity.SignatureEntity.SignatureType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SignatureRepository extends JpaRepository<SignatureEntity, String> {

    List<SignatureEntity> findByApplicationId(String applicationId);

    List<SignatureEntity> findByApplicationIdAndSignatureType(String applicationId, SignatureType signatureType);

    void deleteByApplicationId(String applicationId);
}
