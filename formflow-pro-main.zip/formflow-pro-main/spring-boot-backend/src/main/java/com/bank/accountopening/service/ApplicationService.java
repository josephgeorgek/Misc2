package com.bank.accountopening.service;

import com.bank.accountopening.entity.ApplicationEntity.ApplicationStatus;
import com.bank.accountopening.model.ApplicationDTO;

import java.util.List;
import java.util.Optional;

public interface ApplicationService {

    /**
     * Create a new application
     */
    ApplicationDTO createApplication(ApplicationDTO applicationDTO);

    /**
     * Get application by ID
     */
    Optional<ApplicationDTO> getApplicationById(String id);

    /**
     * Get all applications
     */
    List<ApplicationDTO> getAllApplications();

    /**
     * Update an existing application
     */
    ApplicationDTO updateApplication(String id, ApplicationDTO applicationDTO);

    /**
     * Delete an application
     */
    void deleteApplication(String id);

    /**
     * Search applications by query (name or registration number)
     */
    List<ApplicationDTO> searchApplications(String query);

    /**
     * Get applications by status
     */
    List<ApplicationDTO> getApplicationsByStatus(ApplicationStatus status);

    /**
     * Update application status
     */
    ApplicationDTO updateApplicationStatus(String id, ApplicationStatus status);

    /**
     * Save application as draft
     */
    ApplicationDTO saveAsDraft(ApplicationDTO applicationDTO);

    /**
     * Submit application for review
     */
    ApplicationDTO submitApplication(String id);
}
