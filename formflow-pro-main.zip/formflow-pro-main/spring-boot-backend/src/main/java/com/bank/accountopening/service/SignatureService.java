package com.bank.accountopening.service;

import com.bank.accountopening.entity.SignatureEntity.SignatureType;
import com.bank.accountopening.model.SignatureDTO;

import java.util.List;
import java.util.Optional;

public interface SignatureService {

    /**
     * Save a signature for an application
     */
    SignatureDTO saveSignature(SignatureDTO signatureDTO);

    /**
     * Get signature by ID
     */
    Optional<SignatureDTO> getSignatureById(String id);

    /**
     * Get all signatures for an application
     */
    List<SignatureDTO> getSignaturesByApplicationId(String applicationId);

    /**
     * Get signatures by application and type
     */
    List<SignatureDTO> getSignaturesByApplicationAndType(String applicationId, SignatureType type);

    /**
     * Update a signature
     */
    SignatureDTO updateSignature(String id, SignatureDTO signatureDTO);

    /**
     * Delete a signature
     */
    void deleteSignature(String id);

    /**
     * Delete all signatures for an application
     */
    void deleteSignaturesByApplicationId(String applicationId);

    /**
     * Batch save signatures for an application
     */
    List<SignatureDTO> saveSignatures(String applicationId, List<SignatureDTO> signatures);
}
