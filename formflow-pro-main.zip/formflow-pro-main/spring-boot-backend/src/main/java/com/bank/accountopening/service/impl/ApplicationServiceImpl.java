package com.bank.accountopening.service.impl;

import com.bank.accountopening.entity.ApplicationEntity;
import com.bank.accountopening.entity.ApplicationEntity.ApplicationStatus;
import com.bank.accountopening.model.ApplicationDTO;
import com.bank.accountopening.model.BusinessDetailsDTO;
import com.bank.accountopening.model.ContactPersonDTO;
import com.bank.accountopening.repository.ApplicationRepository;
import com.bank.accountopening.service.ApplicationService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class ApplicationServiceImpl implements ApplicationService {

    private final ApplicationRepository applicationRepository;
    private final ObjectMapper objectMapper;

    @Override
    public ApplicationDTO createApplication(ApplicationDTO applicationDTO) {
        ApplicationEntity entity = mapToEntity(applicationDTO);
        entity.setStatus(ApplicationStatus.DRAFT);
        ApplicationEntity saved = applicationRepository.save(entity);
        log.info("Created new application with ID: {}", saved.getId());
        return mapToDTO(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<ApplicationDTO> getApplicationById(String id) {
        return applicationRepository.findById(id).map(this::mapToDTO);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ApplicationDTO> getAllApplications() {
        return applicationRepository.findAllByOrderByUpdatedAtDesc()
                .stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public ApplicationDTO updateApplication(String id, ApplicationDTO applicationDTO) {
        ApplicationEntity existing = applicationRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Application not found: " + id));
        
        updateEntityFromDTO(existing, applicationDTO);
        ApplicationEntity saved = applicationRepository.save(existing);
        log.info("Updated application with ID: {}", saved.getId());
        return mapToDTO(saved);
    }

    @Override
    public void deleteApplication(String id) {
        applicationRepository.deleteById(id);
        log.info("Deleted application with ID: {}", id);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ApplicationDTO> searchApplications(String query) {
        return applicationRepository.searchApplications(query)
                .stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<ApplicationDTO> getApplicationsByStatus(ApplicationStatus status) {
        return applicationRepository.findByStatus(status)
                .stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public ApplicationDTO updateApplicationStatus(String id, ApplicationStatus status) {
        ApplicationEntity entity = applicationRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Application not found: " + id));
        entity.setStatus(status);
        ApplicationEntity saved = applicationRepository.save(entity);
        log.info("Updated status of application {} to {}", id, status);
        return mapToDTO(saved);
    }

    @Override
    public ApplicationDTO saveAsDraft(ApplicationDTO applicationDTO) {
        if (applicationDTO.getId() != null) {
            return updateApplication(applicationDTO.getId(), applicationDTO);
        } else {
            return createApplication(applicationDTO);
        }
    }

    @Override
    public ApplicationDTO submitApplication(String id) {
        return updateApplicationStatus(id, ApplicationStatus.SUBMITTED);
    }

    // Mapping methods
    private ApplicationEntity mapToEntity(ApplicationDTO dto) {
        ApplicationEntity entity = new ApplicationEntity();
        updateEntityFromDTO(entity, dto);
        return entity;
    }

    private void updateEntityFromDTO(ApplicationEntity entity, ApplicationDTO dto) {
        if (dto.getBusinessDetails() != null) {
            BusinessDetailsDTO bd = dto.getBusinessDetails();
            entity.setRegisteredName(bd.getRegisteredName());
            entity.setRegistrationNumber(bd.getRegistrationNumber());
            entity.setOfficeNumber(bd.getOfficeNumber());
            entity.setFaxNumber(bd.getFaxNumber());
            entity.setNatureOfBusiness(bd.getNatureOfBusiness());
            entity.setGstRegistered(bd.getGstRegistered());
            entity.setCountryOfDomicile(bd.getCountryOfDomicile());
            entity.setBusinessType(bd.getBusinessType());
        }

        if (dto.getPrimaryContact() != null) {
            ContactPersonDTO pc = dto.getPrimaryContact();
            entity.setPrimaryContactName(pc.getFullName());
            entity.setPrimaryContactEmail(pc.getEmail());
            entity.setPrimaryContactMobile(pc.getMobileNumber());
            entity.setPrimaryContactNric(pc.getNricPassport());
        }

        if (dto.getSecondaryContact() != null) {
            ContactPersonDTO sc = dto.getSecondaryContact();
            entity.setSecondaryContactName(sc.getFullName());
            entity.setSecondaryContactEmail(sc.getEmail());
            entity.setSecondaryContactMobile(sc.getMobileNumber());
            entity.setSecondaryContactNric(sc.getNricPassport());
        }

        if (dto.getAccountParticulars() != null) {
            entity.setAccountName(dto.getAccountParticulars().getAccountName());
            entity.setMailingAddress(dto.getAccountParticulars().getMailingAddress());
            entity.setPayNowSignUp(dto.getAccountParticulars().getPayNowSignUp());
            entity.setSgqrSignUp(dto.getAccountParticulars().getSgqrSignUp());
        }

        // Store full form data as JSON
        if (dto.getFormDataJson() != null) {
            entity.setFormDataJson(dto.getFormDataJson());
        } else {
            try {
                entity.setFormDataJson(objectMapper.writeValueAsString(dto));
            } catch (JsonProcessingException e) {
                log.error("Failed to serialize form data", e);
            }
        }

        if (dto.getStatus() != null) {
            entity.setStatus(ApplicationStatus.valueOf(dto.getStatus().toUpperCase()));
        }
    }

    private ApplicationDTO mapToDTO(ApplicationEntity entity) {
        ApplicationDTO dto = new ApplicationDTO();
        dto.setId(entity.getId());
        dto.setStatus(entity.getStatus() != null ? entity.getStatus().name() : null);
        dto.setCreatedAt(entity.getCreatedAt());
        dto.setUpdatedAt(entity.getUpdatedAt());

        // Business Details
        dto.setBusinessDetails(BusinessDetailsDTO.builder()
                .registeredName(entity.getRegisteredName())
                .registrationNumber(entity.getRegistrationNumber())
                .officeNumber(entity.getOfficeNumber())
                .faxNumber(entity.getFaxNumber())
                .natureOfBusiness(entity.getNatureOfBusiness())
                .gstRegistered(entity.getGstRegistered())
                .countryOfDomicile(entity.getCountryOfDomicile())
                .businessType(entity.getBusinessType())
                .build());

        // Primary Contact
        dto.setPrimaryContact(ContactPersonDTO.builder()
                .fullName(entity.getPrimaryContactName())
                .email(entity.getPrimaryContactEmail())
                .mobileNumber(entity.getPrimaryContactMobile())
                .nricPassport(entity.getPrimaryContactNric())
                .build());

        // Secondary Contact
        dto.setSecondaryContact(ContactPersonDTO.builder()
                .fullName(entity.getSecondaryContactName())
                .email(entity.getSecondaryContactEmail())
                .mobileNumber(entity.getSecondaryContactMobile())
                .nricPassport(entity.getSecondaryContactNric())
                .build());

        // Form Data JSON
        dto.setFormDataJson(entity.getFormDataJson());

        return dto;
    }
}
