package com.bank.accountopening.service.impl;

import com.bank.accountopening.entity.ApplicationEntity;
import com.bank.accountopening.entity.SignatureEntity;
import com.bank.accountopening.entity.SignatureEntity.SignatureType;
import com.bank.accountopening.model.SignatureDTO;
import com.bank.accountopening.repository.ApplicationRepository;
import com.bank.accountopening.repository.SignatureRepository;
import com.bank.accountopening.service.SignatureService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class SignatureServiceImpl implements SignatureService {

    private final SignatureRepository signatureRepository;
    private final ApplicationRepository applicationRepository;

    @Override
    public SignatureDTO saveSignature(SignatureDTO signatureDTO) {
        ApplicationEntity application = applicationRepository.findById(signatureDTO.getApplicationId())
                .orElseThrow(() -> new RuntimeException("Application not found: " + signatureDTO.getApplicationId()));

        SignatureEntity entity = mapToEntity(signatureDTO, application);
        entity.setSignedAt(LocalDateTime.now());
        SignatureEntity saved = signatureRepository.save(entity);
        log.info("Saved signature with ID: {}", saved.getId());
        return mapToDTO(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<SignatureDTO> getSignatureById(String id) {
        return signatureRepository.findById(id).map(this::mapToDTO);
    }

    @Override
    @Transactional(readOnly = true)
    public List<SignatureDTO> getSignaturesByApplicationId(String applicationId) {
        return signatureRepository.findByApplicationId(applicationId)
                .stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<SignatureDTO> getSignaturesByApplicationAndType(String applicationId, SignatureType type) {
        return signatureRepository.findByApplicationIdAndSignatureType(applicationId, type)
                .stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public SignatureDTO updateSignature(String id, SignatureDTO signatureDTO) {
        SignatureEntity existing = signatureRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Signature not found: " + id));

        existing.setSignerName(signatureDTO.getSignerName());
        existing.setSignatureData(signatureDTO.getSignatureData());
        if (signatureDTO.getSignatureType() != null) {
            existing.setSignatureType(SignatureType.valueOf(signatureDTO.getSignatureType()));
        }
        existing.setPageNumber(signatureDTO.getPageNumber());
        existing.setConfidence(signatureDTO.getConfidence());

        SignatureEntity saved = signatureRepository.save(existing);
        log.info("Updated signature with ID: {}", saved.getId());
        return mapToDTO(saved);
    }

    @Override
    public void deleteSignature(String id) {
        signatureRepository.deleteById(id);
        log.info("Deleted signature with ID: {}", id);
    }

    @Override
    public void deleteSignaturesByApplicationId(String applicationId) {
        signatureRepository.deleteByApplicationId(applicationId);
        log.info("Deleted all signatures for application: {}", applicationId);
    }

    @Override
    public List<SignatureDTO> saveSignatures(String applicationId, List<SignatureDTO> signatures) {
        ApplicationEntity application = applicationRepository.findById(applicationId)
                .orElseThrow(() -> new RuntimeException("Application not found: " + applicationId));

        // Delete existing signatures
        signatureRepository.deleteByApplicationId(applicationId);

        // Save new signatures
        List<SignatureEntity> entities = signatures.stream()
                .map(dto -> {
                    SignatureEntity entity = mapToEntity(dto, application);
                    entity.setSignedAt(LocalDateTime.now());
                    return entity;
                })
                .collect(Collectors.toList());

        List<SignatureEntity> saved = signatureRepository.saveAll(entities);
        log.info("Saved {} signatures for application: {}", saved.size(), applicationId);

        return saved.stream().map(this::mapToDTO).collect(Collectors.toList());
    }

    // Mapping methods
    private SignatureEntity mapToEntity(SignatureDTO dto, ApplicationEntity application) {
        SignatureEntity entity = new SignatureEntity();
        entity.setApplication(application);
        entity.setSignerName(dto.getSignerName());
        entity.setSignatureData(dto.getSignatureData());
        if (dto.getSignatureType() != null) {
            entity.setSignatureType(SignatureType.valueOf(dto.getSignatureType()));
        }
        entity.setPageNumber(dto.getPageNumber());
        entity.setConfidence(dto.getConfidence());
        return entity;
    }

    private SignatureDTO mapToDTO(SignatureEntity entity) {
        return SignatureDTO.builder()
                .id(entity.getId())
                .applicationId(entity.getApplication().getId())
                .signerName(entity.getSignerName())
                .signatureType(entity.getSignatureType() != null ? entity.getSignatureType().name() : null)
                .signatureData(entity.getSignatureData())
                .signedAt(entity.getSignedAt())
                .pageNumber(entity.getPageNumber())
                .confidence(entity.getConfidence())
                .build();
    }
}
