package com.bank.accountopening;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccountOpeningApplicationTests {

    @Test
    void contextLoads() {
        // Verify that the Spring application context loads successfully
    }
}
