package com.bank.accountopening.controller;

import com.bank.accountopening.model.ApplicationDTO;
import com.bank.accountopening.model.BusinessDetailsDTO;
import com.bank.accountopening.model.ContactPersonDTO;
import com.bank.accountopening.service.ApplicationService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ApplicationController.class)
class ApplicationControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private ApplicationService applicationService;

    private ApplicationDTO testApplication;

    @BeforeEach
    void setUp() {
        testApplication = ApplicationDTO.builder()
                .id("test-id-123")
                .status("DRAFT")
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .businessDetails(BusinessDetailsDTO.builder()
                        .registeredName("Test Company Pte Ltd")
                        .registrationNumber("202012345A")
                        .officeNumber("+65 6123 4567")
                        .natureOfBusiness("Technology")
                        .countryOfDomicile("Singapore")
                        .build())
                .primaryContact(ContactPersonDTO.builder()
                        .fullName("John Doe")
                        .email("john.doe@test.com")
                        .mobileNumber("+65 9123 4567")
                        .nricPassport("S1234567A")
                        .build())
                .build();
    }

    @Test
    void createApplication_ShouldReturnCreatedApplication() throws Exception {
        when(applicationService.createApplication(any(ApplicationDTO.class)))
                .thenReturn(testApplication);

        mockMvc.perform(post("/api/applications")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(testApplication)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.id").value("test-id-123"))
                .andExpect(jsonPath("$.data.businessDetails.registeredName").value("Test Company Pte Ltd"));

        verify(applicationService, times(1)).createApplication(any(ApplicationDTO.class));
    }

    @Test
    void getAllApplications_ShouldReturnListOfApplications() throws Exception {
        List<ApplicationDTO> applications = Arrays.asList(testApplication);
        when(applicationService.getAllApplications()).thenReturn(applications);

        mockMvc.perform(get("/api/applications"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data").isArray())
                .andExpect(jsonPath("$.data[0].id").value("test-id-123"));

        verify(applicationService, times(1)).getAllApplications();
    }

    @Test
    void getApplicationById_WhenExists_ShouldReturnApplication() throws Exception {
        when(applicationService.getApplicationById("test-id-123"))
                .thenReturn(Optional.of(testApplication));

        mockMvc.perform(get("/api/applications/test-id-123"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.id").value("test-id-123"))
                .andExpect(jsonPath("$.data.businessDetails.registeredName").value("Test Company Pte Ltd"));

        verify(applicationService, times(1)).getApplicationById("test-id-123");
    }

    @Test
    void getApplicationById_WhenNotExists_ShouldReturn404() throws Exception {
        when(applicationService.getApplicationById("non-existent"))
                .thenReturn(Optional.empty());

        mockMvc.perform(get("/api/applications/non-existent"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("Application not found"));

        verify(applicationService, times(1)).getApplicationById("non-existent");
    }

    @Test
    void updateApplication_ShouldReturnUpdatedApplication() throws Exception {
        ApplicationDTO updatedApp = ApplicationDTO.builder()
                .id("test-id-123")
                .status("SUBMITTED")
                .businessDetails(BusinessDetailsDTO.builder()
                        .registeredName("Updated Company Pte Ltd")
                        .build())
                .build();

        when(applicationService.updateApplication(eq("test-id-123"), any(ApplicationDTO.class)))
                .thenReturn(updatedApp);

        mockMvc.perform(put("/api/applications/test-id-123")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updatedApp)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.businessDetails.registeredName").value("Updated Company Pte Ltd"));

        verify(applicationService, times(1)).updateApplication(eq("test-id-123"), any(ApplicationDTO.class));
    }

    @Test
    void deleteApplication_ShouldReturnSuccess() throws Exception {
        doNothing().when(applicationService).deleteApplication("test-id-123");

        mockMvc.perform(delete("/api/applications/test-id-123"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("Application deleted successfully"));

        verify(applicationService, times(1)).deleteApplication("test-id-123");
    }

    @Test
    void searchApplications_ShouldReturnMatchingApplications() throws Exception {
        List<ApplicationDTO> results = Arrays.asList(testApplication);
        when(applicationService.searchApplications("Test")).thenReturn(results);

        mockMvc.perform(get("/api/applications/search")
                        .param("query", "Test"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data").isArray())
                .andExpect(jsonPath("$.data[0].businessDetails.registeredName").value("Test Company Pte Ltd"));

        verify(applicationService, times(1)).searchApplications("Test");
    }

    @Test
    void submitApplication_ShouldReturnSubmittedApplication() throws Exception {
        ApplicationDTO submittedApp = ApplicationDTO.builder()
                .id("test-id-123")
                .status("SUBMITTED")
                .build();

        when(applicationService.submitApplication("test-id-123"))
                .thenReturn(submittedApp);

        mockMvc.perform(post("/api/applications/test-id-123/submit"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.status").value("SUBMITTED"));

        verify(applicationService, times(1)).submitApplication("test-id-123");
    }
}
