package com.bank.accountopening.controller;

import com.bank.accountopening.model.SignatureDTO;
import com.bank.accountopening.service.SignatureService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(SignatureController.class)
class SignatureControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private SignatureService signatureService;

    private SignatureDTO testSignature;

    @BeforeEach
    void setUp() {
        testSignature = SignatureDTO.builder()
                .id("sig-123")
                .applicationId("app-123")
                .signerName("John Doe")
                .signatureType("DIRECTOR")
                .signatureData("data:image/png;base64,iVBORw0KGgo...")
                .signedAt(LocalDateTime.now())
                .pageNumber(1)
                .confidence(0.85)
                .build();
    }

    @Test
    void saveSignature_ShouldReturnSavedSignature() throws Exception {
        when(signatureService.saveSignature(any(SignatureDTO.class)))
                .thenReturn(testSignature);

        mockMvc.perform(post("/api/signatures")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(testSignature)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.id").value("sig-123"))
                .andExpect(jsonPath("$.data.signerName").value("John Doe"));

        verify(signatureService, times(1)).saveSignature(any(SignatureDTO.class));
    }

    @Test
    void getSignatureById_WhenExists_ShouldReturnSignature() throws Exception {
        when(signatureService.getSignatureById("sig-123"))
                .thenReturn(Optional.of(testSignature));

        mockMvc.perform(get("/api/signatures/sig-123"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.id").value("sig-123"));

        verify(signatureService, times(1)).getSignatureById("sig-123");
    }

    @Test
    void getSignatureById_WhenNotExists_ShouldReturn404() throws Exception {
        when(signatureService.getSignatureById("non-existent"))
                .thenReturn(Optional.empty());

        mockMvc.perform(get("/api/signatures/non-existent"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.success").value(false));

        verify(signatureService, times(1)).getSignatureById("non-existent");
    }

    @Test
    void getSignaturesByApplicationId_ShouldReturnSignatures() throws Exception {
        List<SignatureDTO> signatures = Arrays.asList(testSignature);
        when(signatureService.getSignaturesByApplicationId("app-123"))
                .thenReturn(signatures);

        mockMvc.perform(get("/api/signatures/application/app-123"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data").isArray())
                .andExpect(jsonPath("$.data[0].id").value("sig-123"));

        verify(signatureService, times(1)).getSignaturesByApplicationId("app-123");
    }

    @Test
    void updateSignature_ShouldReturnUpdatedSignature() throws Exception {
        SignatureDTO updatedSig = SignatureDTO.builder()
                .id("sig-123")
                .signerName("Jane Doe")
                .signatureType("DIRECTOR")
                .build();

        when(signatureService.updateSignature(eq("sig-123"), any(SignatureDTO.class)))
                .thenReturn(updatedSig);

        mockMvc.perform(put("/api/signatures/sig-123")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updatedSig)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.signerName").value("Jane Doe"));

        verify(signatureService, times(1)).updateSignature(eq("sig-123"), any(SignatureDTO.class));
    }

    @Test
    void deleteSignature_ShouldReturnSuccess() throws Exception {
        doNothing().when(signatureService).deleteSignature("sig-123");

        mockMvc.perform(delete("/api/signatures/sig-123"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("Signature deleted successfully"));

        verify(signatureService, times(1)).deleteSignature("sig-123");
    }

    @Test
    void batchSaveSignatures_ShouldReturnSavedSignatures() throws Exception {
        List<SignatureDTO> signatures = Arrays.asList(testSignature);
        when(signatureService.saveSignatures(eq("app-123"), any()))
                .thenReturn(signatures);

        mockMvc.perform(post("/api/signatures/application/app-123/batch")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(signatures)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data").isArray());

        verify(signatureService, times(1)).saveSignatures(eq("app-123"), any());
    }
}
