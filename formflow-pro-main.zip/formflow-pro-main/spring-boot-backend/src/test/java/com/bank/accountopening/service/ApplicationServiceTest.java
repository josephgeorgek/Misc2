package com.bank.accountopening.service;

import com.bank.accountopening.entity.ApplicationEntity;
import com.bank.accountopening.entity.ApplicationEntity.ApplicationStatus;
import com.bank.accountopening.model.ApplicationDTO;
import com.bank.accountopening.model.BusinessDetailsDTO;
import com.bank.accountopening.repository.ApplicationRepository;
import com.bank.accountopening.service.impl.ApplicationServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ApplicationServiceTest {

    @Mock
    private ApplicationRepository applicationRepository;

    @Mock
    private ObjectMapper objectMapper;

    @InjectMocks
    private ApplicationServiceImpl applicationService;

    private ApplicationEntity testEntity;
    private ApplicationDTO testDTO;

    @BeforeEach
    void setUp() {
        testEntity = new ApplicationEntity();
        testEntity.setId("test-id-123");
        testEntity.setRegisteredName("Test Company Pte Ltd");
        testEntity.setRegistrationNumber("202012345A");
        testEntity.setStatus(ApplicationStatus.DRAFT);
        testEntity.setCreatedAt(LocalDateTime.now());
        testEntity.setUpdatedAt(LocalDateTime.now());

        testDTO = ApplicationDTO.builder()
                .id("test-id-123")
                .status("DRAFT")
                .businessDetails(BusinessDetailsDTO.builder()
                        .registeredName("Test Company Pte Ltd")
                        .registrationNumber("202012345A")
                        .build())
                .build();
    }

    @Test
    void createApplication_ShouldReturnCreatedApplication() {
        when(applicationRepository.save(any(ApplicationEntity.class)))
                .thenReturn(testEntity);

        ApplicationDTO result = applicationService.createApplication(testDTO);

        assertNotNull(result);
        assertEquals("test-id-123", result.getId());
        verify(applicationRepository, times(1)).save(any(ApplicationEntity.class));
    }

    @Test
    void getApplicationById_WhenExists_ShouldReturnApplication() {
        when(applicationRepository.findById("test-id-123"))
                .thenReturn(Optional.of(testEntity));

        Optional<ApplicationDTO> result = applicationService.getApplicationById("test-id-123");

        assertTrue(result.isPresent());
        assertEquals("Test Company Pte Ltd", result.get().getBusinessDetails().getRegisteredName());
        verify(applicationRepository, times(1)).findById("test-id-123");
    }

    @Test
    void getApplicationById_WhenNotExists_ShouldReturnEmpty() {
        when(applicationRepository.findById("non-existent"))
                .thenReturn(Optional.empty());

        Optional<ApplicationDTO> result = applicationService.getApplicationById("non-existent");

        assertFalse(result.isPresent());
        verify(applicationRepository, times(1)).findById("non-existent");
    }

    @Test
    void getAllApplications_ShouldReturnListOfApplications() {
        List<ApplicationEntity> entities = Arrays.asList(testEntity);
        when(applicationRepository.findAllByOrderByUpdatedAtDesc())
                .thenReturn(entities);

        List<ApplicationDTO> result = applicationService.getAllApplications();

        assertFalse(result.isEmpty());
        assertEquals(1, result.size());
        verify(applicationRepository, times(1)).findAllByOrderByUpdatedAtDesc();
    }

    @Test
    void updateApplication_ShouldReturnUpdatedApplication() {
        when(applicationRepository.findById("test-id-123"))
                .thenReturn(Optional.of(testEntity));
        when(applicationRepository.save(any(ApplicationEntity.class)))
                .thenReturn(testEntity);

        ApplicationDTO result = applicationService.updateApplication("test-id-123", testDTO);

        assertNotNull(result);
        verify(applicationRepository, times(1)).findById("test-id-123");
        verify(applicationRepository, times(1)).save(any(ApplicationEntity.class));
    }

    @Test
    void updateApplication_WhenNotExists_ShouldThrowException() {
        when(applicationRepository.findById("non-existent"))
                .thenReturn(Optional.empty());

        assertThrows(RuntimeException.class, () ->
                applicationService.updateApplication("non-existent", testDTO));

        verify(applicationRepository, times(1)).findById("non-existent");
        verify(applicationRepository, never()).save(any(ApplicationEntity.class));
    }

    @Test
    void deleteApplication_ShouldDeleteSuccessfully() {
        doNothing().when(applicationRepository).deleteById("test-id-123");

        applicationService.deleteApplication("test-id-123");

        verify(applicationRepository, times(1)).deleteById("test-id-123");
    }

    @Test
    void searchApplications_ShouldReturnMatchingApplications() {
        List<ApplicationEntity> entities = Arrays.asList(testEntity);
        when(applicationRepository.searchApplications("Test"))
                .thenReturn(entities);

        List<ApplicationDTO> result = applicationService.searchApplications("Test");

        assertFalse(result.isEmpty());
        verify(applicationRepository, times(1)).searchApplications("Test");
    }

    @Test
    void updateApplicationStatus_ShouldReturnUpdatedApplication() {
        when(applicationRepository.findById("test-id-123"))
                .thenReturn(Optional.of(testEntity));
        when(applicationRepository.save(any(ApplicationEntity.class)))
                .thenReturn(testEntity);

        ApplicationDTO result = applicationService.updateApplicationStatus("test-id-123", ApplicationStatus.SUBMITTED);

        assertNotNull(result);
        verify(applicationRepository, times(1)).save(any(ApplicationEntity.class));
    }

    @Test
    void submitApplication_ShouldSetStatusToSubmitted() {
        testEntity.setStatus(ApplicationStatus.SUBMITTED);
        when(applicationRepository.findById("test-id-123"))
                .thenReturn(Optional.of(testEntity));
        when(applicationRepository.save(any(ApplicationEntity.class)))
                .thenReturn(testEntity);

        ApplicationDTO result = applicationService.submitApplication("test-id-123");

        assertNotNull(result);
        verify(applicationRepository, times(1)).save(any(ApplicationEntity.class));
    }
}
