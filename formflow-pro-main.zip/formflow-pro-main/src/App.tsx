import { ThemeProvider, CssBaseline } from '@mui/material';
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import theme from "./theme/theme";
import MainLayout from "./layouts/MainLayout";
import LandingMUI from "./pages/LandingMUI";
import IndexMUI from "./pages/IndexMUI";
import ViewApplication from "./pages/ViewApplication";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <BrowserRouter>
        <MainLayout>
          <Routes>
            <Route path="/" element={<LandingMUI />} />
            <Route path="/new" element={<IndexMUI />} />
            <Route path="/view/:id" element={<ViewApplication />} />
            <Route path="/edit/:id" element={<IndexMUI />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </MainLayout>
      </BrowserRouter>
    </ThemeProvider>
  </QueryClientProvider>
);

export default App;
