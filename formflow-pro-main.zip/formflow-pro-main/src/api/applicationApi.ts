import { api } from './apiClient';
import { DraftApplication } from '@/data/drafts';
import { AgreementSignature, FormData } from '@/types/form';

// Response types matching Spring Boot backend
interface ApiResponse<T> {
  success: boolean;
  data: T;
  message: string;
  timestamp: string;
}

interface ApplicationDTO {
  id: string;
  companyName: string;
  uen: string;
  status: string;
  formData: FormData;
  createdAt: string;
  updatedAt: string;
  submittedAt?: string;
}

interface SignatureDTO {
  id: string;
  applicationId: string;
  signatoryName: string;
  signatureData: string;
  signedAt: string;
  signatureType: string;
}

// Check if backend is available
let backendAvailable: boolean | null = null;
let lastHealthCheck: number = 0;
const HEALTH_CHECK_INTERVAL = 30000; // 30 seconds

export async function checkBackendHealth(): Promise<boolean> {
  const now = Date.now();
  
  // Use cached result if recent
  if (backendAvailable !== null && (now - lastHealthCheck) < HEALTH_CHECK_INTERVAL) {
    return backendAvailable;
  }

  try {
    const response = await api.get<ApiResponse<{ status: string }>>('/health', {
      timeout: 5000, // Quick timeout for health check
    });
    backendAvailable = response.data.success;
    lastHealthCheck = now;
    console.log('[API] Backend health check:', backendAvailable ? 'available' : 'unavailable');
    return backendAvailable;
  } catch (error) {
    backendAvailable = false;
    lastHealthCheck = now;
    console.log('[API] Backend not available, using localStorage fallback');
    return false;
  }
}

// Force re-check backend availability
export function resetBackendCheck(): void {
  backendAvailable = null;
  lastHealthCheck = 0;
}

// Convert backend DTO to frontend DraftApplication
function dtoToDraft(dto: ApplicationDTO): DraftApplication {
  return {
    id: dto.id,
    status: dto.status as DraftApplication['status'],
    ...dto.formData,
    createdAt: dto.createdAt,
    updatedAt: dto.updatedAt,
  };
}

// Convert frontend DraftApplication to backend DTO
function draftToDto(draft: DraftApplication): Partial<ApplicationDTO> {
  const { id, status, createdAt, updatedAt, ...formData } = draft;
  return {
    id,
    companyName: draft.businessDetails?.registeredName || '',
    uen: draft.businessDetails?.registrationNumber || '',
    status,
    formData: formData as FormData,
    createdAt,
    updatedAt,
  };
}

// Application API calls
export const applicationApi = {
  // Get all applications
  async getAll(): Promise<DraftApplication[]> {
    const response = await api.get<ApiResponse<ApplicationDTO[]>>('/applications');
    return response.data.data.map(dtoToDraft);
  },

  // Get application by ID
  async getById(id: string): Promise<DraftApplication | null> {
    try {
      const response = await api.get<ApiResponse<ApplicationDTO>>(`/applications/${id}`);
      return dtoToDraft(response.data.data);
    } catch (error) {
      return null;
    }
  },

  // Search applications
  async search(query: string): Promise<DraftApplication[]> {
    const response = await api.get<ApiResponse<ApplicationDTO[]>>('/applications/search', {
      params: { query },
    });
    return response.data.data.map(dtoToDraft);
  },

  // Create new application
  async create(draft: DraftApplication): Promise<DraftApplication> {
    const response = await api.post<ApiResponse<ApplicationDTO>>('/applications', draftToDto(draft));
    return dtoToDraft(response.data.data);
  },

  // Update application
  async update(id: string, updates: Partial<DraftApplication>): Promise<DraftApplication> {
    const response = await api.put<ApiResponse<ApplicationDTO>>(`/applications/${id}`, updates);
    return dtoToDraft(response.data.data);
  },

  // Save as draft
  async saveAsDraft(draft: DraftApplication): Promise<DraftApplication> {
    const response = await api.post<ApiResponse<ApplicationDTO>>('/applications/draft', draftToDto(draft));
    return dtoToDraft(response.data.data);
  },

  // Submit application
  async submit(id: string): Promise<DraftApplication> {
    const response = await api.post<ApiResponse<ApplicationDTO>>(`/applications/${id}/submit`);
    return dtoToDraft(response.data.data);
  },

  // Delete application
  async delete(id: string): Promise<void> {
    await api.delete(`/applications/${id}`);
  },
};

// Signature API calls
export const signatureApi = {
  // Get signatures for an application
  async getByApplicationId(applicationId: string): Promise<AgreementSignature[]> {
    try {
      const response = await api.get<ApiResponse<SignatureDTO[]>>(`/signatures/application/${applicationId}`);
      return response.data.data.map(dto => ({
        id: dto.id,
        name: dto.signatoryName,
        signature: dto.signatureData,
        date: dto.signedAt,
      }));
    } catch (error) {
      return [];
    }
  },

  // Save signatures for an application
  async saveAll(applicationId: string, signatures: AgreementSignature[]): Promise<AgreementSignature[]> {
    const signatureDTOs = signatures.map(sig => ({
      applicationId,
      signatoryName: sig.name,
      signatureData: sig.signature,
      signatureType: 'agreement',
    }));

    const response = await api.post<ApiResponse<SignatureDTO[]>>('/signatures/batch', {
      applicationId,
      signatures: signatureDTOs,
    });

    return response.data.data.map(dto => ({
      id: dto.id,
      name: dto.signatoryName,
      signature: dto.signatureData,
      date: dto.signedAt,
    }));
  },

  // Delete all signatures for an application
  async deleteByApplicationId(applicationId: string): Promise<void> {
    const signatures = await signatureApi.getByApplicationId(applicationId);
    await Promise.all(signatures.map(sig => api.delete(`/signatures/${sig.id}`)));
  },
};
