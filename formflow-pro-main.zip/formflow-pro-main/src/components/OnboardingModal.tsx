import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Monitor, Upload, FileText, CheckCircle2, AlertCircle, Loader2, Edit2 } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { FormData, initialFormData } from '@/types/form';
import { parsePDF, getExtractionSummary } from '@/lib/pdfParser';

interface OnboardingModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

// Fallback mock data in case PDF parsing fails or extracts nothing
const createFallbackFormData = (): FormData => ({
  ...initialFormData,
  businessDetails: {
    registeredName: 'Sample Company Pte Ltd',
    registrationNumber: '202300001K',
    businessType: 'Private Limited Company',
    natureOfBusiness: 'General Business Services',
    countryOfDomicile: 'Singapore',
    gstRegistered: false,
    officeNumber: '+65 6000 0000',
    faxNumber: '',
  },
  primaryContact: {
    fullName: 'Contact Person',
    nricPassport: 'S0000000A',
    email: 'contact@example.com',
    mobileNumber: '+65 9000 0000',
    officeNumber: '+65 6000 0000',
  },
});

export function OnboardingModal({ open, onOpenChange }: OnboardingModalProps) {
  const navigate = useNavigate();
  const [step, setStep] = useState<'choose' | 'upload' | 'preview'>('choose');
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingStatus, setProcessingStatus] = useState<string>('');
  const [processingProgress, setProcessingProgress] = useState<number>(0);
  const [parsedData, setParsedData] = useState<FormData | null>(null);
  const [rawText, setRawText] = useState<string>('');
  const [extractionSummary, setExtractionSummary] = useState<string>('');
  const [ocrUsed, setOcrUsed] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleOnlineOption = () => {
    onOpenChange(false);
    navigate('/new');
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.includes('pdf')) {
      setError('Please upload a PDF file');
      return;
    }

    setIsProcessing(true);
    setProcessingStatus('Loading PDF...');
    setProcessingProgress(0);
    setError(null);

    try {
      // Real PDF parsing with OCR support
      const extractedData = await parsePDF(file, (status, progress) => {
        setProcessingStatus(status);
        setProcessingProgress(progress);
      });
      
      // Check if we got meaningful data
      const hasData = extractedData.formData.businessDetails.registeredName || 
                      extractedData.formData.primaryContact.fullName ||
                      extractedData.formData.beneficialOwners.length > 0;
      
      setOcrUsed(extractedData.ocrUsed);
      
      if (hasData) {
        setParsedData(extractedData.formData);
        setRawText(extractedData.rawText);
        setExtractionSummary(getExtractionSummary(extractedData));
      } else {
        // If no data was extracted, use fallback but show the raw text
        setParsedData(createFallbackFormData());
        setRawText(extractedData.rawText || 'No text content found in PDF');
        setExtractionSummary(
          extractedData.ocrUsed 
            ? 'Note: OCR was used but limited data was extracted. Please review and edit the form fields manually.'
            : 'Note: Limited data extracted. Please review and edit the form fields manually.'
        );
      }
      
      setIsProcessing(false);
      setStep('preview');
    } catch (err) {
      console.error('PDF parsing error:', err);
      setError(err instanceof Error ? err.message : 'Failed to parse PDF');
      setIsProcessing(false);
    }
  };

  const handleConfirmParsedData = () => {
    // Navigate to form with pre-populated data
    onOpenChange(false);
    navigate('/new', { state: { prefillData: parsedData } });
  };

  const handleSaveAsDraft = () => {
    if (!parsedData) return;
    
    // Save to localStorage as a draft with proper DraftApplication structure
    const draftId = `draft-${Date.now()}`;
    const now = new Date().toISOString();
    
    const draft = {
      id: draftId,
      status: 'draft' as const,
      createdAt: now,
      updatedAt: now,
      businessDetails: parsedData.businessDetails,
      primaryContact: parsedData.primaryContact,
      secondaryContact: parsedData.secondaryContact,
      accountType: parsedData.accountType,
      accountParticulars: parsedData.accountParticulars,
      beneficialOwners: parsedData.beneficialOwners,
      signingCondition: parsedData.signingCondition,
      boardResolution: parsedData.boardResolution,
      taxDeclarationEntity: parsedData.taxDeclarationEntity,
      taxDeclarationIndividual: parsedData.taxDeclarationIndividual,
      businessBankingServices: parsedData.businessBankingServices,
      businessDebitCard: parsedData.businessDebitCard,
      giroApplication: parsedData.giroApplication,
      eAlerts: parsedData.eAlerts,
      agreement: parsedData.agreement,
      agreeToTerms: parsedData.agreeToTerms,
    };
    
    // Get existing drafts
    const existingDrafts = localStorage.getItem('user_drafts');
    const drafts = existingDrafts ? JSON.parse(existingDrafts) : [];
    drafts.push(draft);
    localStorage.setItem('user_drafts', JSON.stringify(drafts));
    
    onOpenChange(false);
    // Navigate to view the saved draft
    navigate(`/view/${draftId}`);
  };

  const resetModal = () => {
    setStep('choose');
    setParsedData(null);
    setRawText('');
    setExtractionSummary('');
    setError(null);
    setIsProcessing(false);
    setProcessingStatus('');
    setProcessingProgress(0);
    setOcrUsed(false);
  };

  // Helper to display key fields from extracted data
  const renderExtractedSummary = (data: FormData) => {
    return (
      <div className="space-y-3 text-sm">
        {extractionSummary && (
          <div className="p-2 bg-primary/10 rounded text-xs text-primary mb-2">
            {extractionSummary.split('\n').map((line, i) => (
              <div key={i}>{line}</div>
            ))}
          </div>
        )}
        
        <div className="grid grid-cols-2 gap-2">
          <div>
            <p className="text-muted-foreground text-xs">Company Name</p>
            <p className="font-medium">{data.businessDetails.registeredName || '(Not found)'}</p>
          </div>
          <div>
            <p className="text-muted-foreground text-xs">UEN</p>
            <p className="font-medium">{data.businessDetails.registrationNumber || '(Not found)'}</p>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div>
            <p className="text-muted-foreground text-xs">Primary Contact</p>
            <p className="font-medium">{data.primaryContact.fullName || '(Not found)'}</p>
          </div>
          <div>
            <p className="text-muted-foreground text-xs">Email</p>
            <p className="font-medium">{data.primaryContact.email || '(Not found)'}</p>
          </div>
        </div>
        <div>
          <p className="text-muted-foreground text-xs">Account Types</p>
          <p className="font-medium">{data.accountType.sgdAccounts.length > 0 ? data.accountType.sgdAccounts.join(', ') : '(Not found)'}</p>
        </div>
        <div>
          <p className="text-muted-foreground text-xs">Beneficial Owners</p>
          <p className="font-medium">{data.beneficialOwners.length > 0 ? data.beneficialOwners.map(o => o.fullName).join(', ') : '(Not found)'}</p>
        </div>
        
        <details className="mt-2">
          <summary className="text-xs text-muted-foreground cursor-pointer hover:text-foreground">
            View Raw Extracted Text
          </summary>
          <pre className="mt-2 text-xs text-muted-foreground whitespace-pre-wrap bg-muted/50 p-2 rounded max-h-40 overflow-y-auto">
            {rawText || 'No text extracted'}
          </pre>
        </details>
        
        <details className="mt-2">
          <summary className="text-xs text-muted-foreground cursor-pointer hover:text-foreground">
            View Full JSON Data
          </summary>
          <pre className="mt-2 text-xs text-muted-foreground whitespace-pre-wrap bg-muted/50 p-2 rounded max-h-40 overflow-y-auto">
            {JSON.stringify(data, null, 2)}
          </pre>
        </details>
      </div>
    );
  };

  return (
    <Dialog open={open} onOpenChange={(o) => {
      onOpenChange(o);
      if (!o) resetModal();
    }}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-xl font-display">
            Onboard New Customer Business Account
          </DialogTitle>
          <DialogDescription>
            {step === 'choose' && 'Choose how you want to proceed with the application'}
            {step === 'upload' && 'Upload a scanned PDF of the application form'}
            {step === 'preview' && 'Review extracted data from the PDF'}
          </DialogDescription>
        </DialogHeader>

        <AnimatePresence mode="wait">
          {step === 'choose' && (
            <motion.div
              key="choose"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="grid grid-cols-2 gap-4 pt-4"
            >
              <Card
                className="cursor-pointer hover:border-primary hover:shadow-md transition-all"
                onClick={handleOnlineOption}
              >
                <CardContent className="pt-6 text-center">
                  <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 text-primary mb-4">
                    <Monitor className="w-6 h-6" />
                  </div>
                  <h3 className="font-semibold mb-2">Online Application</h3>
                  <p className="text-sm text-muted-foreground">
                    Fill out the form digitally step by step
                  </p>
                </CardContent>
              </Card>

              <Card
                className="cursor-pointer hover:border-primary hover:shadow-md transition-all"
                onClick={() => setStep('upload')}
              >
                <CardContent className="pt-6 text-center">
                  <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-secondary/10 text-secondary-foreground mb-4">
                    <Upload className="w-6 h-6" />
                  </div>
                  <h3 className="font-semibold mb-2">Upload Scanned PDF</h3>
                  <p className="text-sm text-muted-foreground">
                    Extract data from existing PDF form
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          )}

          {step === 'upload' && (
            <motion.div
              key="upload"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="pt-4"
            >
              <div
                className={cn(
                  'border-2 border-dashed rounded-xl p-8 text-center transition-colors',
                  isProcessing ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/50'
                )}
              >
                {isProcessing ? (
                  <div className="space-y-4">
                    <Loader2 className="w-12 h-12 mx-auto text-primary animate-spin" />
                    <p className="text-sm text-muted-foreground">
                      {processingStatus || 'Processing PDF...'}
                    </p>
                    {processingProgress > 0 && (
                      <div className="w-full bg-muted rounded-full h-2">
                        <div 
                          className="bg-primary h-2 rounded-full transition-all duration-300"
                          style={{ width: `${processingProgress}%` }}
                        />
                      </div>
                    )}
                  </div>
                ) : (
                  <>
                    <FileText className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                    <p className="font-medium mb-2">Drop your PDF here or click to browse</p>
                    <p className="text-sm text-muted-foreground mb-4">
                      Supports scanned application forms (PDF only)
                    </p>
                    <input
                      type="file"
                      accept=".pdf"
                      onChange={handleFileUpload}
                      className="hidden"
                      id="pdf-upload"
                    />
                    <Button asChild variant="outline">
                      <label htmlFor="pdf-upload" className="cursor-pointer">
                        Select PDF File
                      </label>
                    </Button>
                  </>
                )}
              </div>

              {error && (
                <div className="mt-4 p-3 rounded-lg bg-destructive/10 text-destructive flex items-center gap-2">
                  <AlertCircle className="w-4 h-4" />
                  <span className="text-sm">{error}</span>
                </div>
              )}

              <div className="flex justify-between mt-6">
                <Button variant="ghost" onClick={() => setStep('choose')}>
                  Back
                </Button>
              </div>
            </motion.div>
          )}

          {step === 'preview' && parsedData && (
            <motion.div
              key="preview"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="pt-4"
            >
              <div className="flex items-center gap-2 mb-4 text-success">
                <CheckCircle2 className="w-5 h-5" />
                <span className="font-medium">PDF Data Extracted Successfully</span>
              </div>

              <div className="bg-muted/50 rounded-xl p-4 max-h-72 overflow-y-auto">
                {renderExtractedSummary(parsedData)}
              </div>

              <p className="text-sm text-muted-foreground mt-4">
                You can edit all fields before submission. Choose to continue editing or save as draft.
              </p>

              <div className="flex flex-col gap-2 mt-6">
                <div className="flex justify-between gap-2">
                  <Button variant="ghost" onClick={() => setStep('upload')}>
                    Upload Different PDF
                  </Button>
                  <div className="flex gap-2">
                    <Button variant="outline" onClick={handleSaveAsDraft}>
                      <FileText className="w-4 h-4 mr-2" />
                      Save as Draft
                    </Button>
                    <Button onClick={handleConfirmParsedData}>
                      <Edit2 className="w-4 h-4 mr-2" />
                      Edit & Continue
                    </Button>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </DialogContent>
    </Dialog>
  );
}