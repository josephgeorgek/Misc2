import { useState } from 'react';
import { jsPDF } from 'jspdf';
import { Loader2, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { FormData } from '@/types/form';

interface PDFExportButtonProps {
  formData: FormData;
  contentRef?: React.RefObject<HTMLDivElement>;
}

export function PDFExportButton({ formData }: PDFExportButtonProps) {
  const [isExporting, setIsExporting] = useState(false);

  // Pre-convert SVG signatures to PNG before PDF generation
  const convertSvgToPng = (svgDataUrl: string): Promise<string> => {
    return new Promise((resolve, reject) => {
      if (!svgDataUrl || !svgDataUrl.includes('image/svg+xml')) {
        resolve(svgDataUrl);
        return;
      }

      const img = new Image();
      img.crossOrigin = 'anonymous';
      
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = 300;
        canvas.height = 100;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.fillStyle = 'white';
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          ctx.drawImage(img, 0, 0, 300, 100);
          resolve(canvas.toDataURL('image/png'));
        } else {
          reject(new Error('Could not get canvas context'));
        }
      };
      
      img.onerror = () => {
        reject(new Error('Failed to load SVG image'));
      };
      
      img.src = svgDataUrl;
    });
  };

  // Collect all signatures that need conversion
  const collectSignatures = (): string[] => {
    const signatures: string[] = [];
    
    // Beneficial owners
    formData.beneficialOwners.forEach(owner => {
      if (owner.signature) signatures.push(owner.signature);
    });
    
    // Board resolution
    formData.boardResolution.authorisedPersons.forEach(person => {
      if (person.signature) signatures.push(person.signature);
    });
    formData.boardResolution.directorSignatures?.forEach(dir => {
      if (dir.signature) signatures.push(dir.signature);
    });
    if (formData.boardResolution.companySecretarySignature) {
      signatures.push(formData.boardResolution.companySecretarySignature);
    }
    
    // Debit card
    formData.businessDebitCard.cardholders?.forEach(ch => {
      if (ch.signature) signatures.push(ch.signature);
    });
    
    // GIRO
    formData.giroApplication.signatures?.forEach(sig => {
      if (sig.signature) signatures.push(sig.signature);
    });
    
    // Agreement signatures
    formData.agreement.agreementSignatures?.forEach(sig => {
      if (sig.signature) signatures.push(sig.signature);
    });
    
    return [...new Set(signatures)]; // Unique signatures
  };

  const generatePDF = async () => {
    setIsExporting(true);

    try {
      // Pre-convert all SVG signatures to PNG
      const allSignatures = collectSignatures();
      const signatureMap = new Map<string, string>();
      
      for (const sig of allSignatures) {
        if (sig && sig.includes('image/svg+xml')) {
          try {
            const pngData = await convertSvgToPng(sig);
            signatureMap.set(sig, pngData);
          } catch (e) {
            console.warn('Failed to convert signature:', e);
            signatureMap.set(sig, sig); // Use original as fallback
          }
        }
      }

      const pdf = new jsPDF('p', 'mm', 'a4');
      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();
      const margin = 15;
      let yOffset = margin;

      // Helper function to add text with word wrap
      const addText = (text: string, x: number, y: number, fontSize: number = 10, isBold: boolean = false) => {
        pdf.setFontSize(fontSize);
        pdf.setFont('helvetica', isBold ? 'bold' : 'normal');
        const lines = pdf.splitTextToSize(text, pageWidth - 2 * margin);
        pdf.text(lines, x, y);
        return lines.length * (fontSize * 0.4);
      };

      // Helper to check page break
      const checkPageBreak = (height: number) => {
        if (yOffset + height > pageHeight - margin) {
          pdf.addPage();
          yOffset = margin;
        }
      };

      // Add header
      pdf.setFillColor(200, 30, 30); // OCBC Red
      pdf.rect(0, 0, pageWidth, 25, 'F');
      pdf.setTextColor(255, 255, 255);
      addText('OCBC BUSINESS ACCOUNT APPLICATION FORM', margin, 16, 16, true);
      pdf.setTextColor(0, 0, 0);
      yOffset = 35;

      // Section divider helper
      const addSection = (title: string) => {
        checkPageBreak(20);
        pdf.setFillColor(240, 240, 240);
        pdf.rect(margin, yOffset - 5, pageWidth - 2 * margin, 10, 'F');
        pdf.setTextColor(200, 30, 30);
        addText(title.toUpperCase(), margin + 2, yOffset + 2, 11, true);
        pdf.setTextColor(0, 0, 0);
        yOffset += 12;
      };

      // Field helper
      const addField = (label: string, value: string | undefined | null) => {
        checkPageBreak(10);
        pdf.setFont('helvetica', 'bold');
        pdf.setFontSize(9);
        pdf.text(`${label}:`, margin, yOffset);
        pdf.setFont('helvetica', 'normal');
        const valueText = value || '-';
        const valueLines = pdf.splitTextToSize(valueText, pageWidth - margin - 65);
        pdf.text(valueLines, margin + 50, yOffset);
        yOffset += Math.max(6, valueLines.length * 4);
      };

      // Signature helper - uses pre-converted signatures
      const addSignature = (label: string, signature: string | undefined, name?: string, date?: string) => {
        checkPageBreak(35);
        pdf.setFont('helvetica', 'bold');
        pdf.setFontSize(9);
        pdf.text(`${label}:`, margin, yOffset);
        yOffset += 5;
        
        if (signature && signature.startsWith('data:image')) {
          try {
            // Use pre-converted PNG if available
            const imageToUse = signatureMap.get(signature) || signature;
            pdf.addImage(imageToUse, 'PNG', margin, yOffset - 3, 50, 17);
            yOffset += 20;
          } catch (e) {
            console.error('Error adding signature image:', e);
            pdf.setFont('helvetica', 'italic');
            pdf.text('[Signature on file]', margin, yOffset);
            yOffset += 6;
          }
        } else {
          pdf.setFont('helvetica', 'italic');
          pdf.text('[No signature]', margin, yOffset);
          yOffset += 6;
        }
        
        if (name) {
          pdf.setFont('helvetica', 'normal');
          pdf.text(`Name: ${name}`, margin, yOffset);
          yOffset += 5;
        }
        if (date) {
          pdf.setFont('helvetica', 'normal');
          pdf.text(`Date: ${date}`, margin, yOffset);
          yOffset += 5;
        }
        yOffset += 3;
      };

      // ========== SECTION 1: BUSINESS DETAILS ==========
      addSection('Section 1: Business Details');
      addField('Registered Name', formData.businessDetails.registeredName);
      addField('Registration No. (UEN)', formData.businessDetails.registrationNumber);
      addField('Business Type', formData.businessDetails.businessType);
      addField('Nature of Business', formData.businessDetails.natureOfBusiness);
      addField('Country of Domicile', formData.businessDetails.countryOfDomicile);
      addField('GST Registered', formData.businessDetails.gstRegistered ? 'Yes' : 'No');
      addField('Office Number', formData.businessDetails.officeNumber);
      addField('Fax Number', formData.businessDetails.faxNumber);
      yOffset += 5;

      // ========== SECTION 2: CONTACT PERSONS ==========
      addSection('Section 2: Contact Persons');
      addText('Primary Contact', margin, yOffset, 10, true);
      yOffset += 6;
      addField('Full Name', formData.primaryContact.fullName);
      addField('NRIC/Passport', formData.primaryContact.nricPassport);
      addField('Email', formData.primaryContact.email);
      addField('Mobile', formData.primaryContact.mobileNumber);

      if (formData.secondaryContact.fullName) {
        yOffset += 4;
        addText('Secondary Contact', margin, yOffset, 10, true);
        yOffset += 6;
        addField('Full Name', formData.secondaryContact.fullName);
        addField('NRIC/Passport', formData.secondaryContact.nricPassport);
        addField('Email', formData.secondaryContact.email);
        addField('Mobile', formData.secondaryContact.mobileNumber);
      }
      yOffset += 5;

      // ========== SECTION 3: ACCOUNT TYPES ==========
      addSection('Section 3: Account Type Selection');
      if (formData.accountType.sgdAccounts.length > 0) {
        addField('SGD Accounts', formData.accountType.sgdAccounts.join(', '));
      }
      if (formData.accountType.foreignCurrencyAccounts.length > 0) {
        addField('Foreign Currency Accounts', formData.accountType.foreignCurrencyAccounts.join(', '));
      }
      if (formData.accountType.currencies.length > 0) {
        addField('Currencies', formData.accountType.currencies.join(', ').toUpperCase());
      }
      yOffset += 5;

      // ========== SECTION 4: ACCOUNT PARTICULARS ==========
      addSection('Section 4: Account Particulars');
      addField('Account Name', formData.accountParticulars.accountName);
      addField('Mailing Address', formData.accountParticulars.mailingAddress);
      addField('Source of Capital', formData.accountParticulars.sourceOfCapital.join(', '));
      addField('PayNow Sign-up', formData.accountParticulars.payNowSignUp ? 'Yes' : 'No');
      addField('SGQR Sign-up', formData.accountParticulars.sgqrSignUp ? 'Yes' : 'No');
      
      if (formData.accountParticulars.sgqrSignUp && formData.accountParticulars.outlets.length > 0) {
        yOffset += 3;
        addText('SGQR Outlets:', margin, yOffset, 9, true);
        yOffset += 5;
        formData.accountParticulars.outlets.filter(o => o.outletName).forEach((outlet, idx) => {
          addField(`Outlet ${idx + 1}`, `${outlet.outletName} - ${outlet.postalCode}, ${outlet.levelUnit}`);
        });
      }
      yOffset += 5;

      // ========== SECTION 5: BENEFICIAL OWNERS ==========
      addSection('Section 5: Beneficial Owners & Signatories');
      formData.beneficialOwners.forEach((owner, idx) => {
        checkPageBreak(45);
        addText(`Person ${idx + 1}: ${owner.fullName}`, margin, yOffset, 10, true);
        yOffset += 6;
        addField('NRIC/Passport', owner.nricPassport);
        addField('Designation', owner.designation);
        addField('Email', owner.email);
        addField('Mobile', owner.mobileNumber);
        addField('Office', owner.officeNumber);
        const roles = [];
        if (owner.isBeneficialOwner) roles.push('Beneficial Owner');
        if (owner.isAuthorisedSignatory) roles.push('Authorised Signatory');
        addField('Roles', roles.join(', ') || 'None');
        if (owner.grouping) {
          addField('Group', owner.grouping);
        }
        
        // Add specimen signature if exists
        if (owner.signature) {
          addSignature('Specimen Signature', owner.signature);
        }
        yOffset += 4;
      });

      const signingTypes: Record<string, string> = {
        singly: 'Singly (Any one signatory)',
        anyTwo: 'Any Two Jointly',
        grouping: 'Grouping with Signing Limits',
      };
      addField('Signing Condition', signingTypes[formData.signingCondition.type]);
      if (formData.signingCondition.details) {
        addField('Signing Details', formData.signingCondition.details);
      }
      yOffset += 5;

      // ========== SECTION 6: BOARD RESOLUTION ==========
      addSection('Section 6: Board Resolution');
      addField('Company Name', formData.boardResolution.companyName);
      addField('Meeting Date', formData.boardResolution.meetingDate);
      addField('Resolution Passed', formData.boardResolution.resolutionPassed ? 'Yes' : 'No');
      
      // Authorised Activities
      const activities: string[] = [];
      if (formData.boardResolution.openCloseAccounts) activities.push('Open/Close Accounts');
      if (formData.boardResolution.applyBankingServices) activities.push('Apply Banking Services');
      if (formData.boardResolution.appointAuthorisedUsers) activities.push('Appoint Authorised Users');
      if (formData.boardResolution.appointAuthorisedSignatories) activities.push('Appoint Signatories');
      if (formData.boardResolution.borrowingAndSecurity) activities.push('Borrowing & Security');
      if (formData.boardResolution.corporateCreditCard) activities.push('Corporate Credit Card');
      if (formData.boardResolution.electronicSigning) activities.push('Electronic Signing');
      addField('Authorised Activities', activities.join(', '));
      
      addField('Signing Mandate', formData.boardResolution.signingMandate);
      addField('Signing Limits', formData.boardResolution.signingLimits);
      
      // Authorised Persons with Signatures
      if (formData.boardResolution.authorisedPersons.length > 0) {
        yOffset += 3;
        addText('Schedule of Authorised Persons:', margin, yOffset, 10, true);
        yOffset += 6;
        formData.boardResolution.authorisedPersons.forEach((person, idx) => {
          checkPageBreak(40);
          addField(`Person ${idx + 1} Name`, person.fullName);
          addField('NRIC/Passport', person.nricPassport);
          addField('Designation', person.designation);
          addSignature('Specimen Signature', person.signature);
        });
      }
      
      // Director Signatures
      if (formData.boardResolution.directorSignatures.length > 0) {
        yOffset += 3;
        addText('Director Signatures:', margin, yOffset, 10, true);
        yOffset += 6;
        formData.boardResolution.directorSignatures.forEach((dir, idx) => {
          checkPageBreak(35);
          addSignature(`Director ${idx + 1}`, dir.signature, dir.name, dir.date);
        });
      }
      
      // Company Secretary
      if (formData.boardResolution.companySecretaryName) {
        yOffset += 3;
        addText('Company Secretary Certification:', margin, yOffset, 10, true);
        yOffset += 6;
        addField('Name', formData.boardResolution.companySecretaryName);
        addField('Date', formData.boardResolution.certificationDate);
        addSignature('Signature', formData.boardResolution.companySecretarySignature);
      }
      yOffset += 5;

      // ========== SECTION 7: TAX DECLARATION ==========
      addSection('Section 7: Tax Declaration (FATCA/CRS)');
      addField('Entity Name', formData.taxDeclarationEntity.registeredName);
      addField('Registration No.', formData.taxDeclarationEntity.registrationNumber);
      addField('Registered Address', formData.taxDeclarationEntity.registeredAddress);
      addField('Country', formData.taxDeclarationEntity.country);
      addField('Postal Code', formData.taxDeclarationEntity.postalCode);
      addField('Entity Type', formData.taxDeclarationEntity.entityType === 'financialInstitution' ? 'Financial Institution' : 'Non-Financial Institution');
      
      if (formData.taxDeclarationEntity.entityType === 'notFinancialInstitution') {
        const nonFITypes: Record<string, string> = {
          publicSector: 'Public Sector Entity',
          activeBusiness: 'Active Non-Financial Entity',
          passiveBusiness: 'Passive Non-Financial Entity',
        };
        addField('Non-FI Type', nonFITypes[formData.taxDeclarationEntity.nonFIType] || formData.taxDeclarationEntity.nonFIType);
      }
      
      if (formData.taxDeclarationEntity.fatcaStatus) {
        addField('FATCA Status', formData.taxDeclarationEntity.fatcaStatus);
      }
      if (formData.taxDeclarationEntity.crsStatus) {
        addField('CRS Status', formData.taxDeclarationEntity.crsStatus);
      }
      
      // Tax Residencies
      if (formData.taxDeclarationEntity.taxResidencies.length > 0) {
        yOffset += 3;
        addText('Tax Residencies:', margin, yOffset, 9, true);
        yOffset += 5;
        formData.taxDeclarationEntity.taxResidencies.forEach((res, idx) => {
          addField(`Residency ${idx + 1}`, `${res.country} - TIN: ${res.tin || 'N/A'}`);
        });
      }
      
      if (formData.taxDeclarationEntity.declarationSignature) {
        addSignature('Declaration Signature', formData.taxDeclarationEntity.declarationSignature, undefined, formData.taxDeclarationEntity.declarationDate);
      }
      yOffset += 5;

      // ========== SECTION 8: BUSINESS BANKING SERVICES ==========
      addSection('Section 8: Business Banking Services (Velocity)');
      addField('Apply for Velocity', formData.businessBankingServices.applyForVelocity ? 'Yes' : 'No');
      if (formData.businessBankingServices.applyForVelocity) {
        addField('Organisation ID', formData.businessBankingServices.organisationId);
        addField('Contact Person', formData.businessBankingServices.contactPersonName);
        addField('Contact Email', formData.businessBankingServices.contactPersonEmail);
        addField('Contact Mobile', formData.businessBankingServices.contactPersonMobile);
        addField('Service Package', formData.businessBankingServices.servicePackage?.toUpperCase());
        addField('2FA Method', formData.businessBankingServices.twoFactorMethod === 'digital' ? 'Digital Token' : 'Hardware Token');
        addField('e-Statement', formData.businessBankingServices.eStatementEnabled ? 'Enabled' : 'Disabled');
        
        // Approval Matrix
        if (formData.businessBankingServices.approvalMatrix) {
          const approvalTypes: Record<string, string> = {
            single: 'Single Approver',
            dual: 'Dual Approver',
            matrix: 'Matrix-based',
          };
          addField('Approval Type', approvalTypes[formData.businessBankingServices.approvalMatrix.approvalType] || '-');
          
          if (formData.businessBankingServices.approvalMatrix.approvalType === 'dual') {
            addField('Single Threshold', `SGD ${formData.businessBankingServices.approvalMatrix.singleApproverThreshold}`);
            addField('Dual Threshold', `SGD ${formData.businessBankingServices.approvalMatrix.dualApproverThreshold}`);
          }
        }
        
        // Velocity Users
        if (formData.businessBankingServices.velocityUsers.length > 0) {
          yOffset += 3;
          addText('Authorised Velocity Users:', margin, yOffset, 9, true);
          yOffset += 5;
          formData.businessBankingServices.velocityUsers.forEach((user, idx) => {
            checkPageBreak(25);
            addField(`User ${idx + 1}`, user.fullName);
            addField('User ID', user.userId);
            addField('Role', user.role);
            addField('Email', user.email);
            yOffset += 2;
          });
        }
        
        // Custom Roles
        if (formData.businessBankingServices.customRoles && formData.businessBankingServices.customRoles.length > 0) {
          yOffset += 3;
          addText('Custom Roles:', margin, yOffset, 9, true);
          yOffset += 5;
          formData.businessBankingServices.customRoles.forEach((role, idx) => {
            addField(`Role ${idx + 1}`, `${role.roleName} - ${role.description}`);
          });
        }
      }
      yOffset += 5;

      // ========== SECTION 9: DEBIT CARD ==========
      addSection('Section 9: Business Debit Card');
      addField('Apply for Debit Card', formData.businessDebitCard.applyForDebitCard ? 'Yes' : 'No');
      if (formData.businessDebitCard.applyForDebitCard) {
        addField('Linked Account', formData.businessDebitCard.linkedAccountNumber || 'New Account');
        formData.businessDebitCard.cardholders.forEach((holder, idx) => {
          checkPageBreak(30);
          addText(`Cardholder ${idx + 1}: ${holder.fullName}`, margin, yOffset, 9, true);
          yOffset += 5;
          addField('Name on Card', holder.nameOnCard);
          addField('NRIC', holder.nricNumber);
          addField('NETS ATM Limit', `$${holder.netsAtmLimit}`);
          addField('NETS Payment Limit', `$${holder.netsPaymentLimit}`);
          if (holder.signature) {
            addSignature('Cardholder Signature', holder.signature);
          }
        });
      }
      yOffset += 5;

      // ========== SECTION 10: GIRO ==========
      addSection('Section 10: GIRO Application');
      addField('Apply for GIRO', formData.giroApplication.applyForGIRO ? 'Yes' : 'No');
      if (formData.giroApplication.applyForGIRO) {
        addField('Debit Account', formData.giroApplication.debitAccountNumber);
        
        if (formData.giroApplication.billingOrganizations.length > 0) {
          yOffset += 3;
          addText('Billing Organizations:', margin, yOffset, 9, true);
          yOffset += 5;
          formData.giroApplication.billingOrganizations.forEach((org, idx) => {
            addField(`Organization ${idx + 1}`, `${org.organizationName} - Account: ${org.accountNumber}`);
          });
        }
        
        if (formData.giroApplication.signatures.length > 0) {
          yOffset += 3;
          formData.giroApplication.signatures.forEach((sig, idx) => {
            checkPageBreak(35);
            addSignature(`GIRO Signatory ${idx + 1}`, sig.signature, sig.name, sig.date);
          });
        }
      }
      yOffset += 5;

      // ========== SECTION 11: E-ALERTS ==========
      addSection('Section 11: eAlerts');
      addField('Apply for eAlerts', formData.eAlerts.applyForEAlerts ? 'Yes' : 'No');
      if (formData.eAlerts.applyForEAlerts && formData.eAlerts.alertUsers.length > 0) {
        formData.eAlerts.alertUsers.forEach((user, idx) => {
          addField(`Alert User ${idx + 1}`, `${user.name} - ${user.deliveryMethod === 'email' ? 'Email' : 'SMS'}`);
        });
      }
      yOffset += 5;

      // ========== SECTION 12: AGREEMENT & AUTHORISED SIGNATURES ==========
      addSection('Section 12: Agreement & Declaration');
      addField('Agree to Terms & Conditions', formData.agreement.agreeToTerms ? 'Yes' : 'No');
      addField('Agree to Data Protection', formData.agreement.agreeToDataProtection ? 'Yes' : 'No');
      addField('Agree to FATCA', formData.agreement.agreeToFATCA ? 'Yes' : 'No');
      addField('Agree to CRS', formData.agreement.agreeToCRS ? 'Yes' : 'No');
      addField('Signature Date', formData.agreement.signatureDate);
      
      // Agreement Signatures - Most Important
      if (formData.agreement.agreementSignatures.length > 0) {
        yOffset += 5;
        checkPageBreak(20);
        pdf.setFillColor(200, 30, 30);
        pdf.rect(margin, yOffset - 5, pageWidth - 2 * margin, 10, 'F');
        pdf.setTextColor(255, 255, 255);
        addText('AUTHORISED SIGNATURES', margin + 2, yOffset + 2, 11, true);
        pdf.setTextColor(0, 0, 0);
        yOffset += 15;
        
        formData.agreement.agreementSignatures.forEach((sig, idx) => {
          checkPageBreak(45);
          
          // Signature box
          pdf.setDrawColor(200, 200, 200);
          pdf.setLineWidth(0.5);
          pdf.rect(margin, yOffset - 5, pageWidth - 2 * margin, 38, 'S');
          
          pdf.setFont('helvetica', 'bold');
          pdf.setFontSize(10);
          pdf.text(`Authorised Signatory ${idx + 1}`, margin + 3, yOffset + 2);
          yOffset += 8;
          
          if (sig.signature && sig.signature.startsWith('data:image')) {
            try {
              // Handle both SVG and PNG signatures
              pdf.addImage(sig.signature, 'PNG', margin + 3, yOffset - 3, 60, 20);
            } catch (e) {
              console.error('Error adding agreement signature:', e);
              pdf.setFont('helvetica', 'italic');
              pdf.text('[Signature on file]', margin + 3, yOffset + 8);
            }
          }
          
          // Name and date on the right
          pdf.setFont('helvetica', 'normal');
          pdf.setFontSize(9);
          pdf.text(`Name: ${sig.name}`, pageWidth - margin - 50, yOffset + 5);
          pdf.text(`Date: ${sig.date}`, pageWidth - margin - 50, yOffset + 12);
          
          yOffset += 35;
        });
      }

      // ========== FOOTER ==========
      const pageCount = pdf.getNumberOfPages();
      for (let i = 1; i <= pageCount; i++) {
        pdf.setPage(i);
        pdf.setFontSize(8);
        pdf.setTextColor(128, 128, 128);
        pdf.text(
          `Page ${i} of ${pageCount} | OCBC Business Account Application | Generated on ${new Date().toLocaleDateString()}`,
          pageWidth / 2,
          pageHeight - 10,
          { align: 'center' }
        );
      }

      // Save the PDF
      const fileName = formData.businessDetails.registeredName
        ? `${formData.businessDetails.registeredName.replace(/[^a-zA-Z0-9]/g, '_')}_Application.pdf`
        : 'Business_Account_Application.pdf';
      
      pdf.save(fileName);
    } catch (error) {
      console.error('Error generating PDF:', error);
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <Button
      onClick={generatePDF}
      disabled={isExporting}
      variant="outline"
      className="gap-2"
    >
      {isExporting ? (
        <>
          <Loader2 className="w-4 h-4 animate-spin" />
          Generating PDF...
        </>
      ) : (
        <>
          <Download className="w-4 h-4" />
          Download as PDF
        </>
      )}
    </Button>
  );
}