import { useCallback } from 'react';
import { motion } from 'framer-motion';
import { PenTool, Plus, Trash2, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { SignatureCanvas } from './SignatureCanvas';
import { AgreementSignature } from '@/types/form';

interface AuthorizedSignaturesSectionProps {
  signatures: AgreementSignature[];
  onChange: (signatures: AgreementSignature[]) => void;
  disabled?: boolean;
}

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
};

export function AuthorizedSignaturesSection({
  signatures,
  onChange,
  disabled = false,
}: AuthorizedSignaturesSectionProps) {
  const addSignature = useCallback(() => {
    const newSignature: AgreementSignature = {
      id: `sig-${Date.now()}`,
      name: '',
      signature: '',
      date: new Date().toISOString().split('T')[0],
    };
    onChange([...signatures, newSignature]);
  }, [signatures, onChange]);

  const updateSignature = useCallback(
    (index: number, updates: Partial<AgreementSignature>) => {
      const updated = signatures.map((sig, i) =>
        i === index ? { ...sig, ...updates } : sig
      );
      onChange(updated);
    },
    [signatures, onChange]
  );

  const removeSignature = useCallback(
    (index: number) => {
      onChange(signatures.filter((_, i) => i !== index));
    },
    [signatures, onChange]
  );

  // Ensure we have at least 3 signature slots
  const ensureMinimumSignatures = useCallback(() => {
    if (signatures.length < 3) {
      const needed = 3 - signatures.length;
      const newSigs = Array.from({ length: needed }, (_, i) => ({
        id: `sig-${Date.now()}-${i}`,
        name: '',
        signature: '',
        date: new Date().toISOString().split('T')[0],
      }));
      onChange([...signatures, ...newSigs]);
    }
  }, [signatures, onChange]);

  // Auto-add minimum signatures on mount
  if (signatures.length < 3) {
    ensureMinimumSignatures();
  }

  return (
    <motion.div variants={itemVariants} className="form-section">
      <div className="flex items-center gap-3 mb-4">
        <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-accent">
          <PenTool className="w-5 h-5 text-accent-foreground" />
        </div>
        <div>
          <h3 className="text-lg font-semibold font-display text-foreground">
            Authorised Person's Signatures
          </h3>
          <p className="text-sm text-muted-foreground">
            Minimum 3 authorised signatories required to validate the application
          </p>
        </div>
      </div>

      <div className="space-y-6">
        {signatures.map((sig, index) => (
          <motion.div
            key={sig.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="p-4 rounded-xl border border-border bg-muted/30"
          >
            <div className="flex items-center justify-between mb-4">
              <span className="font-medium text-foreground">
                Authorised Signatory {index + 1}
              </span>
              {signatures.length > 3 && !disabled && (
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => removeSignature(index)}
                  className="text-destructive hover:text-destructive hover:bg-destructive/10"
                >
                  <Trash2 className="w-4 h-4 mr-1" />
                  Remove
                </Button>
              )}
            </div>

            <div className="grid md:grid-cols-2 gap-4 mb-4">
              <div className="space-y-2">
                <Label className="form-label">Full Name *</Label>
                <Input
                  placeholder="Enter signatory's full name"
                  value={sig.name}
                  onChange={(e) => updateSignature(index, { name: e.target.value })}
                  disabled={disabled}
                />
              </div>
              <div className="space-y-2">
                <Label className="form-label">Date *</Label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    type="date"
                    value={sig.date}
                    onChange={(e) => updateSignature(index, { date: e.target.value })}
                    className="pl-10"
                    disabled={disabled}
                  />
                </div>
              </div>
            </div>

            <SignatureCanvas
              value={sig.signature}
              onChange={(signature) => updateSignature(index, { signature })}
              label="Specimen Signature *"
              disabled={disabled}
            />
          </motion.div>
        ))}
      </div>

      {!disabled && (
        <Button
          type="button"
          variant="outline"
          onClick={addSignature}
          className="w-full mt-4"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Additional Signatory
        </Button>
      )}
    </motion.div>
  );
}
