import { useState, useCallback, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { FormData, initialFormData } from '@/types/form';
import { FormHeader } from './FormHeader';
import { FormProgress } from './FormProgress';
import { FormNavigation } from './FormNavigation';
import { BusinessDetailsStep } from './steps/BusinessDetailsStep';
import { AccountTypeStep } from './steps/AccountTypeStep';
import { AccountParticularsStep } from './steps/AccountParticularsStep';
import { BeneficialOwnersStep } from './steps/BeneficialOwnersStep';
import { BoardResolutionStep } from './steps/BoardResolutionStep';
import { TaxDeclarationStep } from './steps/TaxDeclarationStep';
import { BusinessServicesStep } from './steps/BusinessServicesStep';
import { DebitCardStep } from './steps/DebitCardStep';
import { GIROStep } from './steps/GIROStep';
import { ReviewStep } from './steps/ReviewStep';
import { toast } from 'sonner';
import { CheckCircle2, PartyPopper } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface BusinessAccountFormProps {
  initialData?: FormData;
  draftId?: string;
}

const STEPS = [
  { id: 1, title: 'Business Details', shortTitle: 'Business' },
  { id: 2, title: 'Account Type', shortTitle: 'Accounts' },
  { id: 3, title: 'Account Particulars', shortTitle: 'Particulars' },
  { id: 4, title: 'Beneficial Owners', shortTitle: 'Owners' },
  { id: 5, title: 'Board Resolution', shortTitle: 'Resolution' },
  { id: 6, title: 'Tax Declaration', shortTitle: 'Tax' },
  { id: 7, title: 'Business Services', shortTitle: 'Services' },
  { id: 8, title: 'Debit Card', shortTitle: 'Debit Card' },
  { id: 9, title: 'GIRO & eAlerts', shortTitle: 'GIRO' },
  { id: 10, title: 'Review & Submit', shortTitle: 'Review' },
];

export function BusinessAccountForm({ initialData, draftId }: BusinessAccountFormProps) {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState<FormData>(initialData || initialFormData);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  // Update form data if initialData changes (e.g., when navigating to edit a different draft)
  useEffect(() => {
    if (initialData) {
      setFormData(initialData);
    }
  }, [initialData]);

  const updateFormData = useCallback((data: Partial<FormData>) => {
    setFormData((prev) => ({ ...prev, ...data }));
  }, []);

  const goToStep = (step: number) => {
    if (step >= 1 && step <= STEPS.length) {
      setCurrentStep(step);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleNext = () => {
    if (validateCurrentStep()) {
      goToStep(currentStep + 1);
    }
  };

  const handlePrevious = () => {
    goToStep(currentStep - 1);
  };

  const validateCurrentStep = (): boolean => {
    switch (currentStep) {
      case 1:
        if (!formData.businessDetails.registeredName || !formData.businessDetails.registrationNumber) {
          toast.error('Please fill in all required business details');
          return false;
        }
        if (!formData.primaryContact.fullName || !formData.primaryContact.email) {
          toast.error('Please fill in primary contact details');
          return false;
        }
        return true;
      case 2:
        if (formData.accountType.sgdAccounts.length === 0 && formData.accountType.foreignCurrencyAccounts.length === 0) {
          toast.error('Please select at least one account type');
          return false;
        }
        return true;
      case 3:
        if (formData.accountParticulars.sourceOfCapital.length === 0) {
          toast.error('Please select at least one source of capital');
          return false;
        }
        return true;
      case 4:
        if (formData.beneficialOwners.length === 0) {
          toast.error('Please add at least one beneficial owner or signatory');
          return false;
        }
        const hasIncompleteOwner = formData.beneficialOwners.some(
          (owner) => !owner.fullName || !owner.nricPassport || !owner.email
        );
        if (hasIncompleteOwner) {
          toast.error('Please complete all required fields for each person');
          return false;
        }
        return true;
      default:
        return true;
    }
  };

  const handleSubmit = async () => {
    if (!formData.agreeToTerms) {
      toast.error('Please agree to the Terms and Conditions');
      return;
    }

    setIsSubmitting(true);
    
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 2000));
    
    setIsSubmitting(false);
    setIsSubmitted(true);
    toast.success('Application submitted successfully!');
  };

  const canProceed = () => {
    if (currentStep === STEPS.length) {
      return formData.agreeToTerms;
    }
    return true;
  };

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-background">
        <FormHeader />
        <main className="container max-w-2xl mx-auto px-4 py-16">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center"
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: 'spring', stiffness: 200 }}
              className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-success/10 text-success mb-6"
            >
              <CheckCircle2 className="w-12 h-12" />
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
            >
              <h1 className="text-3xl font-bold font-display text-foreground mb-4">
                Application Submitted! <PartyPopper className="inline w-8 h-8" />
              </h1>
              <p className="text-lg text-muted-foreground mb-8 max-w-md mx-auto">
                Thank you for your application. Our team will review your details and 
                contact you within 3-5 business days.
              </p>

              <div className="p-6 rounded-xl bg-card border border-border mb-8 text-left max-w-md mx-auto">
                <h3 className="font-semibold text-foreground mb-3">What's Next?</h3>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <span className="text-primary">1.</span>
                    <span>We'll verify your submitted information</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary">2.</span>
                    <span>A representative will contact you for document collection</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary">3.</span>
                    <span>Complete account opening at your nearest branch</span>
                  </li>
                </ul>
              </div>

              <div className="flex gap-4 justify-center">
                <Button
                  onClick={() => navigate('/')}
                  variant="outline"
                  size="lg"
                >
                  Back to Dashboard
                </Button>
                <Button
                  onClick={() => {
                    setFormData(initialFormData);
                    setCurrentStep(1);
                    setIsSubmitted(false);
                    navigate('/new');
                  }}
                  size="lg"
                >
                  Start New Application
                </Button>
              </div>
            </motion.div>
          </motion.div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <FormHeader />
      
      <main className="container max-w-5xl mx-auto px-4 py-6 md:py-10">
        {/* Edit Mode Indicator */}
        {draftId && (
          <div className="mb-4 p-3 rounded-lg bg-accent border border-border">
            <p className="text-sm text-muted-foreground">
              <span className="font-medium text-foreground">Editing:</span> {formData.businessDetails.registeredName || draftId}
            </p>
          </div>
        )}

        {/* Progress */}
        <div className="mb-8 md:mb-12">
          <FormProgress steps={STEPS} currentStep={currentStep} />
        </div>

        {/* Step Content */}
        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
          >
            {currentStep === 1 && (
              <BusinessDetailsStep data={formData} onChange={updateFormData} />
            )}
            {currentStep === 2 && (
              <AccountTypeStep data={formData} onChange={updateFormData} />
            )}
            {currentStep === 3 && (
              <AccountParticularsStep data={formData} onChange={updateFormData} />
            )}
            {currentStep === 4 && (
              <BeneficialOwnersStep data={formData} onChange={updateFormData} />
            )}
            {currentStep === 5 && (
              <BoardResolutionStep data={formData} onChange={updateFormData} />
            )}
            {currentStep === 6 && (
              <TaxDeclarationStep data={formData} onChange={updateFormData} />
            )}
            {currentStep === 7 && (
              <BusinessServicesStep data={formData} onChange={updateFormData} />
            )}
            {currentStep === 8 && (
              <DebitCardStep data={formData} onChange={updateFormData} />
            )}
            {currentStep === 9 && (
              <GIROStep data={formData} onChange={updateFormData} />
            )}
            {currentStep === 10 && (
              <ReviewStep 
                data={formData} 
                onChange={updateFormData} 
                onEditStep={goToStep}
              />
            )}
          </motion.div>
        </AnimatePresence>

        {/* Navigation */}
        <div className="mt-8">
          <FormNavigation
            currentStep={currentStep}
            totalSteps={STEPS.length}
            onPrevious={handlePrevious}
            onNext={handleNext}
            onSubmit={handleSubmit}
            isSubmitting={isSubmitting}
            canProceed={canProceed()}
          />
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border mt-auto py-6">
        <div className="container max-w-5xl mx-auto px-4">
          <p className="text-sm text-muted-foreground text-center">
            © 2025 Business Banking Services. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}