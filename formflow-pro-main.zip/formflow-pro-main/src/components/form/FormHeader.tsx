import { motion } from 'framer-motion';
import { Building } from 'lucide-react';

export function FormHeader() {
  return (
    <motion.header
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="bg-card border-b border-border sticky top-0 z-50"
    >
      <div className="container max-w-5xl mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-primary text-primary-foreground shadow-primary">
              <Building className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-lg font-semibold font-display text-foreground">
                Business Account Application
              </h1>
              <p className="text-sm text-muted-foreground hidden sm:block">
                Apply for your business banking services
              </p>
            </div>
          </div>

          <div className="hidden sm:flex items-center gap-2 text-sm text-muted-foreground">
            <span>Need help?</span>
            <a
              href="tel:+6565381111"
              className="font-medium text-primary hover:underline"
            >
              6538 1111
            </a>
          </div>
        </div>
      </div>
    </motion.header>
  );
}
