import { Check } from 'lucide-react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

interface Step {
  id: number;
  title: string;
  shortTitle: string;
}

interface FormProgressProps {
  steps: Step[];
  currentStep: number;
}

export function FormProgress({ steps, currentStep }: FormProgressProps) {
  return (
    <div className="w-full">
      {/* Mobile: Simple progress bar */}
      <div className="md:hidden">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium text-foreground">
            Step {currentStep} of {steps.length}
          </span>
          <span className="text-sm text-muted-foreground">
            {steps[currentStep - 1]?.shortTitle}
          </span>
        </div>
        <div className="h-2 bg-muted rounded-full overflow-hidden">
          <motion.div
            className="h-full bg-primary rounded-full"
            initial={{ width: 0 }}
            animate={{ width: `${(currentStep / steps.length) * 100}%` }}
            transition={{ duration: 0.3, ease: 'easeOut' }}
          />
        </div>
      </div>

      {/* Desktop: Full stepper */}
      <div className="hidden md:block">
        <div className="flex items-start justify-between">
          {steps.map((step, index) => {
            const isCompleted = currentStep > step.id;
            const isCurrent = currentStep === step.id;
            const isPending = currentStep < step.id;

            return (
              <div key={step.id} className="flex flex-col items-center flex-1">
                <div className="flex items-center w-full">
                  {index > 0 && (
                    <div className="flex-1 h-0.5">
                      <motion.div
                        className={cn(
                          'h-full transition-colors duration-300',
                          isCompleted || isCurrent ? 'bg-primary' : 'bg-muted'
                        )}
                        initial={{ scaleX: 0 }}
                        animate={{ scaleX: isCompleted || isCurrent ? 1 : 0 }}
                        style={{ transformOrigin: 'left' }}
                        transition={{ duration: 0.3, delay: 0.1 }}
                      />
                    </div>
                  )}
                  
                  <motion.div
                    className={cn(
                      'step-indicator relative z-10',
                      isCompleted && 'step-completed',
                      isCurrent && 'step-active',
                      isPending && 'step-pending'
                    )}
                    initial={{ scale: 0.8 }}
                    animate={{ scale: isCurrent ? 1.1 : 1 }}
                    transition={{ duration: 0.2 }}
                  >
                    {isCompleted ? (
                      <Check className="w-5 h-5" />
                    ) : (
                      <span>{step.id}</span>
                    )}
                  </motion.div>

                  {index < steps.length - 1 && (
                    <div className="flex-1 h-0.5">
                      <div
                        className={cn(
                          'h-full transition-colors duration-300',
                          isCompleted ? 'bg-primary' : 'bg-muted'
                        )}
                      />
                    </div>
                  )}
                </div>

                <motion.div
                  className={cn(
                    'mt-3 text-center transition-colors duration-300',
                    isCurrent ? 'text-foreground' : 'text-muted-foreground'
                  )}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <p className={cn(
                    'text-sm font-medium',
                    isCurrent && 'text-primary'
                  )}>
                    {step.shortTitle}
                  </p>
                </motion.div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
