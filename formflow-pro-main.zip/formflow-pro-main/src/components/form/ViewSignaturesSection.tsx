import { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { PenLine, Save, Check, RotateCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { SignatureCanvas } from '@/components/form/SignatureCanvas';
import { AgreementSignature } from '@/types/form';
import { toast } from 'sonner';

interface ViewSignaturesSectionProps {
  signatures: AgreementSignature[];
  onSave: (signatures: AgreementSignature[]) => void;
  title?: string;
  disabled?: boolean;
}

export function ViewSignaturesSection({
  signatures,
  onSave,
  title = "Authorized Signatures",
  disabled = false,
}: ViewSignaturesSectionProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editableSignatures, setEditableSignatures] = useState<AgreementSignature[]>(signatures);
  const [hasChanges, setHasChanges] = useState(false);

  // Ensure we always have at least 3 signature slots when editing
  const ensureMinimumSignatures = useCallback((sigs: AgreementSignature[]) => {
    const minimum = 3;
    if (sigs.length >= minimum) return sigs;
    
    const newSigs = [...sigs];
    while (newSigs.length < minimum) {
      newSigs.push({
        id: `sig-new-${Date.now()}-${newSigs.length}`,
        name: '',
        signature: '',
        date: new Date().toISOString().split('T')[0],
      });
    }
    return newSigs;
  }, []);

  const handleStartEditing = () => {
    setEditableSignatures(ensureMinimumSignatures([...signatures]));
    setIsEditing(true);
    setHasChanges(false);
  };

  const handleCancelEditing = () => {
    setEditableSignatures(signatures);
    setIsEditing(false);
    setHasChanges(false);
  };

  const handleSave = () => {
    // Filter out empty signatures (no name and no signature)
    const validSignatures = editableSignatures.filter(
      sig => sig.name.trim() || sig.signature
    );
    
    onSave(validSignatures);
    setIsEditing(false);
    setHasChanges(false);
    toast.success('Signatures saved successfully!');
  };

  const updateSignature = (index: number, field: keyof AgreementSignature, value: string) => {
    const updated = [...editableSignatures];
    updated[index] = { ...updated[index], [field]: value };
    setEditableSignatures(updated);
    setHasChanges(true);
  };

  const addSignature = () => {
    setEditableSignatures([
      ...editableSignatures,
      {
        id: `sig-${Date.now()}`,
        name: '',
        signature: '',
        date: new Date().toISOString().split('T')[0],
      },
    ]);
    setHasChanges(true);
  };

  const removeSignature = (index: number) => {
    if (editableSignatures.length <= 1) return;
    const updated = editableSignatures.filter((_, i) => i !== index);
    setEditableSignatures(updated);
    setHasChanges(true);
  };

  // View mode - show existing signatures
  if (!isEditing) {
    return (
      <Card className="overflow-hidden">
        <CardHeader className="bg-muted/50 border-b border-border">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-lg">
              <PenLine className="w-5 h-5 text-primary" />
              {title}
            </CardTitle>
            {!disabled && (
              <Button variant="outline" size="sm" onClick={handleStartEditing}>
                <PenLine className="w-4 h-4 mr-2" />
                Edit Signatures
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent className="pt-4">
          {signatures.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">
              No signatures captured yet.
              {!disabled && " Click 'Edit Signatures' to add signatures."}
            </p>
          ) : (
            <div className="grid gap-4 md:grid-cols-3">
              {signatures.map((sig, idx) => (
                <motion.div
                  key={sig.id || idx}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  className="p-4 rounded-lg border border-border bg-card"
                >
                  <div className="space-y-2">
                    <div>
                      <p className="text-sm text-muted-foreground">Signatory {idx + 1}</p>
                      <p className="font-semibold">{sig.name || 'Unnamed'}</p>
                    </div>
                    {sig.signature ? (
                      <div className="border rounded-lg bg-white p-2 h-24 flex items-center justify-center overflow-hidden">
                        <img 
                          src={sig.signature} 
                          alt={`Signature of ${sig.name}`}
                          className="max-h-full max-w-full object-contain"
                          onError={(e) => {
                            // Handle broken images
                            (e.target as HTMLImageElement).style.display = 'none';
                          }}
                        />
                      </div>
                    ) : (
                      <div className="border-2 border-dashed rounded-lg h-20 flex items-center justify-center text-muted-foreground text-sm">
                        No signature
                      </div>
                    )}
                    <p className="text-xs text-muted-foreground">
                      Date: {sig.date || 'Not specified'}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    );
  }

  // Edit mode
  return (
    <Card className="overflow-hidden border-primary/50">
      <CardHeader className="bg-primary/5 border-b border-primary/20">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-lg">
            <PenLine className="w-5 h-5 text-primary" />
            {title}
            <span className="text-sm font-normal text-muted-foreground">(Editing)</span>
          </CardTitle>
          <div className="flex gap-2">
            <Button variant="ghost" size="sm" onClick={handleCancelEditing}>
              <RotateCcw className="w-4 h-4 mr-2" />
              Cancel
            </Button>
            <Button 
              size="sm" 
              onClick={handleSave}
              disabled={!hasChanges}
              className="bg-primary hover:bg-primary/90"
            >
              <Save className="w-4 h-4 mr-2" />
              Confirm & Save
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-6">
        <div className="space-y-6">
          <AnimatePresence mode="popLayout">
            {editableSignatures.map((sig, idx) => (
              <motion.div
                key={sig.id}
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="p-4 rounded-xl border border-border bg-muted/30"
              >
                <div className="flex items-center justify-between mb-4">
                  <h4 className="font-semibold text-primary">Signatory {idx + 1}</h4>
                  {editableSignatures.length > 1 && (
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => removeSignature(idx)}
                      className="text-destructive hover:text-destructive hover:bg-destructive/10"
                    >
                      Remove
                    </Button>
                  )}
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label>Full Name</Label>
                    <Input
                      value={sig.name}
                      onChange={(e) => updateSignature(idx, 'name', e.target.value)}
                      placeholder="Enter signatory name"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Date</Label>
                    <Input
                      type="date"
                      value={sig.date}
                      onChange={(e) => updateSignature(idx, 'date', e.target.value)}
                    />
                  </div>
                </div>

                <div className="mt-4">
                  <SignatureCanvas
                    value={sig.signature}
                    onChange={(signature) => updateSignature(idx, 'signature', signature)}
                    label="Signature"
                  />
                </div>
              </motion.div>
            ))}
          </AnimatePresence>

          <Button
            type="button"
            variant="outline"
            onClick={addSignature}
            className="w-full"
          >
            + Add Another Signatory
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
