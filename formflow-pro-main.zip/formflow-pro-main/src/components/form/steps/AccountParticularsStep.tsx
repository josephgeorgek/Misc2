import { motion } from 'framer-motion';
import { Wallet, QrCode, Building, Check } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { FormData } from '@/types/form';
import { cn } from '@/lib/utils';

interface AccountParticularsStepProps {
  data: FormData;
  onChange: (data: Partial<FormData>) => void;
}

const sourceOptions = [
  { id: 'business-operations', label: 'Business Operations' },
  { id: 'investment', label: 'Investment' },
  { id: 'business-income', label: 'Business Income' },
  { id: 'capital-contribution', label: 'Capital Contribution' },
  { id: 'others', label: 'Others' },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
};

export function AccountParticularsStep({ data, onChange }: AccountParticularsStepProps) {
  const updateParticulars = (field: string, value: string | boolean | string[]) => {
    onChange({
      accountParticulars: { ...data.accountParticulars, [field]: value },
    });
  };

  const toggleSource = (sourceId: string) => {
    const current = data.accountParticulars.sourceOfCapital;
    const updated = current.includes(sourceId)
      ? current.filter((id) => id !== sourceId)
      : [...current, sourceId];
    updateParticulars('sourceOfCapital', updated);
  };

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-8"
    >
      {/* Account Particulars */}
      <motion.div variants={itemVariants} className="form-section">
        <div className="flex items-center gap-3 mb-6">
          <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-accent">
            <Wallet className="w-5 h-5 text-accent-foreground" />
          </div>
          <div>
            <h3 className="text-lg font-semibold font-display text-foreground">Account Details</h3>
            <p className="text-sm text-muted-foreground">Specify how the account will be used</p>
          </div>
        </div>

        <div className="space-y-6">
          <div>
            <Label className="form-label">Source of Capital/Revenue/Wealth *</Label>
            <p className="text-sm text-muted-foreground mb-3">Select all that apply</p>
            <div className="flex flex-wrap gap-3">
              {sourceOptions.map((option) => {
                const isSelected = data.accountParticulars.sourceOfCapital.includes(option.id);
                return (
                  <motion.button
                    key={option.id}
                    type="button"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => toggleSource(option.id)}
                    className={cn(
                      'px-4 py-2 rounded-full border-2 text-sm font-medium transition-all duration-200',
                      isSelected
                        ? 'border-primary bg-primary text-primary-foreground'
                        : 'border-border bg-card hover:border-primary/50 text-foreground'
                    )}
                  >
                    {option.label}
                  </motion.button>
                );
              })}
            </div>
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            <div>
              <Label htmlFor="accountName" className="form-label">
                Account Name
              </Label>
              <Input
                id="accountName"
                value={data.accountParticulars.accountName}
                onChange={(e) => updateParticulars('accountName', e.target.value)}
                placeholder="If different from registered name"
                className="h-12"
              />
              <p className="form-description">Leave blank to use registered business name</p>
            </div>

            <div className="md:col-span-2">
              <Label htmlFor="mailingAddress" className="form-label">
                Mailing Address
              </Label>
              <Textarea
                id="mailingAddress"
                value={data.accountParticulars.mailingAddress}
                onChange={(e) => updateParticulars('mailingAddress', e.target.value)}
                placeholder="If different from registered address"
                className="min-h-[100px] resize-none"
              />
              <p className="form-description">Leave blank to use registered business address</p>
            </div>
          </div>
        </div>
      </motion.div>

      {/* PayNow Sign Up */}
      <motion.div variants={itemVariants} className="form-section">
        <div className="flex items-center gap-3 mb-6">
          <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-accent">
            <QrCode className="w-5 h-5 text-accent-foreground" />
          </div>
          <div>
            <h3 className="text-lg font-semibold font-display text-foreground">PayNow Registration</h3>
            <p className="text-sm text-muted-foreground">Receive payments using your UEN</p>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-muted/50 border border-border mb-6">
          <p className="text-sm text-muted-foreground">
            PayNow allows you to receive money using your Unique Entity Number (UEN) without 
            sharing your account number. Customers can pay you instantly using your UEN.
          </p>
        </div>

        <div className="flex items-center justify-between p-4 rounded-xl border border-border">
          <div>
            <p className="font-medium text-foreground">Sign up for PayNow</p>
            <p className="text-sm text-muted-foreground">Link your UEN to receive payments</p>
          </div>
          <Switch
            checked={data.accountParticulars.payNowSignUp}
            onCheckedChange={(checked) => updateParticulars('payNowSignUp', checked)}
          />
        </div>
      </motion.div>

      {/* SGQR Sign Up */}
      {data.accountParticulars.payNowSignUp && (
        <motion.div
          variants={itemVariants}
          initial="hidden"
          animate="visible"
          className="form-section"
        >
          <div className="flex items-center gap-3 mb-6">
            <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-accent">
              <Building className="w-5 h-5 text-accent-foreground" />
            </div>
            <div>
              <h3 className="text-lg font-semibold font-display text-foreground">SGQR Label</h3>
              <p className="text-sm text-muted-foreground">Combine multiple QR payment options into one</p>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-muted/50 border border-border mb-6">
            <p className="text-sm text-muted-foreground">
              Singapore Quick Response Code (SGQR) helps you combine multiple QR payment options, 
              including PayNow QR, into one label for your customers.
            </p>
          </div>

          <div className="flex items-center justify-between p-4 rounded-xl border border-border mb-6">
            <div>
              <p className="font-medium text-foreground">Sign up for SGQR</p>
              <p className="text-sm text-muted-foreground">Get your SGQR label</p>
            </div>
            <Switch
              checked={data.accountParticulars.sgqrSignUp}
              onCheckedChange={(checked) => updateParticulars('sgqrSignUp', checked)}
            />
          </div>

          {data.accountParticulars.sgqrSignUp && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="space-y-6"
            >
              <RadioGroup
                value={data.accountParticulars.sgqrOption}
                onValueChange={(value) => updateParticulars('sgqrOption', value as 'create' | 'update')}
                className="space-y-3"
              >
                <div className="flex items-center space-x-3 p-4 rounded-xl border border-border">
                  <RadioGroupItem value="create" id="sgqr-create" />
                  <Label htmlFor="sgqr-create" className="flex-1 cursor-pointer">
                    <span className="font-medium">Create new SGQR label</span>
                    <p className="text-sm text-muted-foreground">I don't have an existing SGQR</p>
                  </Label>
                </div>
                <div className="flex items-center space-x-3 p-4 rounded-xl border border-border">
                  <RadioGroupItem value="update" id="sgqr-update" />
                  <Label htmlFor="sgqr-update" className="flex-1 cursor-pointer">
                    <span className="font-medium">Update existing SGQR label</span>
                    <p className="text-sm text-muted-foreground">Add PayNow to my existing SGQR</p>
                  </Label>
                </div>
              </RadioGroup>

              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <Label htmlFor="outletName1" className="form-label">
                    Name on Label (Outlet 1)
                  </Label>
                  <Input
                    id="outletName1"
                    value={data.accountParticulars.outletName1}
                    onChange={(e) => updateParticulars('outletName1', e.target.value)}
                    placeholder="Max 25 characters"
                    maxLength={25}
                    className="h-12"
                  />
                  <p className="form-description">{data.accountParticulars.outletName1.length}/25 characters</p>
                </div>

                <div>
                  <Label htmlFor="outletName2" className="form-label">
                    Name on Label (Outlet 2)
                  </Label>
                  <Input
                    id="outletName2"
                    value={data.accountParticulars.outletName2}
                    onChange={(e) => updateParticulars('outletName2', e.target.value)}
                    placeholder="Optional - Max 25 characters"
                    maxLength={25}
                    className="h-12"
                  />
                  <p className="form-description">{data.accountParticulars.outletName2.length}/25 characters</p>
                </div>
              </div>
            </motion.div>
          )}
        </motion.div>
      )}
    </motion.div>
  );
}
