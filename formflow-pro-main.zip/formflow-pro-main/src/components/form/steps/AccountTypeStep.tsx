import { motion } from 'framer-motion';
import { Banknote, Globe2, Check } from 'lucide-react';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { FormData } from '@/types/form';
import { cn } from '@/lib/utils';

interface AccountTypeStepProps {
  data: FormData;
  onChange: (data: Partial<FormData>) => void;
}

const sgdAccounts = [
  { id: 'sgd-current', label: 'SGD Current Account', description: 'Standard business current account' },
  { id: 'business-growth', label: 'Business Growth Account', description: 'Higher interest for growing businesses' },
  { id: 'entrepreneur-plus', label: 'Business Entrepreneur Account Plus', description: 'For startups and entrepreneurs' },
  { id: 'sgd-time-deposit', label: 'SGD Time Deposit', description: 'Fixed deposit with competitive rates' },
];

const foreignCurrencyAccounts = [
  { id: 'multi-currency', label: 'Multi-Currency Business Account', description: 'Hold and transact in multiple currencies' },
  { id: 'call-deposit', label: 'Call Deposit Account', description: 'Flexible foreign currency savings' },
  { id: 'fcy-time-deposit', label: 'Foreign Currency Time Deposit', description: 'Fixed deposits in foreign currency' },
  { id: 'usd-chequing', label: 'USD Chequing Account', description: 'USD current account with cheque facility' },
];

const currencies = [
  { id: 'usd', label: 'USD', flag: '🇺🇸' },
  { id: 'eur', label: 'EUR', flag: '🇪🇺' },
  { id: 'gbp', label: 'GBP', flag: '🇬🇧' },
  { id: 'aud', label: 'AUD', flag: '🇦🇺' },
  { id: 'jpy', label: 'JPY', flag: '🇯🇵' },
  { id: 'hkd', label: 'HKD', flag: '🇭🇰' },
  { id: 'cny', label: 'CNY', flag: '🇨🇳' },
  { id: 'nzd', label: 'NZD', flag: '🇳🇿' },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
};

export function AccountTypeStep({ data, onChange }: AccountTypeStepProps) {
  const toggleAccount = (type: 'sgdAccounts' | 'foreignCurrencyAccounts', accountId: string) => {
    const current = data.accountType[type];
    const updated = current.includes(accountId)
      ? current.filter((id) => id !== accountId)
      : [...current, accountId];
    
    onChange({
      accountType: { ...data.accountType, [type]: updated },
    });
  };

  const toggleCurrency = (currencyId: string) => {
    const current = data.accountType.currencies;
    const updated = current.includes(currencyId)
      ? current.filter((id) => id !== currencyId)
      : [...current, currencyId];
    
    onChange({
      accountType: { ...data.accountType, currencies: updated },
    });
  };

  const hasForeignAccounts = data.accountType.foreignCurrencyAccounts.length > 0;

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-8"
    >
      {/* SGD Accounts */}
      <motion.div variants={itemVariants} className="form-section">
        <div className="flex items-center gap-3 mb-6">
          <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-accent">
            <Banknote className="w-5 h-5 text-accent-foreground" />
          </div>
          <div>
            <h3 className="text-lg font-semibold font-display text-foreground">Singapore Dollar Accounts</h3>
            <p className="text-sm text-muted-foreground">Select the SGD accounts you need</p>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          {sgdAccounts.map((account) => {
            const isSelected = data.accountType.sgdAccounts.includes(account.id);
            return (
              <motion.div
                key={account.id}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <div
                  onClick={() => toggleAccount('sgdAccounts', account.id)}
                  className={cn(
                    'relative p-4 rounded-xl border-2 cursor-pointer transition-all duration-200',
                    isSelected
                      ? 'border-primary bg-accent shadow-soft'
                      : 'border-border hover:border-primary/50 hover:bg-muted/50'
                  )}
                >
                  <div className="flex items-start gap-3">
                    <div
                      className={cn(
                        'flex items-center justify-center w-5 h-5 rounded-md border-2 transition-colors mt-0.5',
                        isSelected
                          ? 'bg-primary border-primary text-primary-foreground'
                          : 'border-muted-foreground/30'
                      )}
                    >
                      {isSelected && <Check className="w-3 h-3" />}
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-foreground">{account.label}</p>
                      <p className="text-sm text-muted-foreground mt-1">{account.description}</p>
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </motion.div>

      {/* Foreign Currency Accounts */}
      <motion.div variants={itemVariants} className="form-section">
        <div className="flex items-center gap-3 mb-6">
          <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-accent">
            <Globe2 className="w-5 h-5 text-accent-foreground" />
          </div>
          <div>
            <h3 className="text-lg font-semibold font-display text-foreground">Foreign Currency Accounts</h3>
            <p className="text-sm text-muted-foreground">Optional - Select if you need foreign currency accounts</p>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          {foreignCurrencyAccounts.map((account) => {
            const isSelected = data.accountType.foreignCurrencyAccounts.includes(account.id);
            return (
              <motion.div
                key={account.id}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <div
                  onClick={() => toggleAccount('foreignCurrencyAccounts', account.id)}
                  className={cn(
                    'relative p-4 rounded-xl border-2 cursor-pointer transition-all duration-200',
                    isSelected
                      ? 'border-primary bg-accent shadow-soft'
                      : 'border-border hover:border-primary/50 hover:bg-muted/50'
                  )}
                >
                  <div className="flex items-start gap-3">
                    <div
                      className={cn(
                        'flex items-center justify-center w-5 h-5 rounded-md border-2 transition-colors mt-0.5',
                        isSelected
                          ? 'bg-primary border-primary text-primary-foreground'
                          : 'border-muted-foreground/30'
                      )}
                    >
                      {isSelected && <Check className="w-3 h-3" />}
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-foreground">{account.label}</p>
                      <p className="text-sm text-muted-foreground mt-1">{account.description}</p>
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </motion.div>

      {/* Currency Selection */}
      {hasForeignAccounts && (
        <motion.div
          variants={itemVariants}
          initial="hidden"
          animate="visible"
          className="form-section"
        >
          <div className="mb-6">
            <h3 className="text-lg font-semibold font-display text-foreground">Select Currencies</h3>
            <p className="text-sm text-muted-foreground mt-1">
              Choose the currencies you want to transact in
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {currencies.map((currency) => {
              const isSelected = data.accountType.currencies.includes(currency.id);
              return (
                <motion.div
                  key={currency.id}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <div
                    onClick={() => toggleCurrency(currency.id)}
                    className={cn(
                      'flex items-center justify-center gap-2 p-3 rounded-xl border-2 cursor-pointer transition-all duration-200',
                      isSelected
                        ? 'border-primary bg-accent shadow-soft'
                        : 'border-border hover:border-primary/50 hover:bg-muted/50'
                    )}
                  >
                    <span className="text-xl">{currency.flag}</span>
                    <span className="font-medium text-foreground">{currency.label}</span>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </motion.div>
      )}

      {/* Important Note */}
      <motion.div variants={itemVariants} className="p-4 rounded-xl bg-muted/50 border border-border">
        <div className="flex gap-3">
          <div className="flex-shrink-0 w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
            <span className="text-lg">💡</span>
          </div>
          <div>
            <h4 className="font-semibold text-foreground">Deposit Insurance Scheme</h4>
            <p className="text-sm text-muted-foreground mt-1">
              Singapore dollar deposits are insured by the Singapore Deposit Insurance Corporation, 
              for up to S$100,000 per depositor per Scheme member. Foreign currency deposits are not insured.
            </p>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}
