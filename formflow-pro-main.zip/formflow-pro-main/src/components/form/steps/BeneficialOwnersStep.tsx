import { motion, AnimatePresence } from 'framer-motion';
import { Users, Plus, Trash2, UserCheck, PenLine } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Textarea } from '@/components/ui/textarea';
import { FormData, BeneficialOwner } from '@/types/form';
import { cn } from '@/lib/utils';

interface BeneficialOwnersStepProps {
  data: FormData;
  onChange: (data: Partial<FormData>) => void;
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
};

export function BeneficialOwnersStep({ data, onChange }: BeneficialOwnersStepProps) {
  const addOwner = () => {
    const newOwner: BeneficialOwner = {
      id: crypto.randomUUID(),
      fullName: '',
      nricPassport: '',
      designation: '',
      isBeneficialOwner: true,
      isAuthorisedSignatory: false,
      mobileNumber: '',
      officeNumber: '',
      email: '',
      grouping: '',
      signature: '',
    };
    onChange({
      beneficialOwners: [...data.beneficialOwners, newOwner],
    });
  };

  const removeOwner = (id: string) => {
    onChange({
      beneficialOwners: data.beneficialOwners.filter((owner) => owner.id !== id),
    });
  };

  const updateOwner = (id: string, field: keyof BeneficialOwner, value: string | boolean) => {
    onChange({
      beneficialOwners: data.beneficialOwners.map((owner) =>
        owner.id === id ? { ...owner, [field]: value } : owner
      ),
    });
  };

  const updateSigningCondition = (field: 'type' | 'details', value: string) => {
    onChange({
      signingCondition: { ...data.signingCondition, [field]: value },
    });
  };

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-8"
    >
      {/* Beneficial Owners List */}
      <motion.div variants={itemVariants} className="form-section">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-accent">
              <Users className="w-5 h-5 text-accent-foreground" />
            </div>
            <div>
              <h3 className="text-lg font-semibold font-display text-foreground">
                Beneficial Owners & Signatories
              </h3>
              <p className="text-sm text-muted-foreground">
                Persons who own/control the company and authorized signatories
              </p>
            </div>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-muted/50 border border-border mb-6">
          <div className="flex gap-3">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
              <span className="text-sm">ℹ️</span>
            </div>
            <div className="text-sm text-muted-foreground">
              <p className="font-medium text-foreground mb-1">Important</p>
              <p>
                <strong>Beneficial Owner:</strong> Person(s) who ultimately own and/or control the 
                management of the company.
              </p>
              <p className="mt-2">
                <strong>Authorised Signatory:</strong> Authorised to operate the account by way of 
                cheques, orders to pay, bills of exchange and other instruments.
              </p>
            </div>
          </div>
        </div>

        <AnimatePresence mode="popLayout">
          {data.beneficialOwners.map((owner, index) => (
            <motion.div
              key={owner.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.2 }}
              className="relative p-6 rounded-xl border border-border bg-card mb-4 last:mb-0"
            >
              <div className="flex items-center justify-between mb-4">
                <h4 className="font-semibold text-foreground">Person {index + 1}</h4>
                {data.beneficialOwners.length > 1 && (
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => removeOwner(owner.id)}
                    className="text-destructive hover:text-destructive hover:bg-destructive/10"
                  >
                    <Trash2 className="w-4 h-4 mr-1" />
                    Remove
                  </Button>
                )}
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <Label className="form-label">Full Name *</Label>
                  <Input
                    value={owner.fullName}
                    onChange={(e) => updateOwner(owner.id, 'fullName', e.target.value)}
                    placeholder="As per NRIC/Passport"
                    className="h-12"
                  />
                </div>

                <div>
                  <Label className="form-label">NRIC/Passport Number *</Label>
                  <Input
                    value={owner.nricPassport}
                    onChange={(e) => updateOwner(owner.id, 'nricPassport', e.target.value)}
                    placeholder="S1234567A"
                    className="h-12"
                  />
                </div>

                <div>
                  <Label className="form-label">Designation/Title *</Label>
                  <Input
                    value={owner.designation}
                    onChange={(e) => updateOwner(owner.id, 'designation', e.target.value)}
                    placeholder="e.g. Director, Partner"
                    className="h-12"
                  />
                </div>

                <div>
                  <Label className="form-label">Email Address *</Label>
                  <Input
                    type="email"
                    value={owner.email}
                    onChange={(e) => updateOwner(owner.id, 'email', e.target.value)}
                    placeholder="email@company.com"
                    className="h-12"
                  />
                </div>

                <div>
                  <Label className="form-label">Mobile Number *</Label>
                  <Input
                    value={owner.mobileNumber}
                    onChange={(e) => updateOwner(owner.id, 'mobileNumber', e.target.value)}
                    placeholder="+65 9XXX XXXX"
                    className="h-12"
                  />
                </div>
              </div>

              <div className="flex flex-wrap gap-4 mt-4 pt-4 border-t border-border">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id={`beneficial-${owner.id}`}
                    checked={owner.isBeneficialOwner}
                    onCheckedChange={(checked) =>
                      updateOwner(owner.id, 'isBeneficialOwner', checked as boolean)
                    }
                  />
                  <Label htmlFor={`beneficial-${owner.id}`} className="flex items-center gap-2 cursor-pointer">
                    <UserCheck className="w-4 h-4 text-muted-foreground" />
                    <span>Beneficial Owner</span>
                  </Label>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id={`signatory-${owner.id}`}
                    checked={owner.isAuthorisedSignatory}
                    onCheckedChange={(checked) =>
                      updateOwner(owner.id, 'isAuthorisedSignatory', checked as boolean)
                    }
                  />
                  <Label htmlFor={`signatory-${owner.id}`} className="flex items-center gap-2 cursor-pointer">
                    <PenLine className="w-4 h-4 text-muted-foreground" />
                    <span>Authorised Signatory</span>
                  </Label>
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        <Button
          type="button"
          variant="outline"
          onClick={addOwner}
          className="w-full h-12 border-dashed"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Another Person
        </Button>
      </motion.div>

      {/* Signing Condition */}
      <motion.div variants={itemVariants} className="form-section">
        <div className="flex items-center gap-3 mb-6">
          <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-accent">
            <PenLine className="w-5 h-5 text-accent-foreground" />
          </div>
          <div>
            <h3 className="text-lg font-semibold font-display text-foreground">Signing Condition</h3>
            <p className="text-sm text-muted-foreground">How transactions will be authorised</p>
          </div>
        </div>

        <RadioGroup
          value={data.signingCondition.type}
          onValueChange={(value) => updateSigningCondition('type', value)}
          className="space-y-3 mb-6"
        >
          <div
            className={cn(
              'flex items-center space-x-3 p-4 rounded-xl border-2 transition-colors cursor-pointer',
              data.signingCondition.type === 'singly'
                ? 'border-primary bg-accent'
                : 'border-border hover:border-primary/50'
            )}
          >
            <RadioGroupItem value="singly" id="signing-singly" />
            <Label htmlFor="signing-singly" className="flex-1 cursor-pointer">
              <span className="font-medium">Singly</span>
              <p className="text-sm text-muted-foreground">
                Any one authorised signatory can approve transactions
              </p>
            </Label>
          </div>

          <div
            className={cn(
              'flex items-center space-x-3 p-4 rounded-xl border-2 transition-colors cursor-pointer',
              data.signingCondition.type === 'anyTwo'
                ? 'border-primary bg-accent'
                : 'border-border hover:border-primary/50'
            )}
          >
            <RadioGroupItem value="anyTwo" id="signing-any-two" />
            <Label htmlFor="signing-any-two" className="flex-1 cursor-pointer">
              <span className="font-medium">Any Two Jointly</span>
              <p className="text-sm text-muted-foreground">
                Any two authorised signatories must approve transactions together
              </p>
            </Label>
          </div>

          <div
            className={cn(
              'flex items-center space-x-3 p-4 rounded-xl border-2 transition-colors cursor-pointer',
              data.signingCondition.type === 'grouping'
                ? 'border-primary bg-accent'
                : 'border-border hover:border-primary/50'
            )}
          >
            <RadioGroupItem value="grouping" id="signing-grouping" />
            <Label htmlFor="signing-grouping" className="flex-1 cursor-pointer">
              <span className="font-medium">Grouping with Signing Limits</span>
              <p className="text-sm text-muted-foreground">
                Custom grouping and limits for different transaction amounts
              </p>
            </Label>
          </div>
        </RadioGroup>

        {data.signingCondition.type === 'grouping' && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
          >
            <Label className="form-label">Specify Grouping and Signing Limits</Label>
            <Textarea
              value={data.signingCondition.details}
              onChange={(e) => updateSigningCondition('details', e.target.value)}
              placeholder="e.g. Group A (Directors): Any 2 for amounts above $50,000. Group B (Managers): Any 1 for amounts up to $50,000."
              className="min-h-[100px]"
            />
          </motion.div>
        )}
      </motion.div>
    </motion.div>
  );
}
