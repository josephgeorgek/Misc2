import { motion } from 'framer-motion';
import { FileText, Plus, Trash2, Users, PenLine } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { FormData, AuthorisedPerson, DirectorSignature } from '@/types/form';
import { SignatureCanvas } from '../SignatureCanvas';

interface BoardResolutionStepProps {
  data: FormData;
  onChange: (data: Partial<FormData>) => void;
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
};

export function BoardResolutionStep({ data, onChange }: BoardResolutionStepProps) {
  const updateResolution = (field: string, value: string | boolean | AuthorisedPerson[] | DirectorSignature[]) => {
    onChange({
      boardResolution: { ...data.boardResolution, [field]: value },
    });
  };

  const addAuthorisedPerson = () => {
    const newPerson: AuthorisedPerson = {
      id: crypto.randomUUID(),
      fullName: '',
      nricPassport: '',
      designation: '',
      signature: '',
    };
    updateResolution('authorisedPersons', [...data.boardResolution.authorisedPersons, newPerson]);
  };

  const updateAuthorisedPerson = (id: string, field: string, value: string) => {
    const updated = data.boardResolution.authorisedPersons.map((person) =>
      person.id === id ? { ...person, [field]: value } : person
    );
    updateResolution('authorisedPersons', updated);
  };

  const removeAuthorisedPerson = (id: string) => {
    updateResolution(
      'authorisedPersons',
      data.boardResolution.authorisedPersons.filter((p) => p.id !== id)
    );
  };

  const addDirectorSignature = () => {
    const newSignature: DirectorSignature = {
      id: crypto.randomUUID(),
      name: '',
      signature: '',
      date: '',
    };
    updateResolution('directorSignatures', [...data.boardResolution.directorSignatures, newSignature]);
  };

  const updateDirectorSignature = (id: string, field: string, value: string) => {
    const updated = data.boardResolution.directorSignatures.map((sig) =>
      sig.id === id ? { ...sig, [field]: value } : sig
    );
    updateResolution('directorSignatures', updated);
  };

  const removeDirectorSignature = (id: string) => {
    updateResolution(
      'directorSignatures',
      data.boardResolution.directorSignatures.filter((s) => s.id !== id)
    );
  };

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-8"
    >
      {/* Header Info */}
      <motion.div variants={itemVariants} className="form-section">
        <div className="flex items-center gap-3 mb-6">
          <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-accent">
            <FileText className="w-5 h-5 text-accent-foreground" />
          </div>
          <div>
            <h3 className="text-lg font-semibold font-display text-foreground">Board Resolution</h3>
            <p className="text-sm text-muted-foreground">For Private Limited/Public Company</p>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          <div>
            <Label htmlFor="companyName" className="form-label">
              Company Name
            </Label>
            <Input
              id="companyName"
              value={data.boardResolution.companyName || data.businessDetails.registeredName}
              onChange={(e) => updateResolution('companyName', e.target.value)}
              placeholder="As per ACRA records"
              className="h-12"
            />
          </div>
          <div>
            <Label htmlFor="meetingDate" className="form-label">
              Date of Board Meeting
            </Label>
            <Input
              id="meetingDate"
              type="date"
              value={data.boardResolution.meetingDate}
              onChange={(e) => updateResolution('meetingDate', e.target.value)}
              className="h-12"
            />
          </div>
        </div>

        <div className="mt-4 flex items-center space-x-3 p-4 rounded-xl border border-border">
          <Switch
            id="resolutionPassed"
            checked={data.boardResolution.resolutionPassed}
            onCheckedChange={(checked) => updateResolution('resolutionPassed', checked)}
          />
          <Label htmlFor="resolutionPassed" className="cursor-pointer">
            <span className="font-medium text-foreground">Resolution Passed</span>
            <p className="text-sm text-muted-foreground">
              Board resolution has been duly passed and recorded
            </p>
          </Label>
        </div>
      </motion.div>

      {/* Authorized Activities */}
      <motion.div variants={itemVariants} className="form-section">
        <h4 className="text-base font-semibold text-foreground mb-4">
          The Company authorises the Bank to:
        </h4>
        <div className="space-y-3">
          <div className="flex items-center space-x-3 p-3 rounded-lg hover:bg-muted/50 transition-colors">
            <Checkbox
              id="openCloseAccounts"
              checked={data.boardResolution.openCloseAccounts}
              onCheckedChange={(checked) => updateResolution('openCloseAccounts', checked as boolean)}
            />
            <Label htmlFor="openCloseAccounts" className="cursor-pointer flex-1">
              Open, operate and close account(s) in our name and to accept all terms and conditions
            </Label>
          </div>
          <div className="flex items-center space-x-3 p-3 rounded-lg hover:bg-muted/50 transition-colors">
            <Checkbox
              id="applyBankingServices"
              checked={data.boardResolution.applyBankingServices}
              onCheckedChange={(checked) => updateResolution('applyBankingServices', checked as boolean)}
            />
            <Label htmlFor="applyBankingServices" className="cursor-pointer flex-1">
              Apply for and use business banking services (OCBC Velocity, Debit Card, etc.)
            </Label>
          </div>
          <div className="flex items-center space-x-3 p-3 rounded-lg hover:bg-muted/50 transition-colors">
            <Checkbox
              id="appointAuthorisedUsers"
              checked={data.boardResolution.appointAuthorisedUsers}
              onCheckedChange={(checked) => updateResolution('appointAuthorisedUsers', checked as boolean)}
            />
            <Label htmlFor="appointAuthorisedUsers" className="cursor-pointer flex-1">
              Appoint Authorised Users for OCBC Velocity internet banking
            </Label>
          </div>
          <div className="flex items-center space-x-3 p-3 rounded-lg hover:bg-muted/50 transition-colors">
            <Checkbox
              id="appointAuthorisedSignatories"
              checked={data.boardResolution.appointAuthorisedSignatories}
              onCheckedChange={(checked) => updateResolution('appointAuthorisedSignatories', checked as boolean)}
            />
            <Label htmlFor="appointAuthorisedSignatories" className="cursor-pointer flex-1">
              Appoint Authorised Signatories to sign on behalf of the Company
            </Label>
          </div>
          <div className="flex items-center space-x-3 p-3 rounded-lg hover:bg-muted/50 transition-colors">
            <Checkbox
              id="borrowingAndSecurity"
              checked={data.boardResolution.borrowingAndSecurity}
              onCheckedChange={(checked) => updateResolution('borrowingAndSecurity', checked as boolean)}
            />
            <Label htmlFor="borrowingAndSecurity" className="cursor-pointer flex-1">
              Borrowing money and providing security to the Bank
            </Label>
          </div>
          <div className="flex items-center space-x-3 p-3 rounded-lg hover:bg-muted/50 transition-colors">
            <Checkbox
              id="corporateCreditCard"
              checked={data.boardResolution.corporateCreditCard}
              onCheckedChange={(checked) => updateResolution('corporateCreditCard', checked as boolean)}
            />
            <Label htmlFor="corporateCreditCard" className="cursor-pointer flex-1">
              Apply for Corporate Credit Card(s)
            </Label>
          </div>
          <div className="flex items-center space-x-3 p-3 rounded-lg hover:bg-muted/50 transition-colors">
            <Checkbox
              id="electronicSigning"
              checked={data.boardResolution.electronicSigning}
              onCheckedChange={(checked) => updateResolution('electronicSigning', checked as boolean)}
            />
            <Label htmlFor="electronicSigning" className="cursor-pointer flex-1">
              Accept electronic signing and digital authentication methods
            </Label>
          </div>
        </div>
      </motion.div>

      {/* Schedule of Authorised Persons */}
      <motion.div variants={itemVariants} className="form-section">
        <div className="flex items-center gap-3 mb-6">
          <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-accent">
            <Users className="w-5 h-5 text-accent-foreground" />
          </div>
          <div>
            <h3 className="text-lg font-semibold font-display text-foreground">Schedule of Authorised Persons</h3>
            <p className="text-sm text-muted-foreground">Persons authorised to operate account(s) and sign</p>
          </div>
        </div>

        <div className="space-y-4">
          {data.boardResolution.authorisedPersons.map((person, index) => (
            <motion.div
              key={person.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-4 rounded-xl border border-border space-y-4"
            >
              <div className="flex items-center justify-between">
                <h5 className="font-medium text-foreground">Authorised Person {index + 1}</h5>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => removeAuthorisedPerson(person.id)}
                  className="text-destructive hover:text-destructive"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>

              <div className="grid gap-4 md:grid-cols-3">
                <div>
                  <Label className="form-label">Full Name *</Label>
                  <Input
                    value={person.fullName}
                    onChange={(e) => updateAuthorisedPerson(person.id, 'fullName', e.target.value)}
                    placeholder="As per NRIC/Passport"
                    className="h-12"
                  />
                </div>
                <div>
                  <Label className="form-label">NRIC/Passport *</Label>
                  <Input
                    value={person.nricPassport}
                    onChange={(e) => updateAuthorisedPerson(person.id, 'nricPassport', e.target.value)}
                    placeholder="e.g., S1234567A"
                    className="h-12"
                  />
                </div>
                <div>
                  <Label className="form-label">Designation *</Label>
                  <Input
                    value={person.designation}
                    onChange={(e) => updateAuthorisedPerson(person.id, 'designation', e.target.value)}
                    placeholder="e.g., Director, CFO"
                    className="h-12"
                  />
                </div>
              </div>

              {/* Signature Canvas */}
              <SignatureCanvas
                value={person.signature}
                onChange={(signature) => updateAuthorisedPerson(person.id, 'signature', signature)}
                label="Specimen Signature *"
              />
            </motion.div>
          ))}

          <Button
            type="button"
            variant="outline"
            onClick={addAuthorisedPerson}
            className="w-full h-12 border-dashed"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Authorised Person
          </Button>
        </div>

        <div className="mt-6 space-y-4">
          <div>
            <Label htmlFor="signingMandate" className="form-label">
              Signing Mandate
            </Label>
            <Textarea
              id="signingMandate"
              value={data.boardResolution.signingMandate}
              onChange={(e) => updateResolution('signingMandate', e.target.value)}
              placeholder="e.g., Any two directors jointly, Any one director singly for amounts up to..."
              className="min-h-[80px]"
            />
          </div>
          <div>
            <Label htmlFor="signingLimits" className="form-label">
              Signing Limits (if applicable)
            </Label>
            <Textarea
              id="signingLimits"
              value={data.boardResolution.signingLimits}
              onChange={(e) => updateResolution('signingLimits', e.target.value)}
              placeholder="Specify currency and amount limits for each group"
              className="min-h-[80px]"
            />
          </div>
        </div>
      </motion.div>

      {/* Director Signatures */}
      <motion.div variants={itemVariants} className="form-section">
        <div className="flex items-center gap-3 mb-6">
          <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-accent">
            <PenLine className="w-5 h-5 text-accent-foreground" />
          </div>
          <div>
            <h3 className="text-lg font-semibold font-display text-foreground">Director Signatures</h3>
            <p className="text-sm text-muted-foreground">Signed by any 2 Directors or Director & Company Secretary</p>
          </div>
        </div>

        <div className="space-y-4">
          {data.boardResolution.directorSignatures.map((sig, index) => (
            <motion.div
              key={sig.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-4 rounded-xl border border-border space-y-4"
            >
              <div className="flex items-center justify-between">
                <h5 className="font-medium text-foreground">Director {index + 1}</h5>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => removeDirectorSignature(sig.id)}
                  className="text-destructive hover:text-destructive"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <Label className="form-label">Name *</Label>
                  <Input
                    value={sig.name}
                    onChange={(e) => updateDirectorSignature(sig.id, 'name', e.target.value)}
                    placeholder="Full name"
                    className="h-12"
                  />
                </div>
                <div>
                  <Label className="form-label">Date *</Label>
                  <Input
                    type="date"
                    value={sig.date}
                    onChange={(e) => updateDirectorSignature(sig.id, 'date', e.target.value)}
                    className="h-12"
                  />
                </div>
              </div>

              {/* Signature Canvas */}
              <SignatureCanvas
                value={sig.signature}
                onChange={(signature) => updateDirectorSignature(sig.id, 'signature', signature)}
                label="Signature *"
              />
            </motion.div>
          ))}

          <Button
            type="button"
            variant="outline"
            onClick={addDirectorSignature}
            className="w-full h-12 border-dashed"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Director Signature
          </Button>
        </div>

        <div className="mt-6 space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <Label htmlFor="companySecretaryName" className="form-label">
                Company Secretary Name
              </Label>
              <Input
                id="companySecretaryName"
                value={data.boardResolution.companySecretaryName}
                onChange={(e) => updateResolution('companySecretaryName', e.target.value)}
                placeholder="Optional"
                className="h-12"
              />
            </div>
            <div>
              <Label htmlFor="certificationDate" className="form-label">
                Certification Date
              </Label>
              <Input
                id="certificationDate"
                type="date"
                value={data.boardResolution.certificationDate}
                onChange={(e) => updateResolution('certificationDate', e.target.value)}
                className="h-12"
              />
            </div>
          </div>

          {/* Company Secretary Signature */}
          <SignatureCanvas
            value={data.boardResolution.companySecretarySignature}
            onChange={(signature) => updateResolution('companySecretarySignature', signature)}
            label="Company Secretary Signature (if applicable)"
          />
        </div>
      </motion.div>
    </motion.div>
  );
}
