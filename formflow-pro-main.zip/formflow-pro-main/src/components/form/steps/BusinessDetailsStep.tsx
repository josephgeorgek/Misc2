import { motion } from 'framer-motion';
import { Building2, Phone, FileText, Globe, User } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { FormData } from '@/types/form';

interface BusinessDetailsStepProps {
  data: FormData;
  onChange: (data: Partial<FormData>) => void;
}

const businessTypes = [
  { value: 'sole-proprietorship', label: 'Sole Proprietorship' },
  { value: 'partnership', label: 'Partnership' },
  { value: 'private-limited', label: 'Private Limited' },
  { value: 'public-company', label: 'Public Company' },
  { value: 'association', label: 'Association/Club/Society' },
  { value: 'others', label: 'Others' },
];

const countries = [
  'Singapore',
  'Malaysia',
  'Indonesia',
  'Thailand',
  'Philippines',
  'Vietnam',
  'Hong Kong',
  'China',
  'Others',
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
};

export function BusinessDetailsStep({ data, onChange }: BusinessDetailsStepProps) {
  const updateBusinessDetails = (field: string, value: string | boolean | null) => {
    onChange({
      businessDetails: { ...data.businessDetails, [field]: value },
    });
  };

  const updateContact = (type: 'primaryContact' | 'secondaryContact', field: string, value: string) => {
    onChange({
      [type]: { ...data[type], [field]: value },
    });
  };

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-8"
    >
      {/* Business Information */}
      <motion.div variants={itemVariants} className="form-section">
        <div className="flex items-center gap-3 mb-6">
          <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-accent">
            <Building2 className="w-5 h-5 text-accent-foreground" />
          </div>
          <div>
            <h3 className="text-lg font-semibold font-display text-foreground">Business Information</h3>
            <p className="text-sm text-muted-foreground">Enter your company's registered details</p>
          </div>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <div className="md:col-span-2">
            <Label htmlFor="registeredName" className="form-label">
              ACRA Registered Name of Business *
            </Label>
            <Input
              id="registeredName"
              value={data.businessDetails.registeredName}
              onChange={(e) => updateBusinessDetails('registeredName', e.target.value)}
              placeholder="Enter your registered business name"
              className="h-12"
            />
          </div>

          <div>
            <Label htmlFor="registrationNumber" className="form-label">
              Business Registration Number (UEN) *
            </Label>
            <Input
              id="registrationNumber"
              value={data.businessDetails.registrationNumber}
              onChange={(e) => updateBusinessDetails('registrationNumber', e.target.value)}
              placeholder="e.g. 202012345A"
              className="h-12"
            />
          </div>

          <div>
            <Label htmlFor="businessType" className="form-label">
              Business Type *
            </Label>
            <Select
              value={data.businessDetails.businessType}
              onValueChange={(value) => updateBusinessDetails('businessType', value)}
            >
              <SelectTrigger className="h-12">
                <SelectValue placeholder="Select business type" />
              </SelectTrigger>
              <SelectContent>
                {businessTypes.map((type) => (
                  <SelectItem key={type.value} value={type.value}>
                    {type.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="md:col-span-2">
            <Label htmlFor="natureOfBusiness" className="form-label">
              Nature of Business *
            </Label>
            <Textarea
              id="natureOfBusiness"
              value={data.businessDetails.natureOfBusiness}
              onChange={(e) => updateBusinessDetails('natureOfBusiness', e.target.value)}
              placeholder="Describe your business activities"
              className="min-h-[100px] resize-none"
            />
          </div>

          <div>
            <Label htmlFor="countryOfDomicile" className="form-label">
              Country of Domicile *
            </Label>
            <Select
              value={data.businessDetails.countryOfDomicile}
              onValueChange={(value) => updateBusinessDetails('countryOfDomicile', value)}
            >
              <SelectTrigger className="h-12">
                <SelectValue placeholder="Select country" />
              </SelectTrigger>
              <SelectContent>
                {countries.map((country) => (
                  <SelectItem key={country} value={country}>
                    {country}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="form-label">GST Registered? *</Label>
            <RadioGroup
              value={data.businessDetails.gstRegistered === null ? '' : data.businessDetails.gstRegistered ? 'yes' : 'no'}
              onValueChange={(value) => updateBusinessDetails('gstRegistered', value === 'yes')}
              className="flex gap-6 h-12 items-center"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="yes" id="gst-yes" />
                <Label htmlFor="gst-yes" className="font-normal cursor-pointer">Yes</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="no" id="gst-no" />
                <Label htmlFor="gst-no" className="font-normal cursor-pointer">No</Label>
              </div>
            </RadioGroup>
          </div>
        </div>
      </motion.div>

      {/* Contact Numbers */}
      <motion.div variants={itemVariants} className="form-section">
        <div className="flex items-center gap-3 mb-6">
          <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-accent">
            <Phone className="w-5 h-5 text-accent-foreground" />
          </div>
          <div>
            <h3 className="text-lg font-semibold font-display text-foreground">Contact Numbers</h3>
            <p className="text-sm text-muted-foreground">Business phone and fax numbers</p>
          </div>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <div>
            <Label htmlFor="officeNumber" className="form-label">
              Office Number
            </Label>
            <Input
              id="officeNumber"
              value={data.businessDetails.officeNumber}
              onChange={(e) => updateBusinessDetails('officeNumber', e.target.value)}
              placeholder="+65 6XXX XXXX"
              className="h-12"
            />
          </div>

          <div>
            <Label htmlFor="faxNumber" className="form-label">
              Fax Number
            </Label>
            <Input
              id="faxNumber"
              value={data.businessDetails.faxNumber}
              onChange={(e) => updateBusinessDetails('faxNumber', e.target.value)}
              placeholder="+65 6XXX XXXX"
              className="h-12"
            />
          </div>
        </div>
      </motion.div>

      {/* Primary Contact Person */}
      <motion.div variants={itemVariants} className="form-section">
        <div className="flex items-center gap-3 mb-6">
          <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-accent">
            <User className="w-5 h-5 text-accent-foreground" />
          </div>
          <div>
            <h3 className="text-lg font-semibold font-display text-foreground">Primary Contact Person</h3>
            <p className="text-sm text-muted-foreground">Authorized to receive communications from the bank</p>
          </div>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <div>
            <Label htmlFor="primaryFullName" className="form-label">
              Full Name *
            </Label>
            <Input
              id="primaryFullName"
              value={data.primaryContact.fullName}
              onChange={(e) => updateContact('primaryContact', 'fullName', e.target.value)}
              placeholder="As per NRIC/Passport"
              className="h-12"
            />
          </div>

          <div>
            <Label htmlFor="primaryNric" className="form-label">
              NRIC/Passport Number *
            </Label>
            <Input
              id="primaryNric"
              value={data.primaryContact.nricPassport}
              onChange={(e) => updateContact('primaryContact', 'nricPassport', e.target.value)}
              placeholder="S1234567A"
              className="h-12"
            />
          </div>

          <div>
            <Label htmlFor="primaryEmail" className="form-label">
              Email Address *
            </Label>
            <Input
              id="primaryEmail"
              type="email"
              value={data.primaryContact.email}
              onChange={(e) => updateContact('primaryContact', 'email', e.target.value)}
              placeholder="email@company.com"
              className="h-12"
            />
          </div>

          <div>
            <Label htmlFor="primaryMobile" className="form-label">
              Mobile Number *
            </Label>
            <Input
              id="primaryMobile"
              value={data.primaryContact.mobileNumber}
              onChange={(e) => updateContact('primaryContact', 'mobileNumber', e.target.value)}
              placeholder="+65 9XXX XXXX"
              className="h-12"
            />
          </div>
        </div>
      </motion.div>

      {/* Secondary Contact Person (Optional) */}
      <motion.div variants={itemVariants} className="form-section">
        <div className="flex items-center gap-3 mb-6">
          <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-secondary">
            <User className="w-5 h-5 text-secondary-foreground" />
          </div>
          <div>
            <h3 className="text-lg font-semibold font-display text-foreground">Secondary Contact Person</h3>
            <p className="text-sm text-muted-foreground">Optional - Alternative contact for the account</p>
          </div>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <div>
            <Label htmlFor="secondaryFullName" className="form-label">
              Full Name
            </Label>
            <Input
              id="secondaryFullName"
              value={data.secondaryContact.fullName}
              onChange={(e) => updateContact('secondaryContact', 'fullName', e.target.value)}
              placeholder="As per NRIC/Passport"
              className="h-12"
            />
          </div>

          <div>
            <Label htmlFor="secondaryNric" className="form-label">
              NRIC/Passport Number
            </Label>
            <Input
              id="secondaryNric"
              value={data.secondaryContact.nricPassport}
              onChange={(e) => updateContact('secondaryContact', 'nricPassport', e.target.value)}
              placeholder="S1234567A"
              className="h-12"
            />
          </div>

          <div>
            <Label htmlFor="secondaryEmail" className="form-label">
              Email Address
            </Label>
            <Input
              id="secondaryEmail"
              type="email"
              value={data.secondaryContact.email}
              onChange={(e) => updateContact('secondaryContact', 'email', e.target.value)}
              placeholder="email@company.com"
              className="h-12"
            />
          </div>

          <div>
            <Label htmlFor="secondaryMobile" className="form-label">
              Mobile Number
            </Label>
            <Input
              id="secondaryMobile"
              value={data.secondaryContact.mobileNumber}
              onChange={(e) => updateContact('secondaryContact', 'mobileNumber', e.target.value)}
              placeholder="+65 9XXX XXXX"
              className="h-12"
            />
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}
