import { motion } from 'framer-motion';
import { Globe, Plus, Trash2, Shield, CreditCard, Settings2, Users, CheckSquare } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Textarea } from '@/components/ui/textarea';
import { FormData, VelocityUser, LinkedAccount, ApprovalMatrixRule, CustomRole, TransactionTypePermissions, RoleCapabilities } from '@/types/form';

interface BusinessServicesStepProps {
  data: FormData;
  onChange: (data: Partial<FormData>) => void;
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
};

const currencies = ['SGD', 'USD', 'EUR', 'GBP', 'AUD', 'JPY', 'CNY', 'HKD'];

const transactionTypeLabels: Record<keyof TransactionTypePermissions, string> = {
  localTransfers: 'Local Transfers',
  payNow: 'PayNow',
  giro: 'GIRO',
  telegraphicTransfers: 'Telegraphic Transfers',
  billPayments: 'Bill Payments',
  bulkPayments: 'Bulk Payments',
  payrollPayments: 'Payroll Payments',
  tradeServices: 'Trade Services',
  fxConversions: 'FX Conversions',
};

const defaultTransactionTypes: TransactionTypePermissions = {
  localTransfers: false,
  payNow: false,
  giro: false,
  telegraphicTransfers: false,
  billPayments: false,
  bulkPayments: false,
  payrollPayments: false,
  tradeServices: false,
  fxConversions: false,
};

const defaultCapabilities: RoleCapabilities = {
  viewStatements: true,
  viewTransactionHistory: true,
  createLocalTransfers: false,
  createInternationalTransfers: false,
  createPayNow: false,
  createGiro: false,
  createBillPayments: false,
  createBulkPayments: false,
  createPayroll: false,
  approveTransactions: false,
  approveWithLimit: false,
  approvalLimit: '',
  manageUsers: false,
  manageAccounts: false,
  bookFX: false,
  downloadReports: true,
};

export function BusinessServicesStep({ data, onChange }: BusinessServicesStepProps) {
  const updateServices = (field: string, value: any) => {
    onChange({
      businessBankingServices: { ...data.businessBankingServices, [field]: value },
    });
  };

  // Linked accounts management
  const addLinkedAccount = () => {
    const newAccount: LinkedAccount = {
      id: crypto.randomUUID(),
      accountNumber: '',
      currency: 'SGD',
    };
    updateServices('linkedAccounts', [...data.businessBankingServices.linkedAccounts, newAccount]);
  };

  const updateLinkedAccount = (id: string, field: string, value: string) => {
    const updated = data.businessBankingServices.linkedAccounts.map((acc) =>
      acc.id === id ? { ...acc, [field]: value } : acc
    );
    updateServices('linkedAccounts', updated);
  };

  const removeLinkedAccount = (id: string) => {
    updateServices(
      'linkedAccounts',
      data.businessBankingServices.linkedAccounts.filter((a) => a.id !== id)
    );
  };

  // Velocity users management
  const addVelocityUser = () => {
    const newUser: VelocityUser = {
      id: crypto.randomUUID(),
      fullName: '',
      nricPassport: '',
      idType: 'nric',
      idIssueCountry: 'Singapore',
      userId: '',
      mobileNumber: '',
      email: '',
      canViewStatement: true,
      canCreateTransactions: false,
      canApproveTransactions: false,
      canBookFX: false,
      role: 'viewer',
      customRoleName: '',
      transactionTypes: { ...defaultTransactionTypes },
    };
    updateServices('velocityUsers', [...data.businessBankingServices.velocityUsers, newUser]);
  };

  const updateVelocityUser = (id: string, field: string, value: any) => {
    const updated = data.businessBankingServices.velocityUsers.map((user) =>
      user.id === id ? { ...user, [field]: value } : user
    );
    updateServices('velocityUsers', updated);
  };

  const updateUserTransactionType = (userId: string, txType: keyof TransactionTypePermissions, value: boolean) => {
    const updated = data.businessBankingServices.velocityUsers.map((user) =>
      user.id === userId
        ? { ...user, transactionTypes: { ...user.transactionTypes, [txType]: value } }
        : user
    );
    updateServices('velocityUsers', updated);
  };

  const removeVelocityUser = (id: string) => {
    updateServices(
      'velocityUsers',
      data.businessBankingServices.velocityUsers.filter((u) => u.id !== id)
    );
  };

  // Approval Matrix management
  const updateApprovalMatrix = (field: string, value: any) => {
    updateServices('approvalMatrix', { ...data.businessBankingServices.approvalMatrix, [field]: value });
  };

  const addApprovalRule = () => {
    const newRule: ApprovalMatrixRule = {
      id: crypto.randomUUID(),
      transactionType: 'All Transactions',
      amountFrom: '',
      amountTo: '',
      requiredApprovers: 1,
      approverGrouping: '',
    };
    updateApprovalMatrix('matrixRules', [...data.businessBankingServices.approvalMatrix.matrixRules, newRule]);
  };

  const updateApprovalRule = (id: string, field: string, value: any) => {
    const updated = data.businessBankingServices.approvalMatrix.matrixRules.map((rule) =>
      rule.id === id ? { ...rule, [field]: value } : rule
    );
    updateApprovalMatrix('matrixRules', updated);
  };

  const removeApprovalRule = (id: string) => {
    updateApprovalMatrix(
      'matrixRules',
      data.businessBankingServices.approvalMatrix.matrixRules.filter((r) => r.id !== id)
    );
  };

  // Custom roles management
  const addCustomRole = () => {
    const newRole: CustomRole = {
      id: crypto.randomUUID(),
      roleName: '',
      description: '',
      capabilities: { ...defaultCapabilities },
    };
    updateServices('customRoles', [...data.businessBankingServices.customRoles, newRole]);
  };

  const updateCustomRole = (id: string, field: string, value: any) => {
    const updated = data.businessBankingServices.customRoles.map((role) =>
      role.id === id ? { ...role, [field]: value } : role
    );
    updateServices('customRoles', updated);
  };

  const updateRoleCapability = (roleId: string, capability: keyof RoleCapabilities, value: any) => {
    const updated = data.businessBankingServices.customRoles.map((role) =>
      role.id === roleId
        ? { ...role, capabilities: { ...role.capabilities, [capability]: value } }
        : role
    );
    updateServices('customRoles', updated);
  };

  const removeCustomRole = (id: string) => {
    updateServices(
      'customRoles',
      data.businessBankingServices.customRoles.filter((r) => r.id !== id)
    );
  };

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-8"
    >
      {/* OCBC Velocity */}
      <motion.div variants={itemVariants} className="form-section">
        <div className="flex items-center gap-3 mb-6">
          <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-accent">
            <Globe className="w-5 h-5 text-accent-foreground" />
          </div>
          <div>
            <h3 className="text-lg font-semibold font-display text-foreground">Business Internet Banking (OCBC Velocity)</h3>
            <p className="text-sm text-muted-foreground">Manage your accounts online</p>
          </div>
        </div>

        <div className="flex items-center justify-between p-4 rounded-xl border border-border mb-6">
          <div>
            <p className="font-medium text-foreground">Apply for OCBC Velocity</p>
            <p className="text-sm text-muted-foreground">Process within 7 business days</p>
          </div>
          <Switch
            checked={data.businessBankingServices.applyForVelocity}
            onCheckedChange={(checked) => updateServices('applyForVelocity', checked)}
          />
        </div>

        {data.businessBankingServices.applyForVelocity && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            className="space-y-6"
          >
            {/* Business Details */}
            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <Label className="form-label">Registered Name</Label>
                <Input
                  value={data.businessBankingServices.registeredName || data.businessDetails.registeredName}
                  onChange={(e) => updateServices('registeredName', e.target.value)}
                  className="h-12"
                />
              </div>
              <div>
                <Label className="form-label">Debit Fees from Account</Label>
                <Input
                  value={data.businessBankingServices.debitAccountForToken}
                  onChange={(e) => updateServices('debitAccountForToken', e.target.value)}
                  placeholder="Account number for token fees"
                  className="h-12"
                />
              </div>
            </div>

            {/* Contact Person */}
            <div className="space-y-4">
              <h4 className="font-semibold text-foreground">Contact Person</h4>
              <p className="text-sm text-muted-foreground">
                Authorized to receive communications and Velocity starter kit
              </p>
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <Label className="form-label">Name *</Label>
                  <Input
                    value={data.businessBankingServices.contactPersonName}
                    onChange={(e) => updateServices('contactPersonName', e.target.value)}
                    placeholder="Contact person name"
                    className="h-12"
                  />
                </div>
                <div>
                  <Label className="form-label">Email *</Label>
                  <Input
                    type="email"
                    value={data.businessBankingServices.contactPersonEmail}
                    onChange={(e) => updateServices('contactPersonEmail', e.target.value)}
                    placeholder="email@company.com"
                    className="h-12"
                  />
                </div>
                <div>
                  <Label className="form-label">Office Number</Label>
                  <Input
                    value={data.businessBankingServices.contactPersonOfficeNumber}
                    onChange={(e) => updateServices('contactPersonOfficeNumber', e.target.value)}
                    placeholder="+65-XXXX-XXXX"
                    className="h-12"
                  />
                </div>
                <div>
                  <Label className="form-label">Mobile Number *</Label>
                  <Input
                    value={data.businessBankingServices.contactPersonMobile}
                    onChange={(e) => updateServices('contactPersonMobile', e.target.value)}
                    placeholder="+65-XXXX-XXXX"
                    className="h-12"
                  />
                </div>
              </div>
            </div>

            {/* Organisation ID */}
            <div>
              <Label className="form-label">Organisation ID (Choice)</Label>
              <Input
                value={data.businessBankingServices.organisationId}
                onChange={(e) => updateServices('organisationId', e.target.value)}
                placeholder="Subject to availability. Leave blank for auto-assign"
                className="h-12"
              />
              <p className="form-description">An ID will be assigned if left blank or unavailable</p>
            </div>

            {/* Linked Accounts */}
            <div className="space-y-4">
              <h4 className="font-semibold text-foreground">Business Accounts to Link</h4>
              
              {data.businessBankingServices.linkedAccounts.map((account, index) => (
                <motion.div
                  key={account.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex items-center gap-4 p-4 rounded-xl border border-border"
                >
                  <div className="flex-1 grid gap-4 md:grid-cols-2">
                    <div>
                      <Label className="form-label">Account Number</Label>
                      <Input
                        value={account.accountNumber}
                        onChange={(e) => updateLinkedAccount(account.id, 'accountNumber', e.target.value)}
                        placeholder="Enter account number"
                        className="h-12"
                      />
                    </div>
                    <div>
                      <Label className="form-label">Currency</Label>
                      <Select
                        value={account.currency}
                        onValueChange={(value) => updateLinkedAccount(account.id, 'currency', value)}
                      >
                        <SelectTrigger className="h-12">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {currencies.map((currency) => (
                            <SelectItem key={currency} value={currency}>
                              {currency}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => removeLinkedAccount(account.id)}
                    className="text-destructive hover:text-destructive"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </motion.div>
              ))}

              <Button
                type="button"
                variant="outline"
                onClick={addLinkedAccount}
                className="w-full h-12 border-dashed"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Account
              </Button>

              <div className="flex items-center justify-between p-4 rounded-xl border border-border">
                <div>
                  <p className="font-medium text-foreground">Link All Trade Accounts</p>
                  <p className="text-sm text-muted-foreground">LC, BG, Trade Loan, Invoice Financing</p>
                </div>
                <Switch
                  checked={data.businessBankingServices.linkAllTradeAccounts}
                  onCheckedChange={(checked) => updateServices('linkAllTradeAccounts', checked)}
                />
              </div>
            </div>

            {/* e-Statement */}
            <div className="flex items-center justify-between p-4 rounded-xl border border-border">
              <div>
                <p className="font-medium text-foreground">e-Statement</p>
                <p className="text-sm text-muted-foreground">View and download via OCBC Velocity (no hard copy)</p>
              </div>
              <Switch
                checked={data.businessBankingServices.eStatementEnabled}
                onCheckedChange={(checked) => updateServices('eStatementEnabled', checked)}
              />
            </div>

            {/* Service Package */}
            <div className="space-y-4">
              <h4 className="font-semibold text-foreground">Service Package</h4>
              <RadioGroup
                value={data.businessBankingServices.servicePackage}
                onValueChange={(value) => updateServices('servicePackage', value)}
                className="space-y-3"
              >
                <div className="flex items-start space-x-3 p-4 rounded-xl border border-border">
                  <RadioGroupItem value="basic" id="pkg-basic" className="mt-1" />
                  <Label htmlFor="pkg-basic" className="flex-1 cursor-pointer">
                    <span className="font-medium">Basic</span>
                    <p className="text-sm text-muted-foreground">
                      View account statements only
                    </p>
                  </Label>
                </div>
                <div className="flex items-start space-x-3 p-4 rounded-xl border border-border">
                  <RadioGroupItem value="standard" id="pkg-standard" className="mt-1" />
                  <Label htmlFor="pkg-standard" className="flex-1 cursor-pointer">
                    <span className="font-medium">Standard</span>
                    <p className="text-sm text-muted-foreground">
                      Same user creates and approves transactions (single control)
                    </p>
                  </Label>
                </div>
                <div className="flex items-start space-x-3 p-4 rounded-xl border border-border">
                  <RadioGroupItem value="classic" id="pkg-classic" className="mt-1" />
                  <Label htmlFor="pkg-classic" className="flex-1 cursor-pointer">
                    <span className="font-medium">Classic</span>
                    <p className="text-sm text-muted-foreground">
                      Separate maker and authoriser roles (dual control)
                    </p>
                  </Label>
                </div>
              </RadioGroup>

              {data.businessBankingServices.servicePackage === 'classic' && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  className="space-y-3"
                >
                  <p className="text-sm text-muted-foreground">How many authorisers required?</p>
                  <RadioGroup
                    value={data.businessBankingServices.classicSigningMode}
                    onValueChange={(value) => updateServices('classicSigningMode', value)}
                    className="flex gap-4"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="single" id="auth-single" />
                      <Label htmlFor="auth-single">1 Authoriser</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="dual" id="auth-dual" />
                      <Label htmlFor="auth-dual">2 Authorisers jointly</Label>
                    </div>
                  </RadioGroup>
                </motion.div>
              )}
            </div>

            {/* Authorised Users */}
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <Users className="w-5 h-5 text-muted-foreground" />
                <h4 className="font-semibold text-foreground">Authorised Users</h4>
              </div>
              
              {data.businessBankingServices.velocityUsers.map((user, index) => (
                <motion.div
                  key={user.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-4 rounded-xl border border-border space-y-4"
                >
                  <div className="flex items-center justify-between">
                    <h5 className="font-medium text-foreground">User {index + 1}</h5>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => removeVelocityUser(user.id)}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>

                  <div className="grid gap-4 md:grid-cols-2">
                    <div>
                      <Label className="form-label">Full Name *</Label>
                      <Input
                        value={user.fullName}
                        onChange={(e) => updateVelocityUser(user.id, 'fullName', e.target.value)}
                        placeholder="As per NRIC/Passport"
                        className="h-12"
                      />
                    </div>
                    <div>
                      <Label className="form-label">User ID</Label>
                      <Input
                        value={user.userId}
                        onChange={(e) => updateVelocityUser(user.id, 'userId', e.target.value)}
                        placeholder="Preferred user ID"
                        className="h-12"
                      />
                    </div>
                    <div>
                      <Label className="form-label">ID Type</Label>
                      <Select
                        value={user.idType}
                        onValueChange={(value) => updateVelocityUser(user.id, 'idType', value)}
                      >
                        <SelectTrigger className="h-12">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="nric">NRIC</SelectItem>
                          <SelectItem value="passport">Passport</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label className="form-label">NRIC/Passport Number *</Label>
                      <Input
                        value={user.nricPassport}
                        onChange={(e) => updateVelocityUser(user.id, 'nricPassport', e.target.value)}
                        placeholder="e.g., S1234567A"
                        className="h-12"
                      />
                    </div>
                    <div>
                      <Label className="form-label">Mobile Number *</Label>
                      <Input
                        value={user.mobileNumber}
                        onChange={(e) => updateVelocityUser(user.id, 'mobileNumber', e.target.value)}
                        placeholder="+65-XXXX-XXXX"
                        className="h-12"
                      />
                    </div>
                    <div>
                      <Label className="form-label">Email *</Label>
                      <Input
                        type="email"
                        value={user.email}
                        onChange={(e) => updateVelocityUser(user.id, 'email', e.target.value)}
                        placeholder="email@company.com"
                        className="h-12"
                      />
                    </div>
                  </div>

                  {/* Role Selection */}
                  <div className="space-y-3">
                    <Label className="form-label">User Role</Label>
                    <Select
                      value={user.role}
                      onValueChange={(value) => updateVelocityUser(user.id, 'role', value)}
                    >
                      <SelectTrigger className="h-12">
                        <SelectValue placeholder="Select role" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="viewer">Viewer - View statements only</SelectItem>
                        <SelectItem value="maker">Maker - Create transactions</SelectItem>
                        <SelectItem value="authoriser">Authoriser - Approve transactions</SelectItem>
                        <SelectItem value="makerAuthoriser">Maker & Authoriser - Create and approve</SelectItem>
                        <SelectItem value="custom">Custom Role</SelectItem>
                      </SelectContent>
                    </Select>

                    {user.role === 'custom' && (
                      <div className="mt-2">
                        <Label className="form-label">Custom Role Name</Label>
                        <Input
                          value={user.customRoleName}
                          onChange={(e) => updateVelocityUser(user.id, 'customRoleName', e.target.value)}
                          placeholder="e.g., Finance Manager"
                          className="h-12"
                        />
                      </div>
                    )}
                  </div>

                  {/* Permissions */}
                  <div className="space-y-3">
                    <p className="text-sm font-medium text-foreground">Permissions</p>
                    <div className="flex flex-wrap gap-4">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id={`view-${user.id}`}
                          checked={user.canViewStatement}
                          onCheckedChange={(checked) => updateVelocityUser(user.id, 'canViewStatement', checked)}
                        />
                        <Label htmlFor={`view-${user.id}`} className="text-sm">View Statements</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id={`create-${user.id}`}
                          checked={user.canCreateTransactions}
                          onCheckedChange={(checked) => updateVelocityUser(user.id, 'canCreateTransactions', checked)}
                        />
                        <Label htmlFor={`create-${user.id}`} className="text-sm">Create Transactions</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id={`approve-${user.id}`}
                          checked={user.canApproveTransactions}
                          onCheckedChange={(checked) => updateVelocityUser(user.id, 'canApproveTransactions', checked)}
                        />
                        <Label htmlFor={`approve-${user.id}`} className="text-sm">Approve Transactions</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id={`fx-${user.id}`}
                          checked={user.canBookFX}
                          onCheckedChange={(checked) => updateVelocityUser(user.id, 'canBookFX', checked)}
                        />
                        <Label htmlFor={`fx-${user.id}`} className="text-sm">Book FX</Label>
                      </div>
                    </div>
                  </div>

                  {/* User can make transactions for */}
                  {(user.canCreateTransactions || user.role === 'maker' || user.role === 'makerAuthoriser') && (
                    <div className="space-y-3 p-4 rounded-lg bg-muted/50">
                      <p className="text-sm font-medium text-foreground">User can make transactions for:</p>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                        {(Object.keys(transactionTypeLabels) as (keyof TransactionTypePermissions)[]).map((txType) => (
                          <div key={txType} className="flex items-center space-x-2">
                            <Checkbox
                              id={`tx-${user.id}-${txType}`}
                              checked={user.transactionTypes[txType]}
                              onCheckedChange={(checked) => updateUserTransactionType(user.id, txType, checked as boolean)}
                            />
                            <Label htmlFor={`tx-${user.id}-${txType}`} className="text-sm">
                              {transactionTypeLabels[txType]}
                            </Label>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </motion.div>
              ))}

              <Button
                type="button"
                variant="outline"
                onClick={addVelocityUser}
                className="w-full h-12 border-dashed"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add User
              </Button>
            </div>

            {/* How do you want your transactions to be approved? */}
            {data.businessBankingServices.servicePackage === 'classic' && (
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <CheckSquare className="w-5 h-5 text-muted-foreground" />
                  <div>
                    <h4 className="font-semibold text-foreground">How do you want your transactions to be approved?</h4>
                    <p className="text-sm text-muted-foreground">Configure your approval workflow</p>
                  </div>
                </div>

                <RadioGroup
                  value={data.businessBankingServices.approvalMatrix.approvalType}
                  onValueChange={(value) => updateApprovalMatrix('approvalType', value)}
                  className="space-y-3"
                >
                  <div className="flex items-start space-x-3 p-4 rounded-xl border border-border">
                    <RadioGroupItem value="single" id="approval-single" className="mt-1" />
                    <Label htmlFor="approval-single" className="flex-1 cursor-pointer">
                      <span className="font-medium">Single Approval</span>
                      <p className="text-sm text-muted-foreground">
                        Any one authoriser can approve all transactions
                      </p>
                    </Label>
                  </div>
                  <div className="flex items-start space-x-3 p-4 rounded-xl border border-border">
                    <RadioGroupItem value="dual" id="approval-dual" className="mt-1" />
                    <Label htmlFor="approval-dual" className="flex-1 cursor-pointer">
                      <span className="font-medium">Dual Approval</span>
                      <p className="text-sm text-muted-foreground">
                        Two authorisers required for transactions above threshold
                      </p>
                    </Label>
                  </div>
                  <div className="flex items-start space-x-3 p-4 rounded-xl border border-border">
                    <RadioGroupItem value="matrix" id="approval-matrix" className="mt-1" />
                    <Label htmlFor="approval-matrix" className="flex-1 cursor-pointer">
                      <span className="font-medium">Approval Matrix</span>
                      <p className="text-sm text-muted-foreground">
                        Custom rules based on transaction type and amount
                      </p>
                    </Label>
                  </div>
                </RadioGroup>

                {data.businessBankingServices.approvalMatrix.approvalType === 'dual' && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    className="grid gap-4 md:grid-cols-2 p-4 rounded-xl border border-border"
                  >
                    <div>
                      <Label className="form-label">Single approver up to (S$)</Label>
                      <Input
                        value={data.businessBankingServices.approvalMatrix.singleApproverThreshold}
                        onChange={(e) => updateApprovalMatrix('singleApproverThreshold', e.target.value)}
                        placeholder="e.g., 5000"
                        className="h-12"
                      />
                    </div>
                    <div>
                      <Label className="form-label">Dual approvers up to (S$)</Label>
                      <Input
                        value={data.businessBankingServices.approvalMatrix.dualApproverThreshold}
                        onChange={(e) => updateApprovalMatrix('dualApproverThreshold', e.target.value)}
                        placeholder="e.g., 50000"
                        className="h-12"
                      />
                    </div>
                  </motion.div>
                )}

                {data.businessBankingServices.approvalMatrix.approvalType === 'matrix' && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    className="space-y-4"
                  >
                    {data.businessBankingServices.approvalMatrix.matrixRules.map((rule, index) => (
                      <div key={rule.id} className="p-4 rounded-xl border border-border space-y-4">
                        <div className="flex items-center justify-between">
                          <h5 className="font-medium text-foreground">Rule {index + 1}</h5>
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={() => removeApprovalRule(rule.id)}
                            className="text-destructive hover:text-destructive"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                          <div>
                            <Label className="form-label">Transaction Type</Label>
                            <Select
                              value={rule.transactionType}
                              onValueChange={(value) => updateApprovalRule(rule.id, 'transactionType', value)}
                            >
                              <SelectTrigger className="h-12">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="All Transactions">All Transactions</SelectItem>
                                <SelectItem value="Local Transfers">Local Transfers</SelectItem>
                                <SelectItem value="International Transfers">International Transfers</SelectItem>
                                <SelectItem value="PayNow">PayNow</SelectItem>
                                <SelectItem value="GIRO">GIRO</SelectItem>
                                <SelectItem value="Bill Payments">Bill Payments</SelectItem>
                                <SelectItem value="Bulk Payments">Bulk Payments</SelectItem>
                                <SelectItem value="Payroll">Payroll</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div>
                            <Label className="form-label">Amount From (S$)</Label>
                            <Input
                              value={rule.amountFrom}
                              onChange={(e) => updateApprovalRule(rule.id, 'amountFrom', e.target.value)}
                              placeholder="0"
                              className="h-12"
                            />
                          </div>
                          <div>
                            <Label className="form-label">Amount To (S$)</Label>
                            <Input
                              value={rule.amountTo}
                              onChange={(e) => updateApprovalRule(rule.id, 'amountTo', e.target.value)}
                              placeholder="10000"
                              className="h-12"
                            />
                          </div>
                          <div>
                            <Label className="form-label">Required Approvers</Label>
                            <Select
                              value={String(rule.requiredApprovers)}
                              onValueChange={(value) => updateApprovalRule(rule.id, 'requiredApprovers', parseInt(value))}
                            >
                              <SelectTrigger className="h-12">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="1">1 Approver</SelectItem>
                                <SelectItem value="2">2 Approvers</SelectItem>
                                <SelectItem value="3">3 Approvers</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="md:col-span-2">
                            <Label className="form-label">Approver Grouping</Label>
                            <Input
                              value={rule.approverGrouping}
                              onChange={(e) => updateApprovalRule(rule.id, 'approverGrouping', e.target.value)}
                              placeholder="e.g., Any Authoriser, CFO + Any, etc."
                              className="h-12"
                            />
                          </div>
                        </div>
                      </div>
                    ))}

                    <Button
                      type="button"
                      variant="outline"
                      onClick={addApprovalRule}
                      className="w-full h-12 border-dashed"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Add Approval Rule
                    </Button>
                  </motion.div>
                )}
              </div>
            )}

            {/* Custom Roles */}
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <Settings2 className="w-5 h-5 text-muted-foreground" />
                <div>
                  <h4 className="font-semibold text-foreground">Custom Roles & Capabilities</h4>
                  <p className="text-sm text-muted-foreground">Define custom roles with specific permissions</p>
                </div>
              </div>

              {data.businessBankingServices.customRoles.map((role, index) => (
                <motion.div
                  key={role.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-4 rounded-xl border border-border space-y-4"
                >
                  <div className="flex items-center justify-between">
                    <h5 className="font-medium text-foreground">Custom Role {index + 1}</h5>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => removeCustomRole(role.id)}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>

                  <div className="grid gap-4 md:grid-cols-2">
                    <div>
                      <Label className="form-label">Role Name *</Label>
                      <Input
                        value={role.roleName}
                        onChange={(e) => updateCustomRole(role.id, 'roleName', e.target.value)}
                        placeholder="e.g., Finance Manager"
                        className="h-12"
                      />
                    </div>
                    <div>
                      <Label className="form-label">Description</Label>
                      <Input
                        value={role.description}
                        onChange={(e) => updateCustomRole(role.id, 'description', e.target.value)}
                        placeholder="Brief description of the role"
                        className="h-12"
                      />
                    </div>
                  </div>

                  {/* Capabilities */}
                  <div className="space-y-3">
                    <p className="text-sm font-medium text-foreground">Role Capabilities</p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {/* View Capabilities */}
                      <div className="space-y-2">
                        <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">View</p>
                        <div className="space-y-2">
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id={`cap-view-stmt-${role.id}`}
                              checked={role.capabilities.viewStatements}
                              onCheckedChange={(checked) => updateRoleCapability(role.id, 'viewStatements', checked)}
                            />
                            <Label htmlFor={`cap-view-stmt-${role.id}`} className="text-sm">View Statements</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id={`cap-view-tx-${role.id}`}
                              checked={role.capabilities.viewTransactionHistory}
                              onCheckedChange={(checked) => updateRoleCapability(role.id, 'viewTransactionHistory', checked)}
                            />
                            <Label htmlFor={`cap-view-tx-${role.id}`} className="text-sm">View Transaction History</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id={`cap-reports-${role.id}`}
                              checked={role.capabilities.downloadReports}
                              onCheckedChange={(checked) => updateRoleCapability(role.id, 'downloadReports', checked)}
                            />
                            <Label htmlFor={`cap-reports-${role.id}`} className="text-sm">Download Reports</Label>
                          </div>
                        </div>
                      </div>

                      {/* Create Capabilities */}
                      <div className="space-y-2">
                        <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Create Transactions</p>
                        <div className="space-y-2">
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id={`cap-local-${role.id}`}
                              checked={role.capabilities.createLocalTransfers}
                              onCheckedChange={(checked) => updateRoleCapability(role.id, 'createLocalTransfers', checked)}
                            />
                            <Label htmlFor={`cap-local-${role.id}`} className="text-sm">Local Transfers</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id={`cap-intl-${role.id}`}
                              checked={role.capabilities.createInternationalTransfers}
                              onCheckedChange={(checked) => updateRoleCapability(role.id, 'createInternationalTransfers', checked)}
                            />
                            <Label htmlFor={`cap-intl-${role.id}`} className="text-sm">International Transfers</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id={`cap-paynow-${role.id}`}
                              checked={role.capabilities.createPayNow}
                              onCheckedChange={(checked) => updateRoleCapability(role.id, 'createPayNow', checked)}
                            />
                            <Label htmlFor={`cap-paynow-${role.id}`} className="text-sm">PayNow</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id={`cap-giro-${role.id}`}
                              checked={role.capabilities.createGiro}
                              onCheckedChange={(checked) => updateRoleCapability(role.id, 'createGiro', checked)}
                            />
                            <Label htmlFor={`cap-giro-${role.id}`} className="text-sm">GIRO</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id={`cap-bill-${role.id}`}
                              checked={role.capabilities.createBillPayments}
                              onCheckedChange={(checked) => updateRoleCapability(role.id, 'createBillPayments', checked)}
                            />
                            <Label htmlFor={`cap-bill-${role.id}`} className="text-sm">Bill Payments</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id={`cap-bulk-${role.id}`}
                              checked={role.capabilities.createBulkPayments}
                              onCheckedChange={(checked) => updateRoleCapability(role.id, 'createBulkPayments', checked)}
                            />
                            <Label htmlFor={`cap-bulk-${role.id}`} className="text-sm">Bulk Payments</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id={`cap-payroll-${role.id}`}
                              checked={role.capabilities.createPayroll}
                              onCheckedChange={(checked) => updateRoleCapability(role.id, 'createPayroll', checked)}
                            />
                            <Label htmlFor={`cap-payroll-${role.id}`} className="text-sm">Payroll</Label>
                          </div>
                        </div>
                      </div>

                      {/* Approve Capabilities */}
                      <div className="space-y-2">
                        <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Approve</p>
                        <div className="space-y-2">
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id={`cap-approve-${role.id}`}
                              checked={role.capabilities.approveTransactions}
                              onCheckedChange={(checked) => updateRoleCapability(role.id, 'approveTransactions', checked)}
                            />
                            <Label htmlFor={`cap-approve-${role.id}`} className="text-sm">Approve Transactions</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id={`cap-approve-limit-${role.id}`}
                              checked={role.capabilities.approveWithLimit}
                              onCheckedChange={(checked) => updateRoleCapability(role.id, 'approveWithLimit', checked)}
                            />
                            <Label htmlFor={`cap-approve-limit-${role.id}`} className="text-sm">Approve with Limit</Label>
                          </div>
                          {role.capabilities.approveWithLimit && (
                            <div className="ml-6">
                              <Label className="form-label text-xs">Approval Limit (S$)</Label>
                              <Input
                                value={role.capabilities.approvalLimit}
                                onChange={(e) => updateRoleCapability(role.id, 'approvalLimit', e.target.value)}
                                placeholder="e.g., 50000"
                                className="h-10"
                              />
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Admin Capabilities */}
                      <div className="space-y-2">
                        <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Admin & FX</p>
                        <div className="space-y-2">
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id={`cap-users-${role.id}`}
                              checked={role.capabilities.manageUsers}
                              onCheckedChange={(checked) => updateRoleCapability(role.id, 'manageUsers', checked)}
                            />
                            <Label htmlFor={`cap-users-${role.id}`} className="text-sm">Manage Users</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id={`cap-accounts-${role.id}`}
                              checked={role.capabilities.manageAccounts}
                              onCheckedChange={(checked) => updateRoleCapability(role.id, 'manageAccounts', checked)}
                            />
                            <Label htmlFor={`cap-accounts-${role.id}`} className="text-sm">Manage Accounts</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id={`cap-fx-${role.id}`}
                              checked={role.capabilities.bookFX}
                              onCheckedChange={(checked) => updateRoleCapability(role.id, 'bookFX', checked)}
                            />
                            <Label htmlFor={`cap-fx-${role.id}`} className="text-sm">Book FX</Label>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}

              <Button
                type="button"
                variant="outline"
                onClick={addCustomRole}
                className="w-full h-12 border-dashed"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Custom Role
              </Button>
            </div>

            {/* 2FA Selection */}
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <Shield className="w-5 h-5 text-muted-foreground" />
                <h4 className="font-semibold text-foreground">2-Factor Authentication (2FA)</h4>
              </div>
              <p className="text-sm text-muted-foreground">
                Selection applies to every user. Default is digital token.
              </p>
              <RadioGroup
                value={data.businessBankingServices.twoFactorMethod}
                onValueChange={(value) => updateServices('twoFactorMethod', value)}
                className="grid grid-cols-2 gap-4"
              >
                <div className="flex items-start space-x-3 p-4 rounded-xl border border-border">
                  <RadioGroupItem value="digital" id="2fa-digital" className="mt-1" />
                  <Label htmlFor="2fa-digital" className="flex-1 cursor-pointer">
                    <span className="font-medium">Digital Token (Free)</span>
                    <p className="text-sm text-muted-foreground">
                      Activate on mobile phone
                    </p>
                  </Label>
                </div>
                <div className="flex items-start space-x-3 p-4 rounded-xl border border-border">
                  <RadioGroupItem value="hardware" id="2fa-hardware" className="mt-1" />
                  <Label htmlFor="2fa-hardware" className="flex-1 cursor-pointer">
                    <span className="font-medium">Hardware Token (S$50)</span>
                    <p className="text-sm text-muted-foreground">
                      Physical device mailed to you
                    </p>
                  </Label>
                </div>
              </RadioGroup>
            </div>
          </motion.div>
        )}
      </motion.div>
    </motion.div>
  );
}
