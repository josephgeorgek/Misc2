import { motion } from 'framer-motion';
import { CreditCard, Plus, Trash2 } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { FormData, Cardholder } from '@/types/form';
import { SignatureCanvas } from '../SignatureCanvas';

interface DebitCardStepProps {
  data: FormData;
  onChange: (data: Partial<FormData>) => void;
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
};

const occupations = [
  { value: 'salesExecutive', label: 'Sales Executive' },
  { value: 'director', label: 'Director / Owner' },
  { value: 'generalManager', label: 'General Manager' },
  { value: 'financialOfficer', label: 'Financial Officer' },
  { value: 'other', label: 'Others' },
];

const atmLimits = ['0', '1000', '3000', '5000'];
const paymentLimits = ['1000', '2000', '5000', '10000'];

export function DebitCardStep({ data, onChange }: DebitCardStepProps) {
  const updateDebitCard = (field: string, value: any) => {
    onChange({
      businessDebitCard: { ...data.businessDebitCard, [field]: value },
    });
  };

  const addCardholder = () => {
    const newCardholder: Cardholder = {
      id: crypto.randomUUID(),
      fullName: '',
      title: 'Mr',
      dateOfBirth: '',
      nricNumber: '',
      passportNumber: '',
      passportCountry: '',
      residentialAddress: '',
      postalCode: '',
      nationality: 'singaporean',
      nationalityCountry: '',
      email: '',
      occupation: 'director',
      occupationOther: '',
      mobileNumber: '',
      netsAtmLimit: '5000',
      netsPaymentLimit: '5000',
      nameOnCard: '',
      signature: '',
    };
    updateDebitCard('cardholders', [...data.businessDebitCard.cardholders, newCardholder]);
  };

  const updateCardholder = (id: string, field: string, value: any) => {
    const updated = data.businessDebitCard.cardholders.map((ch) =>
      ch.id === id ? { ...ch, [field]: value } : ch
    );
    updateDebitCard('cardholders', updated);
  };

  const removeCardholder = (id: string) => {
    updateDebitCard(
      'cardholders',
      data.businessDebitCard.cardholders.filter((c) => c.id !== id)
    );
  };

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-8"
    >
      {/* Header */}
      <motion.div variants={itemVariants} className="form-section">
        <div className="flex items-center gap-3 mb-6">
          <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-accent">
            <CreditCard className="w-5 h-5 text-accent-foreground" />
          </div>
          <div>
            <h3 className="text-lg font-semibold font-display text-foreground">Business Debit Card</h3>
            <p className="text-sm text-muted-foreground">OCBC Business MasterCard Debit</p>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-muted/50 border border-border mb-6">
          <p className="text-sm text-muted-foreground">
            This card is for sole proprietors, partnerships and companies with SGD business accounts 
            without overdraft facility. Cardholders must be aged 18 and above.
          </p>
        </div>

        <div className="flex items-center justify-between p-4 rounded-xl border border-border mb-6">
          <div>
            <p className="font-medium text-foreground">Apply for Business Debit Card</p>
            <p className="text-sm text-muted-foreground">Process within 7 business days</p>
          </div>
          <Switch
            checked={data.businessDebitCard.applyForDebitCard}
            onCheckedChange={(checked) => updateDebitCard('applyForDebitCard', checked)}
          />
        </div>

        {data.businessDebitCard.applyForDebitCard && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            className="space-y-6"
          >
            {/* Applicant Details */}
            <div className="space-y-4">
              <h4 className="font-semibold text-foreground">Applicant Details</h4>
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <Label className="form-label">Registered Name *</Label>
                  <Input
                    value={data.businessDebitCard.registeredName || data.businessDetails.registeredName}
                    onChange={(e) => updateDebitCard('registeredName', e.target.value)}
                    className="h-12"
                  />
                </div>
                <div>
                  <Label className="form-label">Business Registration Number</Label>
                  <Input
                    value={data.businessDebitCard.registrationNumber || data.businessDetails.registrationNumber}
                    onChange={(e) => updateDebitCard('registrationNumber', e.target.value)}
                    className="h-12"
                  />
                </div>
              </div>

              <div className="space-y-3">
                <Label className="form-label">SGD Business Account to be Linked</Label>
                <RadioGroup
                  value={data.businessDebitCard.isNewAccount ? 'new' : 'existing'}
                  onValueChange={(value) => updateDebitCard('isNewAccount', value === 'new')}
                  className="flex gap-4"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="new" id="account-new" />
                    <Label htmlFor="account-new">New account (from this application)</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="existing" id="account-existing" />
                    <Label htmlFor="account-existing">Existing account</Label>
                  </div>
                </RadioGroup>

                {!data.businessDebitCard.isNewAccount && (
                  <Input
                    value={data.businessDebitCard.linkedAccountNumber}
                    onChange={(e) => updateDebitCard('linkedAccountNumber', e.target.value)}
                    placeholder="Enter existing account number"
                    className="h-12"
                  />
                )}
              </div>
            </div>

            {/* Cardholders */}
            <div className="space-y-4">
              <h4 className="font-semibold text-foreground">Cardholders</h4>
              <p className="text-sm text-muted-foreground">
                Add up to 2 cardholders. NRIC/Passport copy required.
              </p>

              {data.businessDebitCard.cardholders.map((cardholder, index) => (
                <motion.div
                  key={cardholder.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-4 rounded-xl border border-border space-y-4"
                >
                  <div className="flex items-center justify-between">
                    <h5 className="font-medium text-foreground">Cardholder {index + 1}</h5>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => removeCardholder(cardholder.id)}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>

                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="md:col-span-2 grid grid-cols-4 gap-4">
                      <div>
                        <Label className="form-label">Title</Label>
                        <Select
                          value={cardholder.title}
                          onValueChange={(value) => updateCardholder(cardholder.id, 'title', value)}
                        >
                          <SelectTrigger className="h-12">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Dr">Dr</SelectItem>
                            <SelectItem value="Mr">Mr</SelectItem>
                            <SelectItem value="Mrs">Mrs</SelectItem>
                            <SelectItem value="Ms">Ms</SelectItem>
                            <SelectItem value="Mdm">Mdm</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="col-span-3">
                        <Label className="form-label">Full Name *</Label>
                        <Input
                          value={cardholder.fullName}
                          onChange={(e) => updateCardholder(cardholder.id, 'fullName', e.target.value)}
                          placeholder="As per NRIC/Passport"
                          className="h-12"
                        />
                      </div>
                    </div>

                    <div>
                      <Label className="form-label">Date of Birth *</Label>
                      <Input
                        type="date"
                        value={cardholder.dateOfBirth}
                        onChange={(e) => updateCardholder(cardholder.id, 'dateOfBirth', e.target.value)}
                        className="h-12"
                      />
                    </div>

                    <div>
                      <Label className="form-label">Nationality *</Label>
                      <Select
                        value={cardholder.nationality}
                        onValueChange={(value) => updateCardholder(cardholder.id, 'nationality', value)}
                      >
                        <SelectTrigger className="h-12">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="singaporean">Singaporean</SelectItem>
                          <SelectItem value="singaporeanPR">Singapore PR</SelectItem>
                          <SelectItem value="foreigner">Foreigner</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {cardholder.nationality === 'singaporean' || cardholder.nationality === 'singaporeanPR' ? (
                      <div>
                        <Label className="form-label">NRIC Number *</Label>
                        <Input
                          value={cardholder.nricNumber}
                          onChange={(e) => updateCardholder(cardholder.id, 'nricNumber', e.target.value)}
                          placeholder="e.g., S1234567A"
                          className="h-12"
                        />
                      </div>
                    ) : (
                      <>
                        <div>
                          <Label className="form-label">Passport Number *</Label>
                          <Input
                            value={cardholder.passportNumber}
                            onChange={(e) => updateCardholder(cardholder.id, 'passportNumber', e.target.value)}
                            placeholder="Passport number"
                            className="h-12"
                          />
                        </div>
                        <div>
                          <Label className="form-label">Passport Country *</Label>
                          <Input
                            value={cardholder.passportCountry}
                            onChange={(e) => updateCardholder(cardholder.id, 'passportCountry', e.target.value)}
                            placeholder="Country of issue"
                            className="h-12"
                          />
                        </div>
                      </>
                    )}

                    <div className="md:col-span-2">
                      <Label className="form-label">Residential Address *</Label>
                      <Textarea
                        value={cardholder.residentialAddress}
                        onChange={(e) => updateCardholder(cardholder.id, 'residentialAddress', e.target.value)}
                        placeholder="Full address including postal code"
                        className="min-h-[80px]"
                      />
                    </div>

                    <div>
                      <Label className="form-label">Email *</Label>
                      <Input
                        type="email"
                        value={cardholder.email}
                        onChange={(e) => updateCardholder(cardholder.id, 'email', e.target.value)}
                        placeholder="email@example.com"
                        className="h-12"
                      />
                    </div>

                    <div>
                      <Label className="form-label">Mobile Number *</Label>
                      <Input
                        value={cardholder.mobileNumber}
                        onChange={(e) => updateCardholder(cardholder.id, 'mobileNumber', e.target.value)}
                        placeholder="+65-XXXX-XXXX"
                        className="h-12"
                      />
                    </div>

                    <div>
                      <Label className="form-label">Occupation *</Label>
                      <Select
                        value={cardholder.occupation}
                        onValueChange={(value) => updateCardholder(cardholder.id, 'occupation', value)}
                      >
                        <SelectTrigger className="h-12">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {occupations.map((occ) => (
                            <SelectItem key={occ.value} value={occ.value}>
                              {occ.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {cardholder.occupation === 'other' && (
                      <div>
                        <Label className="form-label">Specify Occupation</Label>
                        <Input
                          value={cardholder.occupationOther}
                          onChange={(e) => updateCardholder(cardholder.id, 'occupationOther', e.target.value)}
                          placeholder="Enter occupation"
                          className="h-12"
                        />
                      </div>
                    )}
                  </div>

                  {/* Daily Limits */}
                  <div className="space-y-4 pt-4 border-t border-border">
                    <h6 className="font-medium text-foreground">Daily Limits</h6>
                    <div className="grid gap-4 md:grid-cols-2">
                      <div>
                        <Label className="form-label">NETS/ATM Withdrawal Limit</Label>
                        <Select
                          value={cardholder.netsAtmLimit}
                          onValueChange={(value) => updateCardholder(cardholder.id, 'netsAtmLimit', value)}
                        >
                          <SelectTrigger className="h-12">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {atmLimits.map((limit) => (
                              <SelectItem key={limit} value={limit}>
                                S${parseInt(limit).toLocaleString()} {limit === '5000' && '(Default)'}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label className="form-label">NETS/Signature Payment Limit</Label>
                        <Select
                          value={cardholder.netsPaymentLimit}
                          onValueChange={(value) => updateCardholder(cardholder.id, 'netsPaymentLimit', value)}
                        >
                          <SelectTrigger className="h-12">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {paymentLimits.map((limit) => (
                              <SelectItem key={limit} value={limit}>
                                S${parseInt(limit).toLocaleString()} {limit === '5000' && '(Default)'}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>

                  {/* Name on Card */}
                  <div>
                    <Label className="form-label">Name on Card *</Label>
                    <Input
                      value={cardholder.nameOnCard}
                      onChange={(e) => updateCardholder(cardholder.id, 'nameOnCard', e.target.value.toUpperCase().slice(0, 19))}
                      placeholder="Max 19 characters"
                      maxLength={19}
                      className="h-12 uppercase"
                    />
                    <p className="form-description">{cardholder.nameOnCard.length}/19 characters</p>
                  </div>

                  {/* Cardholder Signature */}
                  <SignatureCanvas
                    value={cardholder.signature}
                    onChange={(signature) => updateCardholder(cardholder.id, 'signature', signature)}
                    label="Cardholder Signature *"
                  />
                </motion.div>
              ))}

              {data.businessDebitCard.cardholders.length < 2 && (
                <Button
                  type="button"
                  variant="outline"
                  onClick={addCardholder}
                  className="w-full h-12 border-dashed"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Cardholder
                </Button>
              )}
            </div>
          </motion.div>
        )}
      </motion.div>
    </motion.div>
  );
}
