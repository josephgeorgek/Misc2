import { motion } from 'framer-motion';
import { Repeat, Plus, Trash2, Bell } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { FormData, BillingOrganization, GIROSignature, AlertUser } from '@/types/form';
import { SignatureCanvas } from '../SignatureCanvas';

interface GIROStepProps {
  data: FormData;
  onChange: (data: Partial<FormData>) => void;
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
};

const governmentOrgs = [
  { value: 'hdb', label: 'Housing Development Board (HDB)' },
  { value: 'iras', label: 'Inland Revenue Authority of Singapore' },
  { value: 'cpf', label: 'Central Provident Fund Board' },
];

const telecomOrgs = [
  { value: 'm1', label: 'M1 Ltd' },
  { value: 'singtel', label: 'SingTel Ltd' },
  { value: 'starhub', label: 'StarHub Ltd' },
  { value: 'sp', label: 'SP Services Ltd' },
];

const insuranceOrgs = [
  { value: 'income', label: 'Income Insurance Limited' },
  { value: 'greateastern', label: 'The Great Eastern Life Assurance Co Ltd' },
];

export function GIROStep({ data, onChange }: GIROStepProps) {
  const updateGIRO = (field: string, value: any) => {
    onChange({
      giroApplication: { ...data.giroApplication, [field]: value },
    });
  };

  const updateEAlerts = (field: string, value: any) => {
    onChange({
      eAlerts: { ...data.eAlerts, [field]: value },
    });
  };

  // Billing organizations management
  const addBillingOrg = () => {
    const newOrg: BillingOrganization = {
      id: crypto.randomUUID(),
      type: 'government',
      organizationName: '',
      accountNumber: '',
      policyNumber: '',
    };
    updateGIRO('billingOrganizations', [...data.giroApplication.billingOrganizations, newOrg]);
  };

  const updateBillingOrg = (id: string, field: string, value: string) => {
    const updated = data.giroApplication.billingOrganizations.map((org) =>
      org.id === id ? { ...org, [field]: value } : org
    );
    updateGIRO('billingOrganizations', updated);
  };

  const removeBillingOrg = (id: string) => {
    updateGIRO(
      'billingOrganizations',
      data.giroApplication.billingOrganizations.filter((o) => o.id !== id)
    );
  };

  // GIRO signatures
  const addGIROSignature = () => {
    const newSig: GIROSignature = {
      id: crypto.randomUUID(),
      name: '',
      signature: '',
      date: '',
    };
    updateGIRO('signatures', [...data.giroApplication.signatures, newSig]);
  };

  const updateGIROSignature = (id: string, field: string, value: string) => {
    const updated = data.giroApplication.signatures.map((sig) =>
      sig.id === id ? { ...sig, [field]: value } : sig
    );
    updateGIRO('signatures', updated);
  };

  const removeGIROSignature = (id: string) => {
    updateGIRO(
      'signatures',
      data.giroApplication.signatures.filter((s) => s.id !== id)
    );
  };

  // Alert users management
  const addAlertUser = () => {
    const newUser: AlertUser = {
      id: crypto.randomUUID(),
      name: '',
      nricPassport: '',
      language: 'english',
      deliveryMethod: 'sms',
      perTransactionThreshold: '300',
      cumulativeThreshold: '5000',
    };
    updateEAlerts('alertUsers', [...data.eAlerts.alertUsers, newUser]);
  };

  const updateAlertUser = (id: string, field: string, value: string) => {
    const updated = data.eAlerts.alertUsers.map((user) =>
      user.id === id ? { ...user, [field]: value } : user
    );
    updateEAlerts('alertUsers', updated);
  };

  const removeAlertUser = (id: string) => {
    updateEAlerts(
      'alertUsers',
      data.eAlerts.alertUsers.filter((u) => u.id !== id)
    );
  };

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-8"
    >
      {/* GIRO Application */}
      <motion.div variants={itemVariants} className="form-section">
        <div className="flex items-center gap-3 mb-6">
          <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-accent">
            <Repeat className="w-5 h-5 text-accent-foreground" />
          </div>
          <div>
            <h3 className="text-lg font-semibold font-display text-foreground">GIRO Application</h3>
            <p className="text-sm text-muted-foreground">Automated bill payment</p>
          </div>
        </div>

        <div className="flex items-center justify-between p-4 rounded-xl border border-border mb-6">
          <div>
            <p className="font-medium text-foreground">Apply for GIRO</p>
            <p className="text-sm text-muted-foreground">Auto-debit for recurring payments</p>
          </div>
          <Switch
            checked={data.giroApplication.applyForGIRO}
            onCheckedChange={(checked) => updateGIRO('applyForGIRO', checked)}
          />
        </div>

        {data.giroApplication.applyForGIRO && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            className="space-y-6"
          >
            {/* Business Details */}
            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <Label className="form-label">Registered Name</Label>
                <Input
                  value={data.giroApplication.registeredName || data.businessDetails.registeredName}
                  onChange={(e) => updateGIRO('registeredName', e.target.value)}
                  className="h-12"
                />
              </div>
              <div>
                <Label className="form-label">Debit from Account</Label>
                <Input
                  value={data.giroApplication.debitAccountNumber}
                  onChange={(e) => updateGIRO('debitAccountNumber', e.target.value)}
                  placeholder="OCBC account number"
                  className="h-12"
                />
              </div>
            </div>

            {/* Billing Organizations */}
            <div className="space-y-4">
              <h4 className="font-semibold text-foreground">What do you want to pay?</h4>
              
              {data.giroApplication.billingOrganizations.map((org, index) => (
                <motion.div
                  key={org.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-4 rounded-xl border border-border space-y-4"
                >
                  <div className="flex items-center justify-between">
                    <h5 className="font-medium text-foreground">Billing Organization {index + 1}</h5>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => removeBillingOrg(org.id)}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>

                  <div className="grid gap-4 md:grid-cols-2">
                    <div>
                      <Label className="form-label">Category</Label>
                      <Select
                        value={org.type}
                        onValueChange={(value) => updateBillingOrg(org.id, 'type', value)}
                      >
                        <SelectTrigger className="h-12">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="government">Government Organization</SelectItem>
                          <SelectItem value="telecom">Telecommunications & Utilities</SelectItem>
                          <SelectItem value="insurance">Insurance</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label className="form-label">Organization</Label>
                      <Select
                        value={org.organizationName}
                        onValueChange={(value) => updateBillingOrg(org.id, 'organizationName', value)}
                      >
                        <SelectTrigger className="h-12">
                          <SelectValue placeholder="Select organization" />
                        </SelectTrigger>
                        <SelectContent>
                          {org.type === 'government' && governmentOrgs.map((o) => (
                            <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                          ))}
                          {org.type === 'telecom' && telecomOrgs.map((o) => (
                            <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                          ))}
                          {org.type === 'insurance' && insuranceOrgs.map((o) => (
                            <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label className="form-label">
                        {org.type === 'insurance' ? 'Policy Number' : 'Account Number'}
                      </Label>
                      <Input
                        value={org.type === 'insurance' ? org.policyNumber : org.accountNumber}
                        onChange={(e) => updateBillingOrg(org.id, org.type === 'insurance' ? 'policyNumber' : 'accountNumber', e.target.value)}
                        placeholder={org.type === 'insurance' ? 'Insurance policy number' : 'Account/Reference number'}
                        className="h-12"
                      />
                    </div>
                  </div>
                </motion.div>
              ))}

              <Button
                type="button"
                variant="outline"
                onClick={addBillingOrg}
                className="w-full h-12 border-dashed"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Billing Organization
              </Button>
            </div>

            {/* Authorised Signatures */}
            <div className="space-y-4">
              <h4 className="font-semibold text-foreground">Authorised Signatures</h4>
              
              {data.giroApplication.signatures.map((sig, index) => (
                <motion.div
                  key={sig.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-4 rounded-xl border border-border space-y-4"
                >
                  <div className="flex items-center justify-between">
                    <h5 className="font-medium text-foreground">Signatory {index + 1}</h5>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => removeGIROSignature(sig.id)}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>

                  <div className="grid gap-4 md:grid-cols-2">
                    <div>
                      <Label className="form-label">Name *</Label>
                      <Input
                        value={sig.name}
                        onChange={(e) => updateGIROSignature(sig.id, 'name', e.target.value)}
                        placeholder="Full name"
                        className="h-12"
                      />
                    </div>
                    <div>
                      <Label className="form-label">Date *</Label>
                      <Input
                        type="date"
                        value={sig.date}
                        onChange={(e) => updateGIROSignature(sig.id, 'date', e.target.value)}
                        className="h-12"
                      />
                    </div>
                  </div>

                  {/* Signature Canvas */}
                  <SignatureCanvas
                    value={sig.signature}
                    onChange={(signature) => updateGIROSignature(sig.id, 'signature', signature)}
                    label="Signature *"
                  />
                </motion.div>
              ))}

              <Button
                type="button"
                variant="outline"
                onClick={addGIROSignature}
                className="w-full h-12 border-dashed"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Signatory
              </Button>
            </div>
          </motion.div>
        )}
      </motion.div>

      {/* eAlerts */}
      <motion.div variants={itemVariants} className="form-section">
        <div className="flex items-center gap-3 mb-6">
          <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-accent">
            <Bell className="w-5 h-5 text-accent-foreground" />
          </div>
          <div>
            <h3 className="text-lg font-semibold font-display text-foreground">eAlerts@OCBC</h3>
            <p className="text-sm text-muted-foreground">Transaction notifications</p>
          </div>
        </div>

        <div className="flex items-center justify-between p-4 rounded-xl border border-border mb-6">
          <div>
            <p className="font-medium text-foreground">Apply for eAlerts</p>
            <p className="text-sm text-muted-foreground">Get notified of account transactions</p>
          </div>
          <Switch
            checked={data.eAlerts.applyForEAlerts}
            onCheckedChange={(checked) => updateEAlerts('applyForEAlerts', checked)}
          />
        </div>

        {data.eAlerts.applyForEAlerts && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            className="space-y-6"
          >
            <div>
              <Label className="form-label">Account Number for Alerts</Label>
              <Input
                value={data.eAlerts.linkedAccountNumber}
                onChange={(e) => updateEAlerts('linkedAccountNumber', e.target.value)}
                placeholder="Account to monitor"
                className="h-12"
              />
            </div>

            {/* Alert Users */}
            <div className="space-y-4">
              <h4 className="font-semibold text-foreground">Alert Recipients</h4>
              
              {data.eAlerts.alertUsers.map((user, index) => (
                <motion.div
                  key={user.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-4 rounded-xl border border-border space-y-4"
                >
                  <div className="flex items-center justify-between">
                    <h5 className="font-medium text-foreground">User {index + 1}</h5>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => removeAlertUser(user.id)}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>

                  <div className="grid gap-4 md:grid-cols-2">
                    <div>
                      <Label className="form-label">Name *</Label>
                      <Input
                        value={user.name}
                        onChange={(e) => updateAlertUser(user.id, 'name', e.target.value)}
                        placeholder="Full name"
                        className="h-12"
                      />
                    </div>
                    <div>
                      <Label className="form-label">NRIC/Passport *</Label>
                      <Input
                        value={user.nricPassport}
                        onChange={(e) => updateAlertUser(user.id, 'nricPassport', e.target.value)}
                        placeholder="e.g., S1234567A"
                        className="h-12"
                      />
                    </div>
                    <div>
                      <Label className="form-label">Language</Label>
                      <Select
                        value={user.language}
                        onValueChange={(value) => updateAlertUser(user.id, 'language', value)}
                      >
                        <SelectTrigger className="h-12">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="english">English</SelectItem>
                          <SelectItem value="chinese">Chinese</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label className="form-label">Delivery Method</Label>
                      <Select
                        value={user.deliveryMethod}
                        onValueChange={(value) => updateAlertUser(user.id, 'deliveryMethod', value)}
                      >
                        <SelectTrigger className="h-12">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="sms">SMS</SelectItem>
                          <SelectItem value="email">Email</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* Thresholds */}
                  <div className="grid gap-4 md:grid-cols-2 pt-4 border-t border-border">
                    <div>
                      <Label className="form-label">Per Transaction Alert</Label>
                      <Select
                        value={user.perTransactionThreshold}
                        onValueChange={(value) => updateAlertUser(user.id, 'perTransactionThreshold', value)}
                      >
                        <SelectTrigger className="h-12">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="300">S$300 & above</SelectItem>
                          <SelectItem value="500">S$500 & above</SelectItem>
                          <SelectItem value="1000">S$1,000 & above</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label className="form-label">Cumulative Amount Alert</Label>
                      <Select
                        value={user.cumulativeThreshold}
                        onValueChange={(value) => updateAlertUser(user.id, 'cumulativeThreshold', value)}
                      >
                        <SelectTrigger className="h-12">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="5000">S$5,000 & above</SelectItem>
                          <SelectItem value="20000">S$20,000 & above</SelectItem>
                          <SelectItem value="50000">S$50,000 & above</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </motion.div>
              ))}

              <Button
                type="button"
                variant="outline"
                onClick={addAlertUser}
                className="w-full h-12 border-dashed"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Alert Recipient
              </Button>
            </div>
          </motion.div>
        )}
      </motion.div>
    </motion.div>
  );
}
