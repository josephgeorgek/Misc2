import { motion } from 'framer-motion';
import { 
  Building2, 
  User, 
  Banknote, 
  Wallet, 
  Users, 
  FileCheck, 
  Check,
  Edit2,
  FileText,
  Globe,
  Monitor,
  CreditCard,
  Bell,
  Receipt
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { FormData } from '@/types/form';
import { cn } from '@/lib/utils';
import { AuthorizedSignaturesSection } from '../AuthorizedSignaturesSection';

interface ReviewStepProps {
  data: FormData;
  onChange: (data: Partial<FormData>) => void;
  onEditStep: (step: number) => void;
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
};

function ReviewSection({
  icon: Icon,
  title,
  children,
  step,
  onEdit,
}: {
  icon: React.ElementType;
  title: string;
  children: React.ReactNode;
  step: number;
  onEdit: (step: number) => void;
}) {
  return (
    <motion.div variants={itemVariants} className="form-section">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-accent">
            <Icon className="w-5 h-5 text-accent-foreground" />
          </div>
          <h3 className="text-lg font-semibold font-display text-foreground">{title}</h3>
        </div>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          onClick={() => onEdit(step)}
          className="text-primary hover:text-primary hover:bg-accent"
        >
          <Edit2 className="w-4 h-4 mr-1" />
          Edit
        </Button>
      </div>
      <div className="space-y-3">{children}</div>
    </motion.div>
  );
}

function ReviewItem({ label, value }: { label: string; value: string | React.ReactNode }) {
  return (
    <div className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-4 py-2 border-b border-border/50 last:border-0">
      <span className="text-sm text-muted-foreground w-40 flex-shrink-0">{label}</span>
      <span className="text-sm font-medium text-foreground">{value || '-'}</span>
    </div>
  );
}

function ReviewBadge({ children }: { children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center px-2 py-1 rounded-md bg-accent text-accent-foreground text-xs font-medium">
      {children}
    </span>
  );
}

export function ReviewStep({ data, onChange, onEditStep }: ReviewStepProps) {
  const businessTypeLabels: Record<string, string> = {
    'sole-proprietorship': 'Sole Proprietorship',
    'partnership': 'Partnership',
    'private-limited': 'Private Limited',
    'public-company': 'Public Company',
    'association': 'Association/Club/Society',
    'others': 'Others',
  };

  const signingTypeLabels: Record<string, string> = {
    singly: 'Singly (Any one signatory)',
    anyTwo: 'Any Two Jointly',
    grouping: 'Grouping with Signing Limits',
  };

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-6"
    >
      {/* Success Banner */}
      <motion.div
        variants={itemVariants}
        className="p-4 rounded-xl bg-success/10 border border-success/20"
      >
        <div className="flex items-start gap-3">
          <div className="flex items-center justify-center w-8 h-8 rounded-full bg-success text-success-foreground">
            <Check className="w-4 h-4" />
          </div>
          <div>
            <h4 className="font-semibold text-foreground">Almost Done!</h4>
            <p className="text-sm text-muted-foreground mt-1">
              Please review your application details below. Click "Edit" on any section to make changes.
            </p>
          </div>
        </div>
      </motion.div>

      {/* Business Details */}
      <ReviewSection icon={Building2} title="Business Details" step={1} onEdit={onEditStep}>
        <ReviewItem label="Business Name" value={data.businessDetails.registeredName} />
        <ReviewItem label="Registration (UEN)" value={data.businessDetails.registrationNumber} />
        <ReviewItem 
          label="Business Type" 
          value={businessTypeLabels[data.businessDetails.businessType] || data.businessDetails.businessType} 
        />
        <ReviewItem label="Nature of Business" value={data.businessDetails.natureOfBusiness} />
        <ReviewItem label="Country" value={data.businessDetails.countryOfDomicile} />
        <ReviewItem 
          label="GST Registered" 
          value={data.businessDetails.gstRegistered === null ? '-' : data.businessDetails.gstRegistered ? 'Yes' : 'No'} 
        />
        <ReviewItem label="Office Number" value={data.businessDetails.officeNumber} />
        <ReviewItem label="Fax Number" value={data.businessDetails.faxNumber} />
      </ReviewSection>

      {/* Contact Persons */}
      <ReviewSection icon={User} title="Contact Persons" step={1} onEdit={onEditStep}>
        <div className="mb-4">
          <h4 className="text-sm font-medium text-foreground mb-2">Primary Contact</h4>
          <ReviewItem label="Name" value={data.primaryContact.fullName} />
          <ReviewItem label="NRIC/Passport" value={data.primaryContact.nricPassport} />
          <ReviewItem label="Email" value={data.primaryContact.email} />
          <ReviewItem label="Mobile" value={data.primaryContact.mobileNumber} />
          <ReviewItem label="Office" value={data.primaryContact.officeNumber} />
        </div>
        {data.secondaryContact.fullName && (
          <div>
            <h4 className="text-sm font-medium text-foreground mb-2">Secondary Contact</h4>
            <ReviewItem label="Name" value={data.secondaryContact.fullName} />
            <ReviewItem label="NRIC/Passport" value={data.secondaryContact.nricPassport} />
            <ReviewItem label="Email" value={data.secondaryContact.email} />
            <ReviewItem label="Mobile" value={data.secondaryContact.mobileNumber} />
            <ReviewItem label="Office" value={data.secondaryContact.officeNumber} />
          </div>
        )}
      </ReviewSection>

      {/* Account Types */}
      <ReviewSection icon={Banknote} title="Account Types" step={2} onEdit={onEditStep}>
        <div className="space-y-3">
          {data.accountType.sgdAccounts.length > 0 && (
            <div>
              <span className="text-sm text-muted-foreground block mb-2">SGD Accounts</span>
              <div className="flex flex-wrap gap-2">
                {data.accountType.sgdAccounts.map((account) => (
                  <ReviewBadge key={account}>{account}</ReviewBadge>
                ))}
              </div>
            </div>
          )}
          {data.accountType.foreignCurrencyAccounts.length > 0 && (
            <div>
              <span className="text-sm text-muted-foreground block mb-2">Foreign Currency Accounts</span>
              <div className="flex flex-wrap gap-2">
                {data.accountType.foreignCurrencyAccounts.map((account) => (
                  <ReviewBadge key={account}>{account}</ReviewBadge>
                ))}
              </div>
            </div>
          )}
          {data.accountType.currencies.length > 0 && (
            <div>
              <span className="text-sm text-muted-foreground block mb-2">Currencies</span>
              <div className="flex flex-wrap gap-2">
                {data.accountType.currencies.map((currency) => (
                  <ReviewBadge key={currency}>{currency.toUpperCase()}</ReviewBadge>
                ))}
              </div>
            </div>
          )}
        </div>
      </ReviewSection>

      {/* Account Particulars */}
      <ReviewSection icon={Wallet} title="Account Particulars" step={3} onEdit={onEditStep}>
        <div className="space-y-3">
          <ReviewItem label="Account Name" value={data.accountParticulars.accountName} />
          <ReviewItem label="Mailing Address" value={data.accountParticulars.mailingAddress} />
          {data.accountParticulars.sourceOfCapital.length > 0 && (
            <div>
              <span className="text-sm text-muted-foreground block mb-2">Source of Capital</span>
              <div className="flex flex-wrap gap-2">
                {data.accountParticulars.sourceOfCapital.map((source) => (
                  <ReviewBadge key={source}>{source}</ReviewBadge>
                ))}
              </div>
            </div>
          )}
          <ReviewItem label="PayNow Sign-up" value={data.accountParticulars.payNowSignUp ? 'Yes' : 'No'} />
          <ReviewItem label="SGQR Sign-up" value={data.accountParticulars.sgqrSignUp ? 'Yes' : 'No'} />
          {data.accountParticulars.sgqrSignUp && data.accountParticulars.outlets.length > 0 && (
            <div>
              <span className="text-sm text-muted-foreground block mb-2">SGQR Outlets</span>
              {data.accountParticulars.outlets.filter(o => o.outletName).map((outlet, idx) => (
                <div key={idx} className="text-sm text-foreground">
                  {outlet.outletName} - {outlet.postalCode}
                </div>
              ))}
            </div>
          )}
        </div>
      </ReviewSection>

      {/* Beneficial Owners */}
      <ReviewSection icon={Users} title="Beneficial Owners & Signatories" step={4} onEdit={onEditStep}>
        <div className="space-y-4">
          {data.beneficialOwners.map((owner, index) => (
            <div key={owner.id} className="p-3 rounded-lg bg-muted/50">
              <div className="flex items-center gap-2 mb-2">
                <span className="font-medium text-foreground">{owner.fullName || `Person ${index + 1}`}</span>
                <div className="flex gap-1">
                  {owner.isBeneficialOwner && <ReviewBadge>Owner</ReviewBadge>}
                  {owner.isAuthorisedSignatory && <ReviewBadge>Signatory</ReviewBadge>}
                  {owner.grouping && <ReviewBadge>Group {owner.grouping}</ReviewBadge>}
                </div>
              </div>
              <div className="text-sm text-muted-foreground">
                {owner.designation} • {owner.nricPassport} • {owner.email}
              </div>
            </div>
          ))}
          <ReviewItem label="Signing Condition" value={signingTypeLabels[data.signingCondition.type]} />
          {data.signingCondition.type === 'grouping' && data.signingCondition.details && (
            <ReviewItem label="Signing Details" value={data.signingCondition.details} />
          )}
          <ReviewItem label="Apply to All Accounts" value={data.signingCondition.applyToAllAccounts ? 'Yes' : 'No'} />
        </div>
      </ReviewSection>

      {/* Board Resolution */}
      <ReviewSection icon={FileText} title="Board Resolution" step={5} onEdit={onEditStep}>
        <ReviewItem label="Company Name" value={data.boardResolution.companyName} />
        <ReviewItem label="Meeting Date" value={data.boardResolution.meetingDate} />
        <ReviewItem label="Resolution Passed" value={data.boardResolution.resolutionPassed ? 'Yes' : 'No'} />
        <div className="mt-2">
          <span className="text-sm text-muted-foreground block mb-2">Authorised Activities</span>
          <div className="flex flex-wrap gap-2">
            {data.boardResolution.openCloseAccounts && <ReviewBadge>Open/Close Accounts</ReviewBadge>}
            {data.boardResolution.applyBankingServices && <ReviewBadge>Banking Services</ReviewBadge>}
            {data.boardResolution.appointAuthorisedUsers && <ReviewBadge>Appoint Users</ReviewBadge>}
            {data.boardResolution.appointAuthorisedSignatories && <ReviewBadge>Appoint Signatories</ReviewBadge>}
            {data.boardResolution.borrowingAndSecurity && <ReviewBadge>Borrowing</ReviewBadge>}
            {data.boardResolution.corporateCreditCard && <ReviewBadge>Corporate Card</ReviewBadge>}
            {data.boardResolution.electronicSigning && <ReviewBadge>Electronic Signing</ReviewBadge>}
          </div>
        </div>
        {data.boardResolution.authorisedPersons.length > 0 && (
          <div className="mt-2">
            <span className="text-sm text-muted-foreground block mb-2">Authorised Persons ({data.boardResolution.authorisedPersons.length})</span>
            {data.boardResolution.authorisedPersons.map((person, idx) => (
              <div key={person.id || idx} className="text-sm text-foreground">
                {person.fullName} - {person.designation}
              </div>
            ))}
          </div>
        )}
        <ReviewItem label="Signing Mandate" value={data.boardResolution.signingMandate} />
        <ReviewItem label="Signing Limits" value={data.boardResolution.signingLimits} />
      </ReviewSection>

      {/* Tax Declaration */}
      <ReviewSection icon={Globe} title="Tax Declaration (FATCA/CRS)" step={6} onEdit={onEditStep}>
        <ReviewItem label="Entity Name" value={data.taxDeclarationEntity.registeredName} />
        <ReviewItem label="Registration No." value={data.taxDeclarationEntity.registrationNumber} />
        <ReviewItem label="Registered Address" value={data.taxDeclarationEntity.registeredAddress} />
        <ReviewItem label="Country" value={data.taxDeclarationEntity.country} />
        <ReviewItem 
          label="Entity Type" 
          value={data.taxDeclarationEntity.entityType === 'financialInstitution' ? 'Financial Institution' : 'Non-Financial Institution'} 
        />
        {data.taxDeclarationEntity.taxResidencies.length > 0 && (
          <div className="mt-2">
            <span className="text-sm text-muted-foreground block mb-2">Tax Residencies</span>
            {data.taxDeclarationEntity.taxResidencies.map((tax, idx) => (
              <div key={tax.id || idx} className="text-sm text-foreground">
                {tax.country} - TIN: {tax.tin || 'N/A'}
              </div>
            ))}
          </div>
        )}
      </ReviewSection>

      {/* Business Banking Services */}
      <ReviewSection icon={Monitor} title="Business Banking Services (Velocity)" step={7} onEdit={onEditStep}>
        <ReviewItem label="Apply for Velocity" value={data.businessBankingServices.applyForVelocity ? 'Yes' : 'No'} />
        {data.businessBankingServices.applyForVelocity && (
          <>
            <ReviewItem label="Organisation ID" value={data.businessBankingServices.organisationId} />
            <ReviewItem label="Contact Person" value={data.businessBankingServices.contactPersonName} />
            <ReviewItem label="Contact Email" value={data.businessBankingServices.contactPersonEmail} />
            <ReviewItem 
              label="Service Package" 
              value={data.businessBankingServices.servicePackage.charAt(0).toUpperCase() + data.businessBankingServices.servicePackage.slice(1)} 
            />
            <ReviewItem 
              label="2FA Method" 
              value={data.businessBankingServices.twoFactorMethod === 'digital' ? 'Digital Token' : 'Hardware Token'} 
            />
            <ReviewItem label="e-Statement" value={data.businessBankingServices.eStatementEnabled ? 'Enabled' : 'Disabled'} />
            {data.businessBankingServices.velocityUsers.length > 0 && (
              <div className="mt-2">
                <span className="text-sm text-muted-foreground block mb-2">Velocity Users ({data.businessBankingServices.velocityUsers.length})</span>
                {data.businessBankingServices.velocityUsers.map((user, idx) => (
                  <div key={user.id || idx} className="text-sm text-foreground">
                    {user.fullName} - {user.role} - {user.email}
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </ReviewSection>

      {/* Debit Card */}
      <ReviewSection icon={CreditCard} title="Business Debit Card" step={8} onEdit={onEditStep}>
        <ReviewItem label="Apply for Debit Card" value={data.businessDebitCard.applyForDebitCard ? 'Yes' : 'No'} />
        {data.businessDebitCard.applyForDebitCard && (
          <>
            <ReviewItem label="Linked Account" value={data.businessDebitCard.linkedAccountNumber || 'New Account'} />
            {data.businessDebitCard.cardholders.length > 0 && (
              <div className="mt-2">
                <span className="text-sm text-muted-foreground block mb-2">Cardholders ({data.businessDebitCard.cardholders.length})</span>
                {data.businessDebitCard.cardholders.map((holder, idx) => (
                  <div key={holder.id || idx} className="p-2 rounded bg-muted/50 mb-2">
                    <div className="text-sm font-medium text-foreground">{holder.fullName}</div>
                    <div className="text-xs text-muted-foreground">
                      Name on Card: {holder.nameOnCard} | NETS ATM: ${holder.netsAtmLimit} | NETS Payment: ${holder.netsPaymentLimit}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </ReviewSection>

      {/* GIRO & eAlerts */}
      <ReviewSection icon={Receipt} title="GIRO & eAlerts" step={9} onEdit={onEditStep}>
        <div className="mb-4">
          <h4 className="text-sm font-medium text-foreground mb-2">GIRO Application</h4>
          <ReviewItem label="Apply for GIRO" value={data.giroApplication.applyForGIRO ? 'Yes' : 'No'} />
          {data.giroApplication.applyForGIRO && (
            <>
              <ReviewItem label="Debit Account" value={data.giroApplication.debitAccountNumber} />
              {data.giroApplication.billingOrganizations.length > 0 && (
                <div className="mt-2">
                  <span className="text-sm text-muted-foreground block mb-2">Billing Organizations</span>
                  {data.giroApplication.billingOrganizations.map((org, idx) => (
                    <div key={org.id || idx} className="text-sm text-foreground">
                      {org.organizationName} - {org.accountNumber}
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
        <div>
          <h4 className="text-sm font-medium text-foreground mb-2">eAlerts</h4>
          <ReviewItem label="Apply for eAlerts" value={data.eAlerts.applyForEAlerts ? 'Yes' : 'No'} />
          {data.eAlerts.applyForEAlerts && data.eAlerts.alertUsers.length > 0 && (
            <div className="mt-2">
              <span className="text-sm text-muted-foreground block mb-2">Alert Users</span>
              {data.eAlerts.alertUsers.map((user, idx) => (
                <div key={user.id || idx} className="text-sm text-foreground">
                  {user.name} - {user.deliveryMethod.toUpperCase()} - Threshold: ${user.perTransactionThreshold}
                </div>
              ))}
            </div>
          )}
        </div>
      </ReviewSection>

      {/* Authorized Signatures - Before Terms */}
      <AuthorizedSignaturesSection
        signatures={data.agreement.agreementSignatures}
        onChange={(signatures) => onChange({ 
          agreement: { 
            ...data.agreement, 
            agreementSignatures: signatures 
          } 
        })}
      />

      {/* Terms Agreement */}
      <motion.div variants={itemVariants} className="form-section">
        <div className="flex items-center gap-3 mb-4">
          <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-accent">
            <FileCheck className="w-5 h-5 text-accent-foreground" />
          </div>
          <h3 className="text-lg font-semibold font-display text-foreground">Terms & Conditions</h3>
        </div>

        <div className="p-4 rounded-xl bg-muted/50 border border-border mb-4 max-h-48 overflow-y-auto text-sm text-muted-foreground">
          <p className="mb-3">
            I/We request the Bank to open the above account(s). I/We have received and read a copy of the 
            Business Account Terms and Conditions and have fully understood its contents. I/We agree to 
            abide and be bound by them and any amendments, alterations and additions thereto.
          </p>
          <p className="mb-3">
            I/We confirm that all the information I/we have provided is true, accurate and complete and 
            I/we have not withheld any information. I/we undertake to keep the Bank informed in writing, 
            within 30 days, of any changes in circumstances.
          </p>
          <p className="mb-3">
            I/We consent to disclosures as provided therein and agree that all payments be debited from 
            the Account(s).
          </p>
          <p className="mb-3">
            <strong>FATCA Declaration:</strong> I/We certify that I/we have provided all the information 
            required under the U.S. Foreign Account Tax Compliance Act (FATCA) and Singapore's obligations 
            thereunder.
          </p>
          <p>
            <strong>CRS Declaration:</strong> I/We certify that the information provided above is accurate 
            and complete. I/We undertake to notify the Bank of any changes in circumstances which affect the 
            tax residency status of the account holder(s) or cause the information contained herein to become 
            incorrect or incomplete.
          </p>
        </div>

        <div className="space-y-3">
          <div
            className={cn(
              'flex items-start space-x-3 p-4 rounded-xl border-2 transition-colors cursor-pointer',
              data.agreeToTerms ? 'border-primary bg-accent' : 'border-border hover:border-primary/50'
            )}
            onClick={() => onChange({ agreeToTerms: !data.agreeToTerms })}
          >
            <Checkbox
              id="agree-terms"
              checked={data.agreeToTerms}
              onCheckedChange={(checked) => onChange({ agreeToTerms: checked as boolean })}
              className="mt-0.5"
            />
            <Label htmlFor="agree-terms" className="cursor-pointer">
              <span className="font-medium text-foreground">
                I agree to all Terms and Conditions *
              </span>
              <p className="text-sm text-muted-foreground mt-1">
                By checking this box, I confirm that I have read and agree to the Business Account Terms 
                and Conditions, FATCA & CRS declarations, and that all information provided is accurate and complete.
              </p>
            </Label>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}