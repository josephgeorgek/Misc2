import { useState } from 'react';
import { motion } from 'framer-motion';
import { FileWarning, Building2, User, Plus, Trash2, Globe } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { FormData, TaxResidency, ControllingPerson } from '@/types/form';

interface TaxDeclarationStepProps {
  data: FormData;
  onChange: (data: Partial<FormData>) => void;
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
};

const countries = [
  'Singapore', 'United States', 'United Kingdom', 'Australia', 'Canada',
  'China', 'Hong Kong', 'India', 'Indonesia', 'Japan', 'Malaysia',
  'New Zealand', 'Philippines', 'South Korea', 'Taiwan', 'Thailand', 'Vietnam',
];

export function TaxDeclarationStep({ data, onChange }: TaxDeclarationStepProps) {
  const [activeTab, setActiveTab] = useState('entity');

  const updateEntityTax = (field: string, value: any) => {
    onChange({
      taxDeclarationEntity: { ...data.taxDeclarationEntity, [field]: value },
    });
  };

  const updateIndividualTax = (field: string, value: any) => {
    onChange({
      taxDeclarationIndividual: { ...data.taxDeclarationIndividual, [field]: value },
    });
  };

  // Entity tax residency management
  const addEntityTaxResidency = () => {
    const newResidency: TaxResidency = {
      id: crypto.randomUUID(),
      country: '',
      tin: '',
      noTinReason: 'notIssued',
      noTinExplanation: '',
    };
    updateEntityTax('taxResidencies', [...data.taxDeclarationEntity.taxResidencies, newResidency]);
  };

  const updateEntityTaxResidency = (id: string, field: string, value: string) => {
    const updated = data.taxDeclarationEntity.taxResidencies.map((r) =>
      r.id === id ? { ...r, [field]: value } : r
    );
    updateEntityTax('taxResidencies', updated);
  };

  const removeEntityTaxResidency = (id: string) => {
    updateEntityTax(
      'taxResidencies',
      data.taxDeclarationEntity.taxResidencies.filter((r) => r.id !== id)
    );
  };

  // Individual tax residency management
  const addIndividualTaxResidency = () => {
    const newResidency: TaxResidency = {
      id: crypto.randomUUID(),
      country: '',
      tin: '',
      noTinReason: 'notIssued',
      noTinExplanation: '',
    };
    updateIndividualTax('taxResidencies', [...data.taxDeclarationIndividual.taxResidencies, newResidency]);
  };

  const updateIndividualTaxResidency = (id: string, field: string, value: string) => {
    const updated = data.taxDeclarationIndividual.taxResidencies.map((r) =>
      r.id === id ? { ...r, [field]: value } : r
    );
    updateIndividualTax('taxResidencies', updated);
  };

  const removeIndividualTaxResidency = (id: string) => {
    updateIndividualTax(
      'taxResidencies',
      data.taxDeclarationIndividual.taxResidencies.filter((r) => r.id !== id)
    );
  };

  // Controlling persons management
  const addControllingPerson = () => {
    const newPerson: ControllingPerson = {
      id: crypto.randomUUID(),
      fullName: '',
      nricPassport: '',
      dateOfBirth: '',
      countryOfBirth: '',
      residentialAddress: '',
      country: 'Singapore',
      postalCode: '',
      taxResidencies: [],
      controllingPersonType: '',
    };
    updateEntityTax('controllingPersons', [...data.taxDeclarationEntity.controllingPersons, newPerson]);
  };

  const updateControllingPerson = (id: string, field: string, value: any) => {
    const updated = data.taxDeclarationEntity.controllingPersons.map((p) =>
      p.id === id ? { ...p, [field]: value } : p
    );
    updateEntityTax('controllingPersons', updated);
  };

  const removeControllingPerson = (id: string) => {
    updateEntityTax(
      'controllingPersons',
      data.taxDeclarationEntity.controllingPersons.filter((p) => p.id !== id)
    );
  };

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-8"
    >
      {/* Header */}
      <motion.div variants={itemVariants} className="form-section">
        <div className="flex items-center gap-3 mb-6">
          <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-accent">
            <FileWarning className="w-5 h-5 text-accent-foreground" />
          </div>
          <div>
            <h3 className="text-lg font-semibold font-display text-foreground">Tax Declaration</h3>
            <p className="text-sm text-muted-foreground">FATCA & CRS Compliance</p>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-muted/50 border border-border mb-6">
          <p className="text-sm text-muted-foreground">
            Under the Foreign Account Tax Compliance Act (FATCA) and Common Reporting Standard (CRS), 
            we are required to collect and report tax information about account holders.
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="entity" className="flex items-center gap-2">
              <Building2 className="w-4 h-4" />
              Entity
            </TabsTrigger>
            <TabsTrigger value="individual" className="flex items-center gap-2">
              <User className="w-4 h-4" />
              Individual (Sole Prop)
            </TabsTrigger>
          </TabsList>

          {/* Entity Tax Declaration */}
          <TabsContent value="entity" className="space-y-6 mt-6">
            {/* Entity Details */}
            <div className="space-y-4">
              <h4 className="font-semibold text-foreground">Entity Details</h4>
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <Label className="form-label">Registered Name *</Label>
                  <Input
                    value={data.taxDeclarationEntity.registeredName}
                    onChange={(e) => updateEntityTax('registeredName', e.target.value)}
                    placeholder="Entity name"
                    className="h-12"
                  />
                </div>
                <div>
                  <Label className="form-label">Registration Number *</Label>
                  <Input
                    value={data.taxDeclarationEntity.registrationNumber}
                    onChange={(e) => updateEntityTax('registrationNumber', e.target.value)}
                    placeholder="UEN"
                    className="h-12"
                  />
                </div>
                <div className="md:col-span-2">
                  <Label className="form-label">Registered Address *</Label>
                  <Textarea
                    value={data.taxDeclarationEntity.registeredAddress}
                    onChange={(e) => updateEntityTax('registeredAddress', e.target.value)}
                    placeholder="Full address"
                    className="min-h-[80px]"
                  />
                </div>
                <div>
                  <Label className="form-label">Country *</Label>
                  <Select
                    value={data.taxDeclarationEntity.country}
                    onValueChange={(value) => updateEntityTax('country', value)}
                  >
                    <SelectTrigger className="h-12">
                      <SelectValue placeholder="Select country" />
                    </SelectTrigger>
                    <SelectContent>
                      {countries.map((country) => (
                        <SelectItem key={country} value={country}>
                          {country}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="form-label">Postal Code *</Label>
                  <Input
                    value={data.taxDeclarationEntity.postalCode}
                    onChange={(e) => updateEntityTax('postalCode', e.target.value)}
                    placeholder="e.g., 123456"
                    className="h-12"
                  />
                </div>
              </div>
            </div>

            {/* Entity Type */}
            <div className="space-y-4">
              <h4 className="font-semibold text-foreground">Entity Type</h4>
              <RadioGroup
                value={data.taxDeclarationEntity.entityType}
                onValueChange={(value) => updateEntityTax('entityType', value)}
                className="space-y-3"
              >
                <div className="flex items-center space-x-3 p-4 rounded-xl border border-border">
                  <RadioGroupItem value="notFinancialInstitution" id="not-fi" />
                  <Label htmlFor="not-fi" className="flex-1 cursor-pointer">
                    <span className="font-medium">Not a Financial Institution</span>
                    <p className="text-sm text-muted-foreground">Active business, public sector, etc.</p>
                  </Label>
                </div>
                <div className="flex items-center space-x-3 p-4 rounded-xl border border-border">
                  <RadioGroupItem value="financialInstitution" id="is-fi" />
                  <Label htmlFor="is-fi" className="flex-1 cursor-pointer">
                    <span className="font-medium">Financial Institution</span>
                    <p className="text-sm text-muted-foreground">Depository, custodial, investment entity</p>
                  </Label>
                </div>
              </RadioGroup>
            </div>

            {/* Non-FI Type Selection */}
            {data.taxDeclarationEntity.entityType === 'notFinancialInstitution' && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                className="space-y-4"
              >
                <h4 className="font-semibold text-foreground">FATCA/CRS Status</h4>
                <RadioGroup
                  value={data.taxDeclarationEntity.nonFIType}
                  onValueChange={(value) => updateEntityTax('nonFIType', value)}
                  className="space-y-3"
                >
                  <div className="flex items-start space-x-3 p-4 rounded-xl border border-border">
                    <RadioGroupItem value="activeBusiness" id="active-business" className="mt-1" />
                    <Label htmlFor="active-business" className="flex-1 cursor-pointer">
                      <span className="font-medium">Active Business / Charity / Non-Profit</span>
                      <p className="text-sm text-muted-foreground">
                        Less than 50% gross income from passive income; less than 50% assets produce passive income
                      </p>
                    </Label>
                  </div>
                  <div className="flex items-start space-x-3 p-4 rounded-xl border border-border">
                    <RadioGroupItem value="publicSector" id="public-sector" className="mt-1" />
                    <Label htmlFor="public-sector" className="flex-1 cursor-pointer">
                      <span className="font-medium">Public Sector Entity</span>
                      <p className="text-sm text-muted-foreground">
                        Government agencies, statutory boards, embassies, international organisations
                      </p>
                    </Label>
                  </div>
                  <div className="flex items-start space-x-3 p-4 rounded-xl border border-border">
                    <RadioGroupItem value="publiclyListed" id="publicly-listed" className="mt-1" />
                    <Label htmlFor="publicly-listed" className="flex-1 cursor-pointer">
                      <span className="font-medium">Publicly Listed Company</span>
                      <p className="text-sm text-muted-foreground">
                        Stock regularly traded on established securities market
                      </p>
                    </Label>
                  </div>
                  <div className="flex items-start space-x-3 p-4 rounded-xl border border-border">
                    <RadioGroupItem value="passiveInvestment" id="passive-investment" className="mt-1" />
                    <Label htmlFor="passive-investment" className="flex-1 cursor-pointer">
                      <span className="font-medium">Passive Investment Entity</span>
                      <p className="text-sm text-muted-foreground">
                        More than 50% income from investments, dividends, interests, rents, royalties
                      </p>
                    </Label>
                  </div>
                  <div className="flex items-start space-x-3 p-4 rounded-xl border border-border">
                    <RadioGroupItem value="other" id="other-type" className="mt-1" />
                    <Label htmlFor="other-type" className="flex-1 cursor-pointer">
                      <span className="font-medium">Other</span>
                      <p className="text-sm text-muted-foreground">
                        Please seek professional tax advice
                      </p>
                    </Label>
                  </div>
                </RadioGroup>

                {data.taxDeclarationEntity.nonFIType === 'publiclyListed' && (
                  <div className="grid gap-4 md:grid-cols-2 mt-4">
                    <div>
                      <Label className="form-label">Securities Market Name *</Label>
                      <Input
                        value={data.taxDeclarationEntity.securitiesMarketName}
                        onChange={(e) => updateEntityTax('securitiesMarketName', e.target.value)}
                        placeholder="e.g., SGX"
                        className="h-12"
                      />
                    </div>
                    <div>
                      <Label className="form-label">Entity Name on Market</Label>
                      <Input
                        value={data.taxDeclarationEntity.entityNameOnMarket}
                        onChange={(e) => updateEntityTax('entityNameOnMarket', e.target.value)}
                        placeholder="If different from registered name"
                        className="h-12"
                      />
                    </div>
                  </div>
                )}
              </motion.div>
            )}

            {/* Financial Institution Type Selection */}
            {data.taxDeclarationEntity.entityType === 'financialInstitution' && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                className="space-y-4"
              >
                <h4 className="font-semibold text-foreground">Financial Institution Type</h4>
                <RadioGroup
                  value={data.taxDeclarationEntity.fiType}
                  onValueChange={(value) => updateEntityTax('fiType', value)}
                  className="space-y-3"
                >
                  <div className="flex items-start space-x-3 p-4 rounded-xl border border-border">
                    <RadioGroupItem value="depository" id="fi-depository" className="mt-1" />
                    <Label htmlFor="fi-depository" className="flex-1 cursor-pointer">
                      <span className="font-medium">Depository/Custodial/Insurance</span>
                      <p className="text-sm text-muted-foreground">
                        Depository Institution, Custodial Institution or Specified Insurance Company
                      </p>
                    </Label>
                  </div>
                  <div className="flex items-start space-x-3 p-4 rounded-xl border border-border">
                    <RadioGroupItem value="investmentNonParticipating" id="fi-investment-np" className="mt-1" />
                    <Label htmlFor="fi-investment-np" className="flex-1 cursor-pointer">
                      <span className="font-medium">Investment Entity (Non-Participating)</span>
                      <p className="text-sm text-muted-foreground">
                        Located in Non-Participating Jurisdiction managed by another FI
                      </p>
                    </Label>
                  </div>
                  <div className="flex items-start space-x-3 p-4 rounded-xl border border-border">
                    <RadioGroupItem value="investmentOther" id="fi-investment-other" className="mt-1" />
                    <Label htmlFor="fi-investment-other" className="flex-1 cursor-pointer">
                      <span className="font-medium">Other Investment Entity</span>
                      <p className="text-sm text-muted-foreground">
                        Including Investment Entity in Participating Jurisdiction
                      </p>
                    </Label>
                  </div>
                  <div className="flex items-start space-x-3 p-4 rounded-xl border border-border">
                    <RadioGroupItem value="trustNotManaged" id="fi-trust" className="mt-1" />
                    <Label htmlFor="fi-trust" className="flex-1 cursor-pointer">
                      <span className="font-medium">Trust Not Professionally Managed</span>
                      <p className="text-sm text-muted-foreground">
                        Trust not professionally managed by another Financial Institution
                      </p>
                    </Label>
                  </div>
                </RadioGroup>
              </motion.div>
            )}

            {/* Tax Residency */}
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <Globe className="w-5 h-5 text-muted-foreground" />
                <h4 className="font-semibold text-foreground">Tax Residency</h4>
              </div>

              <div className="space-y-4">
                {data.taxDeclarationEntity.taxResidencies.map((residency, index) => (
                  <motion.div
                    key={residency.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="p-4 rounded-xl border border-border space-y-4"
                  >
                    <div className="flex items-center justify-between">
                      <h5 className="font-medium text-foreground">Tax Residency {index + 1}</h5>
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => removeEntityTaxResidency(residency.id)}
                        className="text-destructive hover:text-destructive"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>

                    <div className="grid gap-4 md:grid-cols-2">
                      <div>
                        <Label className="form-label">Country *</Label>
                        <Select
                          value={residency.country}
                          onValueChange={(value) => updateEntityTaxResidency(residency.id, 'country', value)}
                        >
                          <SelectTrigger className="h-12">
                            <SelectValue placeholder="Select country" />
                          </SelectTrigger>
                          <SelectContent>
                            {countries.map((country) => (
                              <SelectItem key={country} value={country}>
                                {country}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label className="form-label">TIN (Tax ID Number)</Label>
                        <Input
                          value={residency.tin}
                          onChange={(e) => updateEntityTaxResidency(residency.id, 'tin', e.target.value)}
                          placeholder="Taxpayer Identification Number"
                          className="h-12"
                        />
                      </div>
                      {!residency.tin && (
                        <>
                          <div>
                            <Label className="form-label">Reason for No TIN</Label>
                            <Select
                              value={residency.noTinReason}
                              onValueChange={(value) => updateEntityTaxResidency(residency.id, 'noTinReason', value)}
                            >
                              <SelectTrigger className="h-12">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="notIssued">Country does not issue TIN</SelectItem>
                                <SelectItem value="notRequired">Country does not require collection of TIN</SelectItem>
                                <SelectItem value="other">Other</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          {residency.noTinReason === 'other' && (
                            <div>
                              <Label className="form-label">Explanation</Label>
                              <Input
                                value={residency.noTinExplanation}
                                onChange={(e) => updateEntityTaxResidency(residency.id, 'noTinExplanation', e.target.value)}
                                placeholder="Please explain"
                                className="h-12"
                              />
                            </div>
                          )}
                        </>
                      )}
                    </div>
                  </motion.div>
                ))}

                <Button
                  type="button"
                  variant="outline"
                  onClick={addEntityTaxResidency}
                  className="w-full h-12 border-dashed"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Tax Residency
                </Button>
              </div>
            </div>

            {/* Controlling Persons (for passive entities) */}
            {data.taxDeclarationEntity.nonFIType === 'passiveInvestment' && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                className="space-y-4"
              >
                <h4 className="font-semibold text-foreground">Controlling Persons</h4>
                <p className="text-sm text-muted-foreground">
                  For passive entities, please provide details of persons who exercise control.
                </p>

                <div className="space-y-4">
                  {data.taxDeclarationEntity.controllingPersons.map((person, index) => (
                    <motion.div
                      key={person.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="p-4 rounded-xl border border-border space-y-4"
                    >
                      <div className="flex items-center justify-between">
                        <h5 className="font-medium text-foreground">Controlling Person {index + 1}</h5>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => removeControllingPerson(person.id)}
                          className="text-destructive hover:text-destructive"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>

                      <div className="grid gap-4 md:grid-cols-2">
                        <div>
                          <Label className="form-label">Full Name *</Label>
                          <Input
                            value={person.fullName}
                            onChange={(e) => updateControllingPerson(person.id, 'fullName', e.target.value)}
                            placeholder="As per NRIC/Passport"
                            className="h-12"
                          />
                        </div>
                        <div>
                          <Label className="form-label">NRIC/Passport *</Label>
                          <Input
                            value={person.nricPassport}
                            onChange={(e) => updateControllingPerson(person.id, 'nricPassport', e.target.value)}
                            placeholder="e.g., S1234567A"
                            className="h-12"
                          />
                        </div>
                        <div>
                          <Label className="form-label">Date of Birth *</Label>
                          <Input
                            type="date"
                            value={person.dateOfBirth}
                            onChange={(e) => updateControllingPerson(person.id, 'dateOfBirth', e.target.value)}
                            className="h-12"
                          />
                        </div>
                        <div>
                          <Label className="form-label">Country of Birth *</Label>
                          <Select
                            value={person.countryOfBirth}
                            onValueChange={(value) => updateControllingPerson(person.id, 'countryOfBirth', value)}
                          >
                            <SelectTrigger className="h-12">
                              <SelectValue placeholder="Select country" />
                            </SelectTrigger>
                            <SelectContent>
                              {countries.map((country) => (
                                <SelectItem key={country} value={country}>
                                  {country}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="md:col-span-2">
                          <Label className="form-label">Residential Address *</Label>
                          <Textarea
                            value={person.residentialAddress}
                            onChange={(e) => updateControllingPerson(person.id, 'residentialAddress', e.target.value)}
                            placeholder="Full address"
                            className="min-h-[60px]"
                          />
                        </div>
                      </div>
                    </motion.div>
                  ))}

                  <Button
                    type="button"
                    variant="outline"
                    onClick={addControllingPerson}
                    className="w-full h-12 border-dashed"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Controlling Person
                  </Button>
                </div>
              </motion.div>
            )}
          </TabsContent>

          {/* Individual Tax Declaration (Sole Proprietorship) */}
          <TabsContent value="individual" className="space-y-6 mt-6">
            <div className="p-4 rounded-xl bg-muted/50 border border-border">
              <p className="text-sm text-muted-foreground">
                For sole proprietorship owned by an individual. Please provide the owner's tax information.
              </p>
            </div>

            {/* Owner Details */}
            <div className="space-y-4">
              <h4 className="font-semibold text-foreground">Owner Details</h4>
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <Label className="form-label">Full Name *</Label>
                  <Input
                    value={data.taxDeclarationIndividual.fullName}
                    onChange={(e) => updateIndividualTax('fullName', e.target.value)}
                    placeholder="As per NRIC/Passport"
                    className="h-12"
                  />
                </div>
                <div>
                  <Label className="form-label">NRIC/Passport Number *</Label>
                  <Input
                    value={data.taxDeclarationIndividual.nricPassport}
                    onChange={(e) => updateIndividualTax('nricPassport', e.target.value)}
                    placeholder="e.g., S1234567A"
                    className="h-12"
                  />
                </div>
                <div>
                  <Label className="form-label">Country of Birth *</Label>
                  <Select
                    value={data.taxDeclarationIndividual.countryOfBirth}
                    onValueChange={(value) => updateIndividualTax('countryOfBirth', value)}
                  >
                    <SelectTrigger className="h-12">
                      <SelectValue placeholder="Select country" />
                    </SelectTrigger>
                    <SelectContent>
                      {countries.map((country) => (
                        <SelectItem key={country} value={country}>
                          {country}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="form-label">Date of Birth *</Label>
                  <Input
                    type="date"
                    value={data.taxDeclarationIndividual.dateOfBirth}
                    onChange={(e) => updateIndividualTax('dateOfBirth', e.target.value)}
                    className="h-12"
                  />
                </div>
                <div className="md:col-span-2">
                  <Label className="form-label">Residential Address *</Label>
                  <Textarea
                    value={data.taxDeclarationIndividual.residentialAddress}
                    onChange={(e) => updateIndividualTax('residentialAddress', e.target.value)}
                    placeholder="Full address"
                    className="min-h-[80px]"
                  />
                </div>
                <div>
                  <Label className="form-label">Country *</Label>
                  <Select
                    value={data.taxDeclarationIndividual.country}
                    onValueChange={(value) => updateIndividualTax('country', value)}
                  >
                    <SelectTrigger className="h-12">
                      <SelectValue placeholder="Select country" />
                    </SelectTrigger>
                    <SelectContent>
                      {countries.map((country) => (
                        <SelectItem key={country} value={country}>
                          {country}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="form-label">Postal Code *</Label>
                  <Input
                    value={data.taxDeclarationIndividual.postalCode}
                    onChange={(e) => updateIndividualTax('postalCode', e.target.value)}
                    placeholder="e.g., 123456"
                    className="h-12"
                  />
                </div>
              </div>
            </div>

            {/* US Documents */}
            {data.taxDeclarationIndividual.countryOfBirth === 'United States' && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                className="space-y-4"
              >
                <div className="p-4 rounded-xl bg-warning/10 border border-warning/20">
                  <p className="text-sm text-warning-foreground">
                    If you are no longer a U.S. tax resident, please provide the following documents:
                  </p>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-4 rounded-xl border border-border">
                    <div>
                      <p className="font-medium text-foreground">Certificate of Loss of Nationality</p>
                      <p className="text-sm text-muted-foreground">Form DS-4083</p>
                    </div>
                    <Switch
                      checked={data.taxDeclarationIndividual.hasUSCertificateLossNationality}
                      onCheckedChange={(checked) => updateIndividualTax('hasUSCertificateLossNationality', checked)}
                    />
                  </div>
                  <div className="flex items-center justify-between p-4 rounded-xl border border-border">
                    <div>
                      <p className="font-medium text-foreground">Form I-407</p>
                      <p className="text-sm text-muted-foreground">Abandonment of Lawful Permanent Resident Status</p>
                    </div>
                    <Switch
                      checked={data.taxDeclarationIndividual.hasFormI407}
                      onCheckedChange={(checked) => updateIndividualTax('hasFormI407', checked)}
                    />
                  </div>
                </div>
              </motion.div>
            )}

            {/* Tax Residency */}
            <div className="space-y-4">
              <h4 className="font-semibold text-foreground">Tax Residency</h4>
              
              <div className="space-y-3">
                <div className="flex items-center justify-between p-4 rounded-xl border border-border">
                  <div>
                    <p className="font-medium text-foreground">Singapore Tax Resident</p>
                    <p className="text-sm text-muted-foreground">TIN is your NRIC/FIN</p>
                  </div>
                  <Switch
                    checked={data.taxDeclarationIndividual.isSingaporeTaxResident}
                    onCheckedChange={(checked) => updateIndividualTax('isSingaporeTaxResident', checked)}
                  />
                </div>

                {data.taxDeclarationIndividual.isSingaporeTaxResident && (
                  <div>
                    <Label className="form-label">Singapore TIN (if different from NRIC/FIN)</Label>
                    <Input
                      value={data.taxDeclarationIndividual.singaporeTin}
                      onChange={(e) => updateIndividualTax('singaporeTin', e.target.value)}
                      placeholder="Leave blank if same as NRIC/FIN"
                      className="h-12"
                    />
                  </div>
                )}

                <div className="flex items-center justify-between p-4 rounded-xl border border-border">
                  <div>
                    <p className="font-medium text-foreground">United States Tax Resident</p>
                    <p className="text-sm text-muted-foreground">Please also complete IRS W-9 form</p>
                  </div>
                  <Switch
                    checked={data.taxDeclarationIndividual.isUSTaxResident}
                    onCheckedChange={(checked) => updateIndividualTax('isUSTaxResident', checked)}
                  />
                </div>

                {data.taxDeclarationIndividual.isUSTaxResident && (
                  <div>
                    <Label className="form-label">US TIN *</Label>
                    <Input
                      value={data.taxDeclarationIndividual.usTin}
                      onChange={(e) => updateIndividualTax('usTin', e.target.value)}
                      placeholder="SSN or ITIN"
                      className="h-12"
                    />
                  </div>
                )}
              </div>

              {/* Other tax residencies */}
              <div className="space-y-4 mt-4">
                <p className="text-sm text-muted-foreground">Other countries of tax residence:</p>
                {data.taxDeclarationIndividual.taxResidencies.map((residency, index) => (
                  <motion.div
                    key={residency.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="p-4 rounded-xl border border-border space-y-4"
                  >
                    <div className="flex items-center justify-between">
                      <h5 className="font-medium text-foreground">Tax Residency {index + 1}</h5>
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => removeIndividualTaxResidency(residency.id)}
                        className="text-destructive hover:text-destructive"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>

                    <div className="grid gap-4 md:grid-cols-2">
                      <div>
                        <Label className="form-label">Country *</Label>
                        <Select
                          value={residency.country}
                          onValueChange={(value) => updateIndividualTaxResidency(residency.id, 'country', value)}
                        >
                          <SelectTrigger className="h-12">
                            <SelectValue placeholder="Select country" />
                          </SelectTrigger>
                          <SelectContent>
                            {countries.map((country) => (
                              <SelectItem key={country} value={country}>
                                {country}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label className="form-label">TIN</Label>
                        <Input
                          value={residency.tin}
                          onChange={(e) => updateIndividualTaxResidency(residency.id, 'tin', e.target.value)}
                          placeholder="Taxpayer Identification Number"
                          className="h-12"
                        />
                      </div>
                    </div>
                  </motion.div>
                ))}

                <Button
                  type="button"
                  variant="outline"
                  onClick={addIndividualTaxResidency}
                  className="w-full h-12 border-dashed"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Tax Residency
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </motion.div>
    </motion.div>
  );
}
