import { FormData } from '@/types/form';

// Create proper SVG signature as data URL - these will render correctly in both view and PDF
const createSignatureSVG = (paths: string, color: string = '#1a365d') => {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="300" height="100" viewBox="0 0 300 100">
    <path d="${paths}" stroke="${color}" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>`;
  return `data:image/svg+xml;base64,${btoa(svg)}`;
};

// Signature 1 - Flowing cursive style
const dummySignature1 = createSignatureSVG(
  'M20,60 Q40,20 60,50 T100,40 Q120,60 140,35 T180,50 Q200,30 220,55 L240,45 Q260,60 280,40'
);

// Signature 2 - More angular style  
const dummySignature2 = createSignatureSVG(
  'M25,55 L50,30 L75,60 L100,25 L130,55 Q150,40 170,55 L200,30 L230,60 Q250,45 275,50',
  '#2d3748'
);

// Signature 3 - Loopy style
const dummySignature3 = createSignatureSVG(
  'M20,50 Q35,20 50,50 Q65,80 80,50 Q95,20 110,50 Q125,80 140,50 L160,50 Q180,30 200,50 Q220,70 240,50 L260,45 Q275,55 280,50',
  '#1e40af'
);

export interface DraftApplication extends FormData {
  id: string;
  status: 'draft' | 'submitted' | 'approved' | 'rejected';
  createdAt: string;
  updatedAt: string;
}

export const draftApplications: DraftApplication[] = [
  {
    id: 'cpf-board-2024',
    status: 'submitted',
    createdAt: '2024-12-15T10:30:00Z',
    updatedAt: '2025-01-08T14:20:00Z',
    businessDetails: {
      registeredName: 'Central Provident Fund Board',
      registrationNumber: 'T08GB0001A',
      officeNumber: '+65 6225 9922',
      faxNumber: '+65 6225 9123',
      natureOfBusiness: 'Government Agency - Social Security & Pension Fund Administration',
      gstRegistered: false,
      countryOfDomicile: 'Singapore',
      businessType: 'Statutory Board',
    },
    primaryContact: {
      nricPassport: 'S7512345A',
      fullName: 'Tan Wei Ming',
      email: 'weiming.tan@cpf.gov.sg',
      mobileNumber: '+65 9123 4567',
      officeNumber: '+65 6225 9922',
    },
    secondaryContact: {
      nricPassport: 'S8023456B',
      fullName: 'Lim Mei Ling',
      email: 'meiling.lim@cpf.gov.sg',
      mobileNumber: '+65 9234 5678',
      officeNumber: '+65 6225 9923',
    },
    accountType: {
      sgdAccounts: ['Business Current Account', 'Business Statement Savings Account'],
      foreignCurrencyAccounts: ['Multi-Currency Account'],
      currencies: ['USD', 'EUR'],
    },
    accountParticulars: {
      sourceOfCapital: ['Government Funding', 'Investment Returns'],
      accountName: 'Central Provident Fund Board',
      mailingAddress: '79 Robinson Road, CPF Building, Singapore 068897',
      payNowSignUp: true,
      sgqrSignUp: false,
      sgqrOption: 'none',
      outlets: [],
      outletName1: '',
      outletName2: '',
    },
    beneficialOwners: [
      {
        id: 'cpf-1',
        fullName: 'Tan Wei Ming',
        nricPassport: 'S7512345A',
        designation: 'Chief Executive Officer',
        isBeneficialOwner: true,
        isAuthorisedSignatory: true,
        mobileNumber: '+65 9123 4567',
        officeNumber: '+65 6225 9922',
        email: 'weiming.tan@cpf.gov.sg',
        grouping: 'A',
        signature: '',
      },
      {
        id: 'cpf-2',
        fullName: 'Dr. Ng Boon Yew',
        nricPassport: 'S6834567C',
        designation: 'Chairman',
        isBeneficialOwner: true,
        isAuthorisedSignatory: true,
        mobileNumber: '+65 9345 6789',
        officeNumber: '+65 6225 9920',
        email: 'boonyew.ng@cpf.gov.sg',
        grouping: 'A',
        signature: '',
      },
      {
        id: 'cpf-3',
        fullName: 'Wong Su Ling',
        nricPassport: 'S7945678D',
        designation: 'Chief Financial Officer',
        isBeneficialOwner: false,
        isAuthorisedSignatory: true,
        mobileNumber: '+65 9456 7890',
        officeNumber: '+65 6225 9925',
        email: 'suling.wong@cpf.gov.sg',
        grouping: 'B',
        signature: dummySignature3,
      },
    ],
    signingCondition: {
      type: 'anyTwo',
      details: 'Any two authorised signatories to sign jointly',
      applyToAllAccounts: true,
    },
    agreeToTerms: true,
    boardResolution: {
      companyName: 'Central Provident Fund Board',
      meetingDate: '2024-12-01',
      resolutionPassed: true,
      openCloseAccounts: true,
      applyBankingServices: true,
      appointAuthorisedUsers: true,
      appointAuthorisedSignatories: true,
      borrowingAndSecurity: false,
      corporateCreditCard: false,
      electronicSigning: true,
      authorisedPersons: [
        { id: 'cpf-auth-1', fullName: 'Tan Wei Ming', nricPassport: 'S7512345A', designation: 'CEO', signature: dummySignature1 },
        { id: 'cpf-auth-2', fullName: 'Dr. Ng Boon Yew', nricPassport: 'S6834567C', designation: 'Chairman', signature: dummySignature2 },
      ],
      signingMandate: 'Any two authorised signatories',
      signingLimits: 'No limit',
      directorSignatures: [
        { id: 'cpf-dir-1', name: 'Tan Wei Ming', signature: dummySignature1, date: '2024-12-01' },
        { id: 'cpf-dir-2', name: 'Dr. Ng Boon Yew', signature: dummySignature2, date: '2024-12-01' },
      ],
      companySecretarySignature: dummySignature3,
      companySecretaryName: 'Lee Kah Meng',
      certificationDate: '2024-12-01',
    },
    taxDeclarationEntity: {
      registeredName: 'Central Provident Fund Board',
      registrationNumber: 'T08GB0001A',
      registeredAddress: '79 Robinson Road, CPF Building, Singapore 068897',
      country: 'Singapore',
      postalCode: '068897',
      entityType: 'notFinancialInstitution',
      nonFIType: 'publicSector',
      fatcaStatus: 'Exempt Beneficial Owner',
      crsStatus: 'Government Entity',
      securitiesMarketName: '',
      entityNameOnMarket: '',
      fiType: 'depository',
      taxResidencies: [{ id: 'cpf-tax-1', country: 'Singapore', tin: 'T08GB0001A', noTinReason: 'notIssued', noTinExplanation: '' }],
      controllingPersons: [],
      declarationDate: '2024-12-15',
      declarationSignature: '',
    },
    taxDeclarationIndividual: {
      fullName: '',
      nricPassport: '',
      countryOfBirth: '',
      dateOfBirth: '',
      residentialAddress: '',
      country: 'Singapore',
      postalCode: '',
      hasUSCertificateLossNationality: false,
      hasFormI407: false,
      isSingaporeTaxResident: true,
      singaporeTin: '',
      isUSTaxResident: false,
      usTin: '',
      taxResidencies: [],
      residentialAddressIndicator: '',
      mailingAddressIndicator: '',
      registeredAddressIndicator: '',
      domicileIndicator: '',
      declarationDate: '',
      declarationSignature: '',
    },
    businessBankingServices: {
      registeredName: 'Central Provident Fund Board',
      registrationNumber: 'T08GB0001A',
      applyForVelocity: true,
      debitAccountForToken: '',
      contactPersonName: 'Tan Wei Ming',
      contactPersonOfficeNumber: '+65 6225 9922',
      contactPersonMobile: '+65 9123 4567',
      contactPersonEmail: 'weiming.tan@cpf.gov.sg',
      organisationId: 'CPFBOARD',
      linkedAccounts: [],
      linkAllTradeAccounts: false,
      eStatementEnabled: true,
      servicePackage: 'classic',
      velocityUsers: [
        {
          id: 'user-1',
          fullName: 'Tan Wei Ming',
          nricPassport: 'S7012345A',
          idType: 'nric',
          idIssueCountry: 'Singapore',
          userId: 'CPFWM01',
          mobileNumber: '+65 9123 4567',
          email: 'weiming.tan@cpf.gov.sg',
          canViewStatement: true,
          canCreateTransactions: true,
          canApproveTransactions: true,
          canBookFX: false,
          role: 'makerAuthoriser',
          customRoleName: '',
          transactionTypes: {
            localTransfers: true,
            payNow: true,
            giro: true,
            telegraphicTransfers: false,
            billPayments: true,
            bulkPayments: true,
            payrollPayments: true,
            tradeServices: false,
            fxConversions: false,
          },
        },
      ],
      twoFactorMethod: 'digital',
      classicSigningMode: 'dual',
      approvalMatrix: {
        approvalType: 'dual',
        singleApproverThreshold: '5000',
        dualApproverThreshold: '50000',
        matrixRules: [
          {
            id: 'rule-1',
            transactionType: 'All Transactions',
            amountFrom: '0',
            amountTo: '5000',
            requiredApprovers: 1,
            approverGrouping: 'Any Authoriser',
          },
          {
            id: 'rule-2',
            transactionType: 'All Transactions',
            amountFrom: '5001',
            amountTo: '50000',
            requiredApprovers: 2,
            approverGrouping: 'Any Two Authorisers',
          },
        ],
      },
      customRoles: [
        {
          id: 'role-1',
          roleName: 'Finance Manager',
          description: 'Full access to financial transactions with approval authority',
          capabilities: {
            viewStatements: true,
            viewTransactionHistory: true,
            createLocalTransfers: true,
            createInternationalTransfers: false,
            createPayNow: true,
            createGiro: true,
            createBillPayments: true,
            createBulkPayments: true,
            createPayroll: true,
            approveTransactions: true,
            approveWithLimit: true,
            approvalLimit: '50000',
            manageUsers: false,
            manageAccounts: false,
            bookFX: false,
            downloadReports: true,
          },
        },
      ],
    },
    businessDebitCard: {
      applyForDebitCard: false,
      registeredName: 'Central Provident Fund Board',
      registrationNumber: 'T08GB0001A',
      linkedAccountNumber: '',
      isNewAccount: false,
      cardholders: [],
    },
    giroApplication: {
      applyForGIRO: false,
      registeredName: 'Central Provident Fund Board',
      registrationNumber: 'T08GB0001A',
      debitAccountNumber: '',
      billingOrganizations: [],
      signatures: [],
    },
    eAlerts: {
      applyForEAlerts: true,
      linkedAccountNumber: '',
      alertUsers: [],
    },
    agreement: {
      agreeToTerms: true,
      agreeToDataProtection: true,
      agreeToFATCA: true,
      agreeToCRS: true,
      signatureDate: '2024-12-15',
      agreementSignatures: [
        { id: 'cpf-sig-1', name: 'Tan Wei Ming', signature: dummySignature1, date: '2024-12-15' },
        { id: 'cpf-sig-2', name: 'Dr. Ng Boon Yew', signature: dummySignature2, date: '2024-12-15' },
        { id: 'cpf-sig-3', name: 'Wong Su Ling', signature: dummySignature3, date: '2024-12-15' },
      ],
    },
  },
  {
    id: 'ibm-singapore-2024',
    status: 'draft',
    createdAt: '2025-01-05T09:15:00Z',
    updatedAt: '2025-01-10T16:45:00Z',
    businessDetails: {
      registeredName: 'IBM Singapore Pte Ltd',
      registrationNumber: '196500232R',
      officeNumber: '+65 6418 8888',
      faxNumber: '+65 6418 8899',
      natureOfBusiness: 'Information Technology - Computer Hardware, Software & Services',
      gstRegistered: true,
      countryOfDomicile: 'Singapore',
      businessType: 'Private Limited Company',
    },
    primaryContact: {
      nricPassport: 'S7823456E',
      fullName: 'David Chen Hao',
      email: 'david.chen@ibm.com',
      mobileNumber: '+65 9567 8901',
      officeNumber: '+65 6418 8801',
    },
    secondaryContact: {
      nricPassport: 'S8134567F',
      fullName: 'Sarah Koh Wei Lin',
      email: 'sarah.koh@ibm.com',
      mobileNumber: '+65 9678 9012',
      officeNumber: '+65 6418 8802',
    },
    accountType: {
      sgdAccounts: ['Business Current Account', 'Business Premium Rate Savings Account'],
      foreignCurrencyAccounts: ['Multi-Currency Account', 'Foreign Currency Fixed Deposit'],
      currencies: ['USD', 'EUR', 'GBP', 'JPY', 'AUD'],
    },
    accountParticulars: {
      sourceOfCapital: ['Business Revenue', 'Parent Company Funding', 'Trade Financing'],
      accountName: 'IBM Singapore Pte Ltd',
      mailingAddress: '9 Changi Business Park Central 1, IBM Singapore, Singapore 486048',
      payNowSignUp: true,
      sgqrSignUp: true,
      sgqrOption: 'create',
      outlets: [
        { outletName: 'IBM Singapore HQ', sgqrId: '', postalCode: '486048', levelUnit: '#01-01', terminalId: '', referenceNo: '' },
        { outletName: 'IBM Changi Office', sgqrId: '', postalCode: '486048', levelUnit: '#02-01', terminalId: '', referenceNo: '' },
      ],
      outletName1: 'IBM Singapore HQ',
      outletName2: 'IBM Changi Office',
    },
    beneficialOwners: [
      {
        id: 'ibm-1',
        fullName: 'David Chen Hao',
        nricPassport: 'S7823456E',
        designation: 'Managing Director, Singapore',
        isBeneficialOwner: false,
        isAuthorisedSignatory: true,
        mobileNumber: '+65 9567 8901',
        officeNumber: '+65 6418 8801',
        email: 'david.chen@ibm.com',
        grouping: 'A',
        signature: '',
      },
      {
        id: 'ibm-2',
        fullName: 'Jennifer Lim Siew Hwa',
        nricPassport: 'S7634567G',
        designation: 'Chief Financial Officer, ASEAN',
        isBeneficialOwner: false,
        isAuthorisedSignatory: true,
        mobileNumber: '+65 9789 0123',
        officeNumber: '+65 6418 8802',
        email: 'jennifer.lim@ibm.com',
        grouping: 'B',
        signature: '',
      },
      {
        id: 'ibm-3',
        fullName: 'Michael Tan Beng Kiat',
        nricPassport: 'S7445678H',
        designation: 'Director, Treasury',
        isBeneficialOwner: false,
        isAuthorisedSignatory: true,
        mobileNumber: '+65 9890 1234',
        officeNumber: '+65 6418 8803',
        email: 'michael.tan@ibm.com',
        grouping: 'B',
        signature: dummySignature3,
      },
    ],
    signingCondition: {
      type: 'grouping',
      details: 'Group A: Managing Director must sign with any one from Group B (CFO or Director, Treasury)',
      applyToAllAccounts: true,
    },
    agreeToTerms: false,
    boardResolution: {
      companyName: 'IBM Singapore Pte Ltd',
      meetingDate: '2025-01-03',
      resolutionPassed: true,
      openCloseAccounts: true,
      applyBankingServices: true,
      appointAuthorisedUsers: true,
      appointAuthorisedSignatories: true,
      borrowingAndSecurity: true,
      corporateCreditCard: true,
      electronicSigning: true,
      authorisedPersons: [
        { id: 'ibm-auth-1', fullName: 'David Chen Hao', nricPassport: 'S7823456E', designation: 'Managing Director', signature: dummySignature1 },
        { id: 'ibm-auth-2', fullName: 'Jennifer Lim Siew Hwa', nricPassport: 'S7634567G', designation: 'CFO', signature: dummySignature2 },
        { id: 'ibm-auth-3', fullName: 'Michael Tan Beng Kiat', nricPassport: 'S7445678H', designation: 'Director, Treasury', signature: dummySignature3 },
      ],
      signingMandate: 'Group A with any one from Group B',
      signingLimits: 'Unlimited',
      directorSignatures: [
        { id: 'ibm-dir-1', name: 'David Chen Hao', signature: dummySignature1, date: '2025-01-03' },
        { id: 'ibm-dir-2', name: 'Jennifer Lim Siew Hwa', signature: dummySignature2, date: '2025-01-03' },
      ],
      companySecretarySignature: dummySignature3,
      companySecretaryName: 'Amanda Teo',
      certificationDate: '2025-01-03',
    },
    taxDeclarationEntity: {
      registeredName: 'IBM Singapore Pte Ltd',
      registrationNumber: '196500232R',
      registeredAddress: '9 Changi Business Park Central 1, Singapore 486048',
      country: 'Singapore',
      postalCode: '486048',
      entityType: 'notFinancialInstitution',
      nonFIType: 'activeBusiness',
      fatcaStatus: '',
      crsStatus: '',
      securitiesMarketName: '',
      entityNameOnMarket: '',
      fiType: 'depository',
      taxResidencies: [{ id: 'ibm-tax-1', country: 'Singapore', tin: '196500232R', noTinReason: 'notIssued', noTinExplanation: '' }],
      controllingPersons: [],
      declarationDate: '',
      declarationSignature: '',
    },
    taxDeclarationIndividual: {
      fullName: '',
      nricPassport: '',
      countryOfBirth: '',
      dateOfBirth: '',
      residentialAddress: '',
      country: 'Singapore',
      postalCode: '',
      hasUSCertificateLossNationality: false,
      hasFormI407: false,
      isSingaporeTaxResident: true,
      singaporeTin: '',
      isUSTaxResident: false,
      usTin: '',
      taxResidencies: [],
      residentialAddressIndicator: '',
      mailingAddressIndicator: '',
      registeredAddressIndicator: '',
      domicileIndicator: '',
      declarationDate: '',
      declarationSignature: '',
    },
    businessBankingServices: {
      registeredName: 'IBM Singapore Pte Ltd',
      registrationNumber: '196500232R',
      applyForVelocity: true,
      debitAccountForToken: '',
      contactPersonName: 'David Chen Hao',
      contactPersonOfficeNumber: '+65 6418 8801',
      contactPersonMobile: '+65 9567 8901',
      contactPersonEmail: 'david.chen@ibm.com',
      organisationId: 'IBMSG',
      linkedAccounts: [],
      linkAllTradeAccounts: true,
      eStatementEnabled: true,
      servicePackage: 'classic',
      velocityUsers: [
        {
          id: 'user-ibm-1',
          fullName: 'David Chen Hao',
          nricPassport: 'S8234567B',
          idType: 'nric',
          idIssueCountry: 'Singapore',
          userId: 'IBMDCH01',
          mobileNumber: '+65 9567 8901',
          email: 'david.chen@ibm.com',
          canViewStatement: true,
          canCreateTransactions: true,
          canApproveTransactions: true,
          canBookFX: true,
          role: 'authoriser',
          customRoleName: '',
          transactionTypes: {
            localTransfers: true,
            payNow: true,
            giro: true,
            telegraphicTransfers: true,
            billPayments: true,
            bulkPayments: true,
            payrollPayments: true,
            tradeServices: true,
            fxConversions: true,
          },
        },
        {
          id: 'user-ibm-2',
          fullName: 'Sarah Lim',
          nricPassport: 'S9012345C',
          idType: 'nric',
          idIssueCountry: 'Singapore',
          userId: 'IBMSL01',
          mobileNumber: '+65 9876 5432',
          email: 'sarah.lim@ibm.com',
          canViewStatement: true,
          canCreateTransactions: true,
          canApproveTransactions: false,
          canBookFX: false,
          role: 'maker',
          customRoleName: '',
          transactionTypes: {
            localTransfers: true,
            payNow: true,
            giro: true,
            telegraphicTransfers: false,
            billPayments: true,
            bulkPayments: false,
            payrollPayments: false,
            tradeServices: false,
            fxConversions: false,
          },
        },
      ],
      twoFactorMethod: 'digital',
      classicSigningMode: 'dual',
      approvalMatrix: {
        approvalType: 'matrix',
        singleApproverThreshold: '10000',
        dualApproverThreshold: '100000',
        matrixRules: [
          {
            id: 'rule-ibm-1',
            transactionType: 'Local Transfers',
            amountFrom: '0',
            amountTo: '10000',
            requiredApprovers: 1,
            approverGrouping: 'Any Authoriser',
          },
          {
            id: 'rule-ibm-2',
            transactionType: 'Local Transfers',
            amountFrom: '10001',
            amountTo: '100000',
            requiredApprovers: 2,
            approverGrouping: 'Any Two Authorisers',
          },
          {
            id: 'rule-ibm-3',
            transactionType: 'International Transfers',
            amountFrom: '0',
            amountTo: '50000',
            requiredApprovers: 2,
            approverGrouping: 'CFO + Any Authoriser',
          },
        ],
      },
      customRoles: [
        {
          id: 'role-ibm-1',
          roleName: 'Treasury Manager',
          description: 'Full treasury operations with FX and international transfers',
          capabilities: {
            viewStatements: true,
            viewTransactionHistory: true,
            createLocalTransfers: true,
            createInternationalTransfers: true,
            createPayNow: true,
            createGiro: true,
            createBillPayments: true,
            createBulkPayments: true,
            createPayroll: false,
            approveTransactions: true,
            approveWithLimit: true,
            approvalLimit: '100000',
            manageUsers: false,
            manageAccounts: true,
            bookFX: true,
            downloadReports: true,
          },
        },
        {
          id: 'role-ibm-2',
          roleName: 'Accounts Payable',
          description: 'Create payments for vendor invoices',
          capabilities: {
            viewStatements: true,
            viewTransactionHistory: true,
            createLocalTransfers: true,
            createInternationalTransfers: false,
            createPayNow: true,
            createGiro: true,
            createBillPayments: true,
            createBulkPayments: true,
            createPayroll: false,
            approveTransactions: false,
            approveWithLimit: false,
            approvalLimit: '',
            manageUsers: false,
            manageAccounts: false,
            bookFX: false,
            downloadReports: true,
          },
        },
      ],
    },
    businessDebitCard: {
      applyForDebitCard: true,
      registeredName: 'IBM Singapore Pte Ltd',
      registrationNumber: '196500232R',
      linkedAccountNumber: '',
      isNewAccount: true,
      cardholders: [],
    },
    giroApplication: {
      applyForGIRO: true,
      registeredName: 'IBM Singapore Pte Ltd',
      registrationNumber: '196500232R',
      debitAccountNumber: '',
      billingOrganizations: [],
      signatures: [],
    },
    eAlerts: {
      applyForEAlerts: true,
      linkedAccountNumber: '',
      alertUsers: [],
    },
    agreement: {
      agreeToTerms: false,
      agreeToDataProtection: false,
      agreeToFATCA: false,
      agreeToCRS: false,
      signatureDate: '2025-01-05',
      agreementSignatures: [
        { id: 'ibm-sig-1', name: 'David Chen Hao', signature: dummySignature1, date: '2025-01-05' },
        { id: 'ibm-sig-2', name: 'Jennifer Lim Siew Hwa', signature: dummySignature2, date: '2025-01-05' },
        { id: 'ibm-sig-3', name: 'Michael Tan Beng Kiat', signature: dummySignature3, date: '2025-01-05' },
      ],
    },
  },
];

const USER_DRAFTS_KEY = 'user_drafts';

// Helper to get user drafts from localStorage
function getUserDrafts(): DraftApplication[] {
  try {
    const stored = localStorage.getItem(USER_DRAFTS_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch {
    return [];
  }
}

// Get all drafts (predefined + user-created)
export function getAllDrafts(): DraftApplication[] {
  const userDrafts = getUserDrafts();
  return [...draftApplications, ...userDrafts];
}

export function getDraftById(id: string): DraftApplication | undefined {
  // Check predefined first
  const predefined = draftApplications.find((draft) => draft.id === id);
  if (predefined) return predefined;
  
  // Then check user drafts
  const userDrafts = getUserDrafts();
  return userDrafts.find((draft) => draft.id === id);
}

export function searchDrafts(query: string): DraftApplication[] {
  const allDrafts = getAllDrafts();
  const lowerQuery = query.toLowerCase().trim();
  if (!lowerQuery) return allDrafts;
  
  return allDrafts.filter((draft) => {
    const searchableFields = [
      draft.businessDetails.registeredName,
      draft.businessDetails.registrationNumber,
      draft.businessDetails.natureOfBusiness,
      draft.businessDetails.businessType,
      draft.primaryContact.fullName,
      draft.primaryContact.email,
      draft.accountParticulars.mailingAddress,
      draft.id,
      draft.status,
    ];
    
    return searchableFields.some((field) => 
      field?.toLowerCase().includes(lowerQuery)
    );
  });
}
