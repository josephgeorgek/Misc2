import { useState, useEffect, useCallback } from 'react';
import { DraftApplication, draftApplications } from '@/data/drafts';
import { AgreementSignature } from '@/types/form';
import { applicationApi, signatureApi, checkBackendHealth } from '@/api/applicationApi';

const STORAGE_KEY_PREFIX = 'app_signatures_';
const USER_DRAFTS_KEY = 'user_drafts';

interface StoredSignatures {
  agreementSignatures: AgreementSignature[];
  updatedAt: string;
}

// Helper to get user drafts from localStorage
function getUserDrafts(): DraftApplication[] {
  try {
    const stored = localStorage.getItem(USER_DRAFTS_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch {
    return [];
  }
}

// Helper to save user drafts to localStorage
function saveUserDrafts(drafts: DraftApplication[]) {
  localStorage.setItem(USER_DRAFTS_KEY, JSON.stringify(drafts));
}

export function useApplicationStorage(applicationId: string | undefined) {
  const [application, setApplication] = useState<DraftApplication | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [useBackend, setUseBackend] = useState(false);

  // Load application data on mount
  useEffect(() => {
    async function loadApplication() {
      if (!applicationId) {
        setApplication(null);
        setIsLoading(false);
        return;
      }

      // Check if backend is available
      const backendAvailable = await checkBackendHealth();
      setUseBackend(backendAvailable);

      if (backendAvailable) {
        // Try to load from backend
        try {
          const backendApp = await applicationApi.getById(applicationId);
          if (backendApp) {
            // Also fetch signatures
            const signatures = await signatureApi.getByApplicationId(applicationId);
            if (signatures.length > 0) {
              backendApp.agreement = {
                ...backendApp.agreement,
                agreementSignatures: signatures,
              };
            }
            setApplication(backendApp);
            setIsLoading(false);
            return;
          }
        } catch (error) {
          console.log('[Storage] Backend fetch failed, falling back to localStorage');
        }
      }

      // Fallback: Load from localStorage/predefined drafts
      loadFromLocalStorage();
    }

    function loadFromLocalStorage() {
      // First check predefined drafts
      let baseApp = draftApplications.find(d => d.id === applicationId);
      
      // If not found in predefined, check user-created drafts in localStorage
      if (!baseApp) {
        const userDrafts = getUserDrafts();
        baseApp = userDrafts.find(d => d.id === applicationId);
      }

      if (!baseApp) {
        setApplication(null);
        setIsLoading(false);
        return;
      }

      // For predefined drafts, check for stored signatures in localStorage
      const storageKey = `${STORAGE_KEY_PREFIX}${applicationId}`;
      const stored = localStorage.getItem(storageKey);
      
      if (stored) {
        try {
          const parsed: StoredSignatures = JSON.parse(stored);
          // Merge stored signatures with base application
          setApplication({
            ...baseApp,
            agreement: {
              ...baseApp.agreement,
              agreementSignatures: parsed.agreementSignatures,
            },
            updatedAt: parsed.updatedAt,
          });
        } catch (e) {
          console.error('Failed to parse stored signatures:', e);
          setApplication(baseApp);
        }
      } else {
        setApplication(baseApp);
      }

      setIsLoading(false);
    }

    loadApplication();
  }, [applicationId]);

  // Save signatures
  const saveSignatures = useCallback(async (signatures: AgreementSignature[]) => {
    if (!applicationId || !application) return;

    const now = new Date().toISOString();

    // Try backend first if available
    if (useBackend) {
      try {
        await signatureApi.saveAll(applicationId, signatures);
        console.log('[Storage] Signatures saved to backend');
      } catch (error) {
        console.log('[Storage] Backend save failed, saving to localStorage');
      }
    }

    // Always save to localStorage as backup
    const isPredefined = draftApplications.some(d => d.id === applicationId);
    
    if (isPredefined) {
      // For predefined drafts, only save signatures separately
      const storageKey = `${STORAGE_KEY_PREFIX}${applicationId}`;
      const dataToStore: StoredSignatures = {
        agreementSignatures: signatures,
        updatedAt: now,
      };
      localStorage.setItem(storageKey, JSON.stringify(dataToStore));
    } else {
      // For user-created drafts, update the full draft in localStorage
      const userDrafts = getUserDrafts();
      const updatedDrafts = userDrafts.map(draft => 
        draft.id === applicationId 
          ? {
              ...draft,
              agreement: {
                ...draft.agreement,
                agreementSignatures: signatures,
              },
              updatedAt: now,
            }
          : draft
      );
      saveUserDrafts(updatedDrafts);
    }

    // Update local state
    setApplication(prev => prev ? {
      ...prev,
      agreement: {
        ...prev.agreement,
        agreementSignatures: signatures,
      },
      updatedAt: now,
    } : null);
  }, [applicationId, application, useBackend]);

  // Update the full application data
  const updateApplication = useCallback(async (updates: Partial<DraftApplication>) => {
    if (!applicationId || !application) return;

    const now = new Date().toISOString();

    // Try backend first if available
    if (useBackend) {
      try {
        const updated = await applicationApi.update(applicationId, updates);
        setApplication({ ...updated, updatedAt: now });
        console.log('[Storage] Application updated in backend');
        return;
      } catch (error) {
        console.log('[Storage] Backend update failed, updating localStorage');
      }
    }

    // Fallback: Update localStorage
    const isPredefined = draftApplications.some(d => d.id === applicationId);
    
    if (!isPredefined) {
      // Only allow updates for user-created drafts in localStorage
      const userDrafts = getUserDrafts();
      const updatedDrafts = userDrafts.map(draft => 
        draft.id === applicationId 
          ? { ...draft, ...updates, updatedAt: now }
          : draft
      );
      saveUserDrafts(updatedDrafts);
      
      // Update local state
      setApplication(prev => prev ? { ...prev, ...updates, updatedAt: now } : null);
    }
  }, [applicationId, application, useBackend]);

  // Clear stored signatures (reset to defaults)
  const clearStoredSignatures = useCallback(async () => {
    if (!applicationId) return;

    // Try backend first if available
    if (useBackend) {
      try {
        await signatureApi.deleteByApplicationId(applicationId);
        console.log('[Storage] Signatures cleared from backend');
      } catch (error) {
        console.log('[Storage] Backend delete failed');
      }
    }

    // Always clear localStorage
    const storageKey = `${STORAGE_KEY_PREFIX}${applicationId}`;
    localStorage.removeItem(storageKey);

    // Reset to base application (only works for predefined drafts)
    const baseApp = draftApplications.find(d => d.id === applicationId);
    if (baseApp) {
      setApplication(baseApp);
    }
  }, [applicationId, useBackend]);

  return {
    application,
    isLoading,
    saveSignatures,
    updateApplication,
    clearStoredSignatures,
    isUsingBackend: useBackend,
  };
}

// Hook to get all applications with backend fallback
export function useAllApplications() {
  const [applications, setApplications] = useState<DraftApplication[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [useBackend, setUseBackend] = useState(false);

  const loadApplications = useCallback(async () => {
    setIsLoading(true);
    
    const backendAvailable = await checkBackendHealth();
    setUseBackend(backendAvailable);

    if (backendAvailable) {
      try {
        const backendApps = await applicationApi.getAll();
        // Merge with predefined drafts
        const allApps = [...draftApplications, ...backendApps.filter(
          app => !draftApplications.some(d => d.id === app.id)
        )];
        setApplications(allApps);
        setIsLoading(false);
        return;
      } catch (error) {
        console.log('[Storage] Backend fetch all failed, using localStorage');
      }
    }

    // Fallback: Use localStorage + predefined
    const userDrafts = getUserDrafts();
    const allApps = [...draftApplications, ...userDrafts];
    setApplications(allApps);
    setIsLoading(false);
  }, []);

  useEffect(() => {
    loadApplications();
  }, [loadApplications]);

  const saveNewApplication = useCallback(async (draft: DraftApplication): Promise<DraftApplication> => {
    // Try backend first
    if (useBackend) {
      try {
        const saved = await applicationApi.create(draft);
        await loadApplications();
        return saved;
      } catch (error) {
        console.log('[Storage] Backend create failed, saving to localStorage');
      }
    }

    // Fallback: Save to localStorage
    const userDrafts = getUserDrafts();
    const newDrafts = [...userDrafts, draft];
    saveUserDrafts(newDrafts);
    await loadApplications();
    return draft;
  }, [useBackend, loadApplications]);

  return {
    applications,
    isLoading,
    isUsingBackend: useBackend,
    refresh: loadApplications,
    saveNewApplication,
  };
}
