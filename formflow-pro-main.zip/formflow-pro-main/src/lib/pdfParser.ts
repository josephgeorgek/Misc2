import { FormData, initialFormData } from '@/types/form';
import Tesseract from 'tesseract.js';
import * as pdfjsLib from 'pdfjs-dist';

// Use the correct ESM worker from jsdelivr CDN
pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdn.jsdelivr.net/npm/pdfjs-dist@${pdfjsLib.version}/build/pdf.worker.min.mjs`;

const getPdfJs = () => pdfjsLib;

interface ExtractedSignature {
  id: string;
  imageData: string; // base64 data URL
  pageNumber: number;
  bounds: { x: number; y: number; width: number; height: number };
  confidence: number;
}

interface ExtractedPDFData {
  rawText: string;
  pages: string[];
  formData: FormData;
  ocrUsed: boolean;
  extractedSignatures: ExtractedSignature[];
}

// Regular expressions for common form field patterns
const patterns = {
  // Business Details
  companyName: /(?:company\s*name|registered\s*name|business\s*name)[:\s]*([A-Za-z0-9\s\.\,\-\(\)]+(?:pte\.?\s*ltd\.?|private\s*limited|llp|ltd\.?))/i,
  uen: /(?:uen|registration\s*(?:no\.?|number)|company\s*(?:no\.?|number))[:\s]*([A-Z0-9]{8,10}[A-Z]?)/i,
  gstNumber: /(?:gst\s*(?:no\.?|number|registration))[:\s]*([A-Z0-9\-]+)/i,
  natureOfBusiness: /(?:nature\s*of\s*business|business\s*activity|principal\s*activity)[:\s]*([^\n]+)/i,
  
  // Contact Details
  email: /(?:email|e-mail)[:\s]*([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/gi,
  phoneNumber: /(?:(?:phone|tel|mobile|contact|office)\s*(?:no\.?|number)?)[:\s]*(\+?[\d\s\-\(\)]{8,})/gi,
  faxNumber: /(?:fax\s*(?:no\.?|number)?)[:\s]*(\+?[\d\s\-\(\)]{8,})/i,
  
  // Personal Details
  nric: /(?:nric|ic\s*no\.?)[:\s]*([STFG]\d{7}[A-Z])/gi,
  passport: /(?:passport\s*(?:no\.?|number)?)[:\s]*([A-Z0-9]{6,12})/gi,
  fullName: /(?:full\s*name|name)[:\s]*([A-Za-z\s\-\']+)/gi,
  designation: /(?:designation|title|position)[:\s]*([A-Za-z\s\-]+)/gi,
  
  // Address
  postalCode: /(?:postal\s*code|postcode|zip)[:\s]*(\d{6})/gi,
  address: /(?:address|registered\s*address|business\s*address)[:\s]*([^\n]+(?:\n[^\n]+)?)/gi,
  
  // Dates
  date: /(\d{1,2}[\s\/\-\.]\w{3,9}[\s\/\-\.]\d{2,4}|\d{1,2}[\s\/\-\.]\d{1,2}[\s\/\-\.]\d{2,4})/gi,
};

// Helper to clean extracted text
function cleanText(text: string): string {
  return text.replace(/\s+/g, ' ').trim();
}

// Extract text from a single page using PDF.js
async function extractPageText(page: any): Promise<string> {
  const textContent = await page.getTextContent();
  const textItems = textContent.items as Array<{ str: string; transform: number[] }>;
  
  // Sort by vertical position (Y coordinate, descending) then horizontal (X coordinate)
  textItems.sort((a, b) => {
    const yDiff = b.transform[5] - a.transform[5];
    if (Math.abs(yDiff) > 5) return yDiff;
    return a.transform[4] - b.transform[4];
  });
  
  let lastY: number | null = null;
  const lines: string[] = [];
  let currentLine = '';
  
  for (const item of textItems) {
    const y = item.transform[5];
    if (lastY !== null && Math.abs(y - lastY) > 5) {
      if (currentLine.trim()) {
        lines.push(currentLine.trim());
      }
      currentLine = item.str;
    } else {
      currentLine += (currentLine ? ' ' : '') + item.str;
    }
    lastY = y;
  }
  
  if (currentLine.trim()) {
    lines.push(currentLine.trim());
  }
  
  return lines.join('\n');
}

// Render PDF page to canvas for OCR
async function renderPageToCanvas(page: any, scale: number = 2): Promise<HTMLCanvasElement> {
  const viewport = page.getViewport({ scale });
  const canvas = document.createElement('canvas');
  const context = canvas.getContext('2d');
  
  canvas.width = viewport.width;
  canvas.height = viewport.height;
  
  await page.render({
    canvasContext: context,
    viewport: viewport
  }).promise;
  
  return canvas;
}

// Extract signature regions from a canvas
async function extractSignaturesFromCanvas(
  canvas: HTMLCanvasElement, 
  pageNumber: number,
  scale: number = 2
): Promise<ExtractedSignature[]> {
  const ctx = canvas.getContext('2d');
  if (!ctx) return [];
  
  const signatures: ExtractedSignature[] = [];
  const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const data = imageData.data;
  
  // Find dark ink regions that could be signatures
  // Look for connected dark pixels in typical signature regions
  const width = canvas.width;
  const height = canvas.height;
  
  // Signature boxes are typically in lower portions or specific regions
  // We'll scan for regions with handwriting characteristics
  const regions = findPotentialSignatureRegions(data, width, height, scale);
  
  for (let i = 0; i < regions.length; i++) {
    const region = regions[i];
    
    // Extract the region as a separate canvas
    const sigCanvas = document.createElement('canvas');
    sigCanvas.width = region.width;
    sigCanvas.height = region.height;
    const sigCtx = sigCanvas.getContext('2d');
    
    if (sigCtx) {
      sigCtx.drawImage(
        canvas, 
        region.x, region.y, region.width, region.height,
        0, 0, region.width, region.height
      );
      
      // Convert to base64 with white background for signatures
      const finalCanvas = document.createElement('canvas');
      finalCanvas.width = region.width;
      finalCanvas.height = region.height;
      const finalCtx = finalCanvas.getContext('2d');
      
      if (finalCtx) {
        // White background
        finalCtx.fillStyle = '#ffffff';
        finalCtx.fillRect(0, 0, region.width, region.height);
        finalCtx.drawImage(sigCanvas, 0, 0);
        
        signatures.push({
          id: `sig-${pageNumber}-${i + 1}`,
          imageData: finalCanvas.toDataURL('image/png'),
          pageNumber,
          bounds: {
            x: Math.round(region.x / scale),
            y: Math.round(region.y / scale),
            width: Math.round(region.width / scale),
            height: Math.round(region.height / scale)
          },
          confidence: region.confidence
        });
        
        finalCanvas.remove();
      }
      sigCanvas.remove();
    }
  }
  
  return signatures;
}

// Find potential signature regions based on ink density and pattern
function findPotentialSignatureRegions(
  data: Uint8ClampedArray, 
  width: number, 
  height: number,
  scale: number
): Array<{ x: number; y: number; width: number; height: number; confidence: number }> {
  const regions: Array<{ x: number; y: number; width: number; height: number; confidence: number }> = [];
  
  // Typical signature box dimensions (scaled)
  const minSigWidth = 100 * scale;
  const maxSigWidth = 400 * scale;
  const minSigHeight = 40 * scale;
  const maxSigHeight = 120 * scale;
  
  // Grid-based scanning for signature-like regions
  const gridSize = Math.round(20 * scale);
  const inkThreshold = 120; // Darkness threshold for ink
  
  // Create ink density map
  const cols = Math.ceil(width / gridSize);
  const rows = Math.ceil(height / gridSize);
  const densityMap: number[][] = [];
  
  for (let row = 0; row < rows; row++) {
    densityMap[row] = [];
    for (let col = 0; col < cols; col++) {
      let inkPixels = 0;
      let totalPixels = 0;
      
      for (let y = row * gridSize; y < Math.min((row + 1) * gridSize, height); y++) {
        for (let x = col * gridSize; x < Math.min((col + 1) * gridSize, width); x++) {
          const idx = (y * width + x) * 4;
          const r = data[idx];
          const g = data[idx + 1];
          const b = data[idx + 2];
          
          // Check if pixel is dark (potential ink)
          if (r < inkThreshold && g < inkThreshold && b < inkThreshold) {
            inkPixels++;
          }
          totalPixels++;
        }
      }
      
      densityMap[row][col] = totalPixels > 0 ? inkPixels / totalPixels : 0;
    }
  }
  
  // Find connected regions with moderate ink density (signatures are not solid blocks)
  const visited = new Set<string>();
  
  for (let row = 0; row < rows; row++) {
    for (let col = 0; col < cols; col++) {
      const key = `${row},${col}`;
      if (visited.has(key)) continue;
      
      const density = densityMap[row][col];
      // Signature regions have moderate ink density (not empty, not solid)
      if (density > 0.02 && density < 0.5) {
        const region = floodFillRegion(densityMap, row, col, rows, cols, visited, 0.01, 0.6);
        
        if (region) {
          const regionWidth = (region.maxCol - region.minCol + 1) * gridSize;
          const regionHeight = (region.maxRow - region.minRow + 1) * gridSize;
          
          // Check if dimensions are signature-like
          if (regionWidth >= minSigWidth && regionWidth <= maxSigWidth &&
              regionHeight >= minSigHeight && regionHeight <= maxSigHeight) {
            
            // Calculate confidence based on aspect ratio and density pattern
            const aspectRatio = regionWidth / regionHeight;
            const idealAspectRatio = 3.5; // Signatures are typically wide
            const aspectConfidence = 1 - Math.min(Math.abs(aspectRatio - idealAspectRatio) / idealAspectRatio, 1);
            
            // Check if it has handwriting-like variation (not uniform)
            const densityVariance = calculateDensityVariance(densityMap, region);
            const varianceConfidence = Math.min(densityVariance * 10, 1);
            
            const confidence = (aspectConfidence * 0.4 + varianceConfidence * 0.4 + Math.min(density * 5, 0.2));
            
            if (confidence > 0.3) {
              regions.push({
                x: region.minCol * gridSize,
                y: region.minRow * gridSize,
                width: regionWidth,
                height: regionHeight,
                confidence
              });
            }
          }
        }
      }
    }
  }
  
  // Sort by confidence and return top candidates
  regions.sort((a, b) => b.confidence - a.confidence);
  return regions.slice(0, 10); // Max 10 signatures per page
}

// Flood fill to find connected regions
function floodFillRegion(
  densityMap: number[][],
  startRow: number,
  startCol: number,
  rows: number,
  cols: number,
  visited: Set<string>,
  minDensity: number,
  maxDensity: number
): { minRow: number; maxRow: number; minCol: number; maxCol: number } | null {
  const stack = [{ row: startRow, col: startCol }];
  let minRow = startRow, maxRow = startRow;
  let minCol = startCol, maxCol = startCol;
  let cellCount = 0;
  
  while (stack.length > 0) {
    const { row, col } = stack.pop()!;
    const key = `${row},${col}`;
    
    if (visited.has(key)) continue;
    if (row < 0 || row >= rows || col < 0 || col >= cols) continue;
    
    const density = densityMap[row][col];
    if (density < minDensity || density > maxDensity) continue;
    
    visited.add(key);
    cellCount++;
    
    minRow = Math.min(minRow, row);
    maxRow = Math.max(maxRow, row);
    minCol = Math.min(minCol, col);
    maxCol = Math.max(maxCol, col);
    
    // Check neighbors
    stack.push({ row: row - 1, col });
    stack.push({ row: row + 1, col });
    stack.push({ row, col: col - 1 });
    stack.push({ row, col: col + 1 });
  }
  
  return cellCount >= 3 ? { minRow, maxRow, minCol, maxCol } : null;
}

// Calculate variance in density across a region (handwriting has variation)
function calculateDensityVariance(
  densityMap: number[][],
  region: { minRow: number; maxRow: number; minCol: number; maxCol: number }
): number {
  const values: number[] = [];
  
  for (let row = region.minRow; row <= region.maxRow; row++) {
    for (let col = region.minCol; col <= region.maxCol; col++) {
      if (densityMap[row] && densityMap[row][col] !== undefined) {
        values.push(densityMap[row][col]);
      }
    }
  }
  
  if (values.length < 2) return 0;
  
  const mean = values.reduce((a, b) => a + b, 0) / values.length;
  const variance = values.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / values.length;
  
  return Math.sqrt(variance);
}

// Perform OCR on a canvas using Tesseract.js
async function performOCR(canvas: HTMLCanvasElement, onProgress?: (progress: number) => void): Promise<string> {
  const result = await Tesseract.recognize(
    canvas,
    'eng',
    {
      logger: (m) => {
        if (m.status === 'recognizing text' && onProgress) {
          onProgress(m.progress);
        }
      }
    }
  );
  
  return result.data.text;
}

// Extract text from PDF - prioritize standard text extraction, OCR only as fallback
async function extractTextWithOCR(
  file: File, 
  onProgress?: (status: string, progress: number) => void
): Promise<{ pages: string[]; fullText: string; ocrUsed: boolean; extractedSignatures: ExtractedSignature[] }> {
  const pdfjs = getPdfJs();
  const arrayBuffer = await file.arrayBuffer();
  
  console.log('Loading PDF document...');
  const pdf = await pdfjs.getDocument({ data: arrayBuffer }).promise;
  console.log('PDF loaded, pages:', pdf.numPages);
  
  const pages: string[] = [];
  let fullText = '';
  let ocrUsed = false;
  const totalPages = pdf.numPages;
  const allSignatures: ExtractedSignature[] = [];
  
  onProgress?.(`Reading ${totalPages} page(s)...`, 5);
  
  for (let i = 1; i <= totalPages; i++) {
    const page = await pdf.getPage(i);
    
    // Always try standard text extraction first
    onProgress?.(`Extracting text from page ${i}/${totalPages}...`, (i / totalPages) * 70);
    let pageText = '';
    
    try {
      pageText = await extractPageText(page);
    } catch (textError) {
      console.warn(`Standard text extraction failed for page ${i}:`, textError);
    }
    
    // Check if page has meaningful text (more than 30 chars of alphanumeric content)
    const alphanumericContent = pageText.replace(/[^a-zA-Z0-9]/g, '');
    const hasEmbeddedText = alphanumericContent.length > 30;
    
    // Render page to canvas for signature extraction (and OCR if needed)
    const canvas = await renderPageToCanvas(page);
    
    // Extract signatures from the page
    onProgress?.(`Scanning for signatures on page ${i}/${totalPages}...`, (i / totalPages) * 75);
    try {
      const pageSignatures = await extractSignaturesFromCanvas(canvas, i);
      allSignatures.push(...pageSignatures);
      console.log(`Found ${pageSignatures.length} potential signatures on page ${i}`);
    } catch (sigError) {
      console.warn(`Signature extraction failed for page ${i}:`, sigError);
    }
    
    // Only use OCR if standard extraction yielded very little text
    if (!hasEmbeddedText) {
      onProgress?.(`Page ${i} appears scanned, trying OCR...`, (i / totalPages) * 80);
      
      try {
        const ocrText = await performOCR(canvas, (p) => {
          const overallProgress = ((i - 1) / totalPages + p / totalPages) * 80;
          onProgress?.(`OCR processing page ${i}/${totalPages}...`, overallProgress);
        });
        
        // Only use OCR result if it's better than standard extraction
        if (ocrText.replace(/[^a-zA-Z0-9]/g, '').length > alphanumericContent.length) {
          pageText = ocrText;
          ocrUsed = true;
        }
      } catch (ocrError) {
        console.warn(`OCR failed for page ${i}:`, ocrError);
        // Continue with whatever text we got from standard extraction
      }
    }
    
    // Clean up canvas
    canvas.remove();
    
    pages.push(pageText);
    fullText += pageText + '\n\n';
  }
  
  console.log(`Total signatures extracted: ${allSignatures.length}`);
  
  return { pages, fullText, ocrUsed, extractedSignatures: allSignatures };
}

// Parse form fields from extracted text
function parseFormFields(text: string): Partial<FormData> {
  const formData: Partial<FormData> = { ...initialFormData };
  
  // Extract company name
  const companyMatch = text.match(patterns.companyName);
  if (companyMatch) {
    formData.businessDetails = {
      ...initialFormData.businessDetails,
      registeredName: cleanText(companyMatch[1]),
    };
  }
  
  // Extract UEN
  const uenMatch = text.match(patterns.uen);
  if (uenMatch && formData.businessDetails) {
    formData.businessDetails.registrationNumber = cleanText(uenMatch[1]);
  }
  
  // Extract nature of business
  const natureMatch = text.match(patterns.natureOfBusiness);
  if (natureMatch && formData.businessDetails) {
    formData.businessDetails.natureOfBusiness = cleanText(natureMatch[1]);
  }
  
  // Extract fax number
  const faxMatch = text.match(patterns.faxNumber);
  if (faxMatch && formData.businessDetails) {
    formData.businessDetails.faxNumber = cleanText(faxMatch[1]);
  }
  
  // Extract emails (first for primary, second for secondary)
  const emails = [...text.matchAll(patterns.email)].map(m => m[1]);
  if (emails.length > 0) {
    formData.primaryContact = {
      ...initialFormData.primaryContact,
      email: emails[0],
    };
  }
  if (emails.length > 1) {
    formData.secondaryContact = {
      ...initialFormData.secondaryContact,
      email: emails[1],
    };
  }
  
  // Extract phone numbers
  const phones = [...text.matchAll(patterns.phoneNumber)].map(m => cleanText(m[1]));
  if (phones.length > 0 && formData.businessDetails) {
    formData.businessDetails.officeNumber = phones[0];
  }
  if (phones.length > 1 && formData.primaryContact) {
    formData.primaryContact.mobileNumber = phones[1];
  }
  
  // Extract NRIC numbers
  const nrics = [...text.matchAll(patterns.nric)].map(m => m[1]);
  if (nrics.length > 0 && formData.primaryContact) {
    formData.primaryContact.nricPassport = nrics[0];
  }
  if (nrics.length > 1 && formData.secondaryContact) {
    formData.secondaryContact.nricPassport = nrics[1];
  }
  
  // Extract names (more sophisticated pattern matching)
  const fullNames = extractNames(text);
  if (fullNames.length > 0 && formData.primaryContact) {
    formData.primaryContact.fullName = fullNames[0];
  }
  if (fullNames.length > 1 && formData.secondaryContact) {
    formData.secondaryContact.fullName = fullNames[1];
  }
  
  // Extract addresses
  const addresses = [...text.matchAll(patterns.address)].map(m => cleanText(m[1]));
  if (addresses.length > 0) {
    formData.accountParticulars = {
      ...initialFormData.accountParticulars,
      mailingAddress: addresses[0],
    };
  }
  
  // Extract beneficial owners from the text
  const beneficialOwners = extractBeneficialOwners(text, nrics, fullNames);
  if (beneficialOwners.length > 0) {
    formData.beneficialOwners = beneficialOwners;
  }
  
  // Check for GST registration
  if (/gst\s*registered\s*(?:yes|y|✓|✔)/i.test(text)) {
    if (formData.businessDetails) {
      formData.businessDetails.gstRegistered = true;
    }
  } else if (/gst\s*registered\s*(?:no|n|✗)/i.test(text)) {
    if (formData.businessDetails) {
      formData.businessDetails.gstRegistered = false;
    }
  }
  
  // Extract account types
  formData.accountType = extractAccountTypes(text);
  
  // Extract signing condition
  formData.signingCondition = extractSigningCondition(text);
  
  // Extract board resolution info
  formData.boardResolution = extractBoardResolution(text, fullNames);
  
  return formData;
}

// Extract names from text
function extractNames(text: string): string[] {
  const names: string[] = [];
  
  // Look for patterns like "Name: John Smith" or "Full Name: John Smith"
  const nameMatches = [...text.matchAll(/(?:full\s*name|name\s*(?:of\s*(?:applicant|director|owner|signatory))?)[:\s]+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)/gi)];
  for (const match of nameMatches) {
    const name = cleanText(match[1]);
    if (name.length > 5 && name.split(' ').length >= 2 && !names.includes(name)) {
      names.push(name);
    }
  }
  
  // Also look for patterns near NRIC mentions
  const nricNamePattern = /([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)\s*(?:\(?\s*[STFG]\d{7}[A-Z]\s*\)?)/g;
  const nricNames = [...text.matchAll(nricNamePattern)];
  for (const match of nricNames) {
    const name = cleanText(match[1]);
    if (name.length > 5 && name.split(' ').length >= 2 && !names.includes(name)) {
      names.push(name);
    }
  }
  
  return names;
}

// Extract beneficial owners
function extractBeneficialOwners(text: string, nrics: string[], names: string[]): FormData['beneficialOwners'] {
  const owners: FormData['beneficialOwners'] = [];
  
  // Match each name with corresponding NRIC if available
  const maxOwners = Math.max(names.length, nrics.length);
  for (let i = 0; i < maxOwners && i < 5; i++) {
    owners.push({
      id: `owner-${i + 1}`,
      fullName: names[i] || '',
      nricPassport: nrics[i] || '',
      designation: i === 0 ? 'Director' : 'Shareholder',
      isBeneficialOwner: true,
      isAuthorisedSignatory: i < 2,
      mobileNumber: '',
      officeNumber: '',
      email: '',
      grouping: i < 2 ? 'A' : 'B',
      signature: '',
    });
  }
  
  return owners;
}

// Extract account types
function extractAccountTypes(text: string): FormData['accountType'] {
  const accountType: FormData['accountType'] = {
    sgdAccounts: [],
    foreignCurrencyAccounts: [],
    currencies: [],
  };
  
  // Check for SGD accounts
  if (/business\s*current\s*account|current\s*account/i.test(text)) {
    accountType.sgdAccounts.push('Business Current Account');
  }
  if (/savings?\s*account|statement\s*savings/i.test(text)) {
    accountType.sgdAccounts.push('Business Statement Savings Account');
  }
  if (/fixed\s*deposit/i.test(text)) {
    accountType.sgdAccounts.push('Fixed Deposit Account');
  }
  
  // Check for foreign currency accounts
  if (/multi[\-\s]?currency|foreign\s*currency/i.test(text)) {
    accountType.foreignCurrencyAccounts.push('Multi-Currency Account');
  }
  
  // Extract currencies
  if (/USD|US\s*Dollar/i.test(text)) accountType.currencies.push('USD');
  if (/EUR|Euro/i.test(text)) accountType.currencies.push('EUR');
  if (/GBP|British\s*Pound/i.test(text)) accountType.currencies.push('GBP');
  if (/JPY|Japanese\s*Yen/i.test(text)) accountType.currencies.push('JPY');
  if (/CNY|Chinese\s*Yuan|RMB/i.test(text)) accountType.currencies.push('CNY');
  if (/AUD|Australian\s*Dollar/i.test(text)) accountType.currencies.push('AUD');
  
  return accountType;
}

// Extract signing condition
function extractSigningCondition(text: string): FormData['signingCondition'] {
  let type: 'singly' | 'anyTwo' | 'grouping' = 'singly';
  let details = '';
  
  if (/any\s*two\s*(?:signatories?|directors?|to\s*sign)/i.test(text)) {
    type = 'anyTwo';
    details = 'Any two authorised signatories to sign jointly';
  } else if (/singly|sole\s*signatory|single\s*sign/i.test(text)) {
    type = 'singly';
    details = 'Single authorised signatory';
  } else if (/group\s*[A-Z]\s*and\s*group\s*[A-Z]/i.test(text)) {
    type = 'grouping';
    details = 'Combined signing from different groups required';
  }
  
  return {
    type,
    details,
    applyToAllAccounts: true,
  };
}

// Extract board resolution
function extractBoardResolution(text: string, names: string[]): FormData['boardResolution'] {
  const resolution = { ...initialFormData.boardResolution };
  
  // Extract company name for resolution
  const companyMatch = text.match(patterns.companyName);
  if (companyMatch) {
    resolution.companyName = cleanText(companyMatch[1]);
  }
  
  // Extract meeting date
  const dateMatches = [...text.matchAll(patterns.date)];
  if (dateMatches.length > 0) {
    try {
      const dateStr = dateMatches[0][1];
      // Try to parse the date
      const parsed = new Date(dateStr);
      if (!isNaN(parsed.getTime())) {
        resolution.meetingDate = parsed.toISOString().split('T')[0];
        resolution.certificationDate = parsed.toISOString().split('T')[0];
      }
    } catch {
      // Keep empty if parsing fails
    }
  }
  
  // Set resolution passed if document mentions resolution
  if (/resolution|resolved|hereby\s*resolve/i.test(text)) {
    resolution.resolutionPassed = true;
  }
  
  // Check for specific authorities
  resolution.openCloseAccounts = /open(?:ing)?\s*(?:and\s*)?(?:clos(?:e|ing))?\s*(?:of\s*)?(?:bank\s*)?account/i.test(text);
  resolution.applyBankingServices = /banking\s*services?|bank\s*facilities/i.test(text);
  resolution.appointAuthorisedSignatories = /authoris(?:e|ed)\s*signator/i.test(text);
  resolution.corporateCreditCard = /corporate\s*(?:credit\s*)?card|credit\s*card/i.test(text);
  resolution.electronicSigning = /electronic|digital\s*sign|e[\-\s]?sign/i.test(text);
  
  // Create authorised persons from extracted names
  resolution.authorisedPersons = names.slice(0, 4).map((name, i) => ({
    id: `auth-${i + 1}`,
    fullName: name,
    nricPassport: '',
    designation: i === 0 ? 'Director' : 'Authorised Signatory',
    signature: '',
  }));
  
  return resolution;
}

// Assign extracted signatures to appropriate form fields
function assignSignaturesToFormFields(
  formData: Partial<FormData>, 
  signatures: ExtractedSignature[]
): Partial<FormData> {
  if (signatures.length === 0) return formData;
  
  const result = { ...formData };
  let sigIndex = 0;
  
  // Assign to beneficial owners
  if (result.beneficialOwners && result.beneficialOwners.length > 0) {
    result.beneficialOwners = result.beneficialOwners.map(owner => {
      if (sigIndex < signatures.length && !owner.signature) {
        const sig = signatures[sigIndex++];
        return { ...owner, signature: sig.imageData };
      }
      return owner;
    });
  }
  
  // Assign to board resolution authorised persons
  if (result.boardResolution && result.boardResolution.authorisedPersons) {
    result.boardResolution = {
      ...result.boardResolution,
      authorisedPersons: result.boardResolution.authorisedPersons.map(person => {
        if (sigIndex < signatures.length && !person.signature) {
          const sig = signatures[sigIndex++];
          return { ...person, signature: sig.imageData };
        }
        return person;
      }),
    };
    
    // Assign to director signatures if available
    if (result.boardResolution.directorSignatures && sigIndex < signatures.length) {
      result.boardResolution.directorSignatures = result.boardResolution.directorSignatures.map(dir => {
        if (sigIndex < signatures.length && !dir.signature) {
          const sig = signatures[sigIndex++];
          return { ...dir, signature: sig.imageData };
        }
        return dir;
      });
    }
    
    // Assign to company secretary signature
    if (!result.boardResolution.companySecretarySignature && sigIndex < signatures.length) {
      result.boardResolution.companySecretarySignature = signatures[sigIndex++].imageData;
    }
  }
  
  // Assign to agreement signatures if available
  if (result.agreement && result.agreement.agreementSignatures && sigIndex < signatures.length) {
    result.agreement = {
      ...result.agreement,
      agreementSignatures: result.agreement.agreementSignatures.map(sig => {
        if (sigIndex < signatures.length && !sig.signature) {
          const extracted = signatures[sigIndex++];
          return { ...sig, signature: extracted.imageData };
        }
        return sig;
      }),
    };
  }
  
  console.log(`Assigned ${sigIndex} signatures to form fields`);
  
  return result;
}

// Main PDF parsing function with OCR support
export async function parsePDF(
  file: File, 
  onProgress?: (status: string, progress: number) => void
): Promise<ExtractedPDFData> {
  console.log('Starting PDF parsing for file:', file.name, 'size:', file.size);
  
  try {
    onProgress?.('Loading PDF...', 0);
    
    // Validate file
    if (!file || file.size === 0) {
      throw new Error('Empty or invalid file');
    }
    
    if (!file.type.includes('pdf') && !file.name.toLowerCase().endsWith('.pdf')) {
      throw new Error('File is not a PDF');
    }
    
    console.log('PDF file validated, starting text extraction...');
    
    const { pages, fullText, ocrUsed, extractedSignatures } = await extractTextWithOCR(file, onProgress);
    
    console.log('Text extracted:', { 
      pageCount: pages.length, 
      textLength: fullText.length, 
      ocrUsed,
      signaturesFound: extractedSignatures.length
    });
    
    onProgress?.('Extracting form data...', 90);
    
    // Parse form fields from the extracted text
    const parsedFields = parseFormFields(fullText);
    
    // Assign extracted signatures to form fields
    const formDataWithSignatures = assignSignaturesToFormFields(parsedFields, extractedSignatures);
    
    // Merge with initial form data to ensure all fields exist
    const formData: FormData = {
      ...initialFormData,
      ...formDataWithSignatures,
      businessDetails: {
        ...initialFormData.businessDetails,
        ...formDataWithSignatures.businessDetails,
      },
      primaryContact: {
        ...initialFormData.primaryContact,
        ...formDataWithSignatures.primaryContact,
      },
      secondaryContact: {
        ...initialFormData.secondaryContact,
        ...formDataWithSignatures.secondaryContact,
      },
      accountType: {
        ...initialFormData.accountType,
        ...formDataWithSignatures.accountType,
      },
      accountParticulars: {
        ...initialFormData.accountParticulars,
        ...formDataWithSignatures.accountParticulars,
      },
      signingCondition: {
        ...initialFormData.signingCondition,
        ...formDataWithSignatures.signingCondition,
      },
      boardResolution: {
        ...initialFormData.boardResolution,
        ...formDataWithSignatures.boardResolution,
      },
      beneficialOwners: formDataWithSignatures.beneficialOwners || [],
    };
    
    onProgress?.('Complete', 100);
    
    console.log('PDF parsing complete');
    
    return {
      rawText: fullText,
      pages,
      formData,
      ocrUsed,
      extractedSignatures,
    };
  } catch (error) {
    console.error('Error parsing PDF:', error);
    const message = error instanceof Error ? error.message : 'Unknown error';
    throw new Error(`Failed to parse PDF: ${message}`);
  }
}

// Export extracted data for debugging
export function getExtractionSummary(data: ExtractedPDFData): string {
  const { formData, ocrUsed, extractedSignatures } = data;
  const summary: string[] = [];
  
  if (ocrUsed) {
    summary.push('📷 OCR was used to extract text from scanned pages');
  }
  
  if (extractedSignatures && extractedSignatures.length > 0) {
    summary.push(`✍️ ${extractedSignatures.length} signature(s) detected and extracted`);
  }
  
  if (formData.businessDetails.registeredName) {
    summary.push(`Company: ${formData.businessDetails.registeredName}`);
  }
  if (formData.businessDetails.registrationNumber) {
    summary.push(`UEN: ${formData.businessDetails.registrationNumber}`);
  }
  if (formData.primaryContact.fullName) {
    summary.push(`Primary Contact: ${formData.primaryContact.fullName}`);
  }
  if (formData.beneficialOwners.length > 0) {
    summary.push(`Beneficial Owners: ${formData.beneficialOwners.length}`);
  }
  if (formData.accountType.sgdAccounts.length > 0) {
    summary.push(`SGD Accounts: ${formData.accountType.sgdAccounts.join(', ')}`);
  }
  
  return summary.length > 0 ? summary.join('\n') : 'No data extracted from PDF';
}

// Export types for use in other modules
export type { ExtractedSignature, ExtractedPDFData };
