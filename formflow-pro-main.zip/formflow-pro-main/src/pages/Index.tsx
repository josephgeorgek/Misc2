import { useParams, useLocation } from 'react-router-dom';
import { BusinessAccountForm } from "@/components/form/BusinessAccountForm";
import { getDraftById } from '@/data/drafts';
import { FormData } from '@/types/form';

interface LocationState {
  prefillData?: FormData;
}

const Index = () => {
  const { id } = useParams<{ id: string }>();
  const location = useLocation();
  const state = location.state as LocationState | null;
  
  // Priority: 1) prefillData from navigation state (PDF upload), 2) draft by ID
  const initialData = state?.prefillData || (id ? getDraftById(id) : undefined);

  return <BusinessAccountForm initialData={initialData} draftId={id} />;
};

export default Index;