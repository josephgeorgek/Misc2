import { useState } from 'react';
import { useNavigate, useLocation, useSearchParams } from 'react-router-dom';
import {
  Box,
  Typography,
  Button,
  Card,
  CardContent,
  Stepper,
  Step,
  StepLabel,
  StepConnector,
  stepConnectorClasses,
  useMediaQuery,
  useTheme,
  Alert,
} from '@mui/material';
import { styled } from '@mui/material/styles';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import SaveIcon from '@mui/icons-material/Save';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import BusinessIcon from '@mui/icons-material/Business';
import AccountBalanceIcon from '@mui/icons-material/AccountBalance';
import SettingsIcon from '@mui/icons-material/Settings';
import PeopleIcon from '@mui/icons-material/People';
import DescriptionIcon from '@mui/icons-material/Description';
import PublicIcon from '@mui/icons-material/Public';
import CreditCardIcon from '@mui/icons-material/CreditCard';
import PaymentIcon from '@mui/icons-material/Payment';
import ReceiptIcon from '@mui/icons-material/Receipt';
import FactCheckIcon from '@mui/icons-material/FactCheck';
import { FormData, initialFormData } from '@/types/form';

// Custom styled stepper connector
const CustomConnector = styled(StepConnector)(({ theme }) => ({
  [`&.${stepConnectorClasses.alternativeLabel}`]: {
    top: 22,
  },
  [`&.${stepConnectorClasses.active}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      backgroundColor: theme.palette.primary.main,
    },
  },
  [`&.${stepConnectorClasses.completed}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      backgroundColor: theme.palette.success.main,
    },
  },
  [`& .${stepConnectorClasses.line}`]: {
    height: 3,
    border: 0,
    backgroundColor: theme.palette.grey[300],
    borderRadius: 1,
  },
}));

// Step icons component
const StepIconRoot = styled('div')<{ ownerState: { completed?: boolean; active?: boolean } }>(
  ({ theme, ownerState }) => ({
    backgroundColor: theme.palette.grey[300],
    zIndex: 1,
    color: theme.palette.grey[600],
    width: 44,
    height: 44,
    display: 'flex',
    borderRadius: '50%',
    justifyContent: 'center',
    alignItems: 'center',
    transition: 'all 0.2s ease',
    ...(ownerState.active && {
      backgroundColor: theme.palette.primary.main,
      color: '#fff',
      boxShadow: '0 4px 14px 0 rgba(196, 18, 48, 0.39)',
    }),
    ...(ownerState.completed && {
      backgroundColor: theme.palette.success.main,
      color: '#fff',
    }),
  }),
);

const steps = [
  { label: 'Business Details', icon: <BusinessIcon /> },
  { label: 'Account Type', icon: <AccountBalanceIcon /> },
  { label: 'Account Particulars', icon: <SettingsIcon /> },
  { label: 'Beneficial Owners', icon: <PeopleIcon /> },
  { label: 'Board Resolution', icon: <DescriptionIcon /> },
  { label: 'Tax Declaration', icon: <PublicIcon /> },
  { label: 'Business Services', icon: <CreditCardIcon /> },
  { label: 'Debit Card', icon: <PaymentIcon /> },
  { label: 'GIRO', icon: <ReceiptIcon /> },
  { label: 'Review', icon: <FactCheckIcon /> },
];

interface StepIconProps {
  active?: boolean;
  completed?: boolean;
  icon: React.ReactNode;
  className?: string;
}

function CustomStepIcon(props: StepIconProps) {
  const { active, completed, icon, className } = props;
  const stepIndex = Number(icon) - 1;
  const stepData = steps[stepIndex];

  return (
    <StepIconRoot ownerState={{ completed, active }} className={className}>
      {completed ? <CheckCircleIcon /> : stepData?.icon}
    </StepIconRoot>
  );
}

export default function BusinessAccountFormMUI() {
  const theme = useTheme();
  const navigate = useNavigate();
  const location = useLocation();
  const [searchParams] = useSearchParams();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  
  const [activeStep, setActiveStep] = useState(0);
  const [formData, setFormData] = useState<FormData>(
    location.state?.prefillData || initialFormData
  );
  const [isSaving, setIsSaving] = useState(false);

  const handleNext = () => {
    if (activeStep < steps.length - 1) {
      setActiveStep((prev) => prev + 1);
    }
  };

  const handleBack = () => {
    if (activeStep > 0) {
      setActiveStep((prev) => prev - 1);
    }
  };

  const handleStepClick = (step: number) => {
    setActiveStep(step);
  };

  const handleSaveDraft = async () => {
    setIsSaving(true);
    // Simulate saving
    await new Promise((resolve) => setTimeout(resolve, 1000));
    setIsSaving(false);
    // TODO: Implement actual save logic
  };

  const handleSubmit = async () => {
    // TODO: Implement submission logic
    console.log('Submitting form:', formData);
  };

  const renderStepContent = () => {
    switch (activeStep) {
      case 0:
        return <BusinessDetailsStep formData={formData} setFormData={setFormData} />;
      case 1:
        return <AccountTypeStep formData={formData} setFormData={setFormData} />;
      // Add other steps as needed
      default:
        return (
          <Box sx={{ py: 4, textAlign: 'center' }}>
            <Typography variant="h6" color="text.secondary">
              Step {activeStep + 1}: {steps[activeStep].label}
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
              Content for this step will be implemented.
            </Typography>
          </Box>
        );
    }
  };

  return (
    <Box>
      {/* Header */}
      <Box sx={{ mb: 3 }}>
        <Button
          startIcon={<ArrowBackIcon />}
          onClick={() => navigate('/')}
          sx={{ mb: 2 }}
        >
          Back to Dashboard
        </Button>
        <Typography variant="h4" fontWeight={700} gutterBottom>
          Business Account Application
        </Typography>
        <Typography variant="body1" color="text.secondary">
          Complete all steps to submit your application
        </Typography>
      </Box>

      {/* Stepper */}
      <Card sx={{ mb: 3, overflow: 'visible' }}>
        <CardContent sx={{ py: 3 }}>
          <Stepper
            activeStep={activeStep}
            alternativeLabel={!isMobile}
            orientation={isMobile ? 'vertical' : 'horizontal'}
            connector={<CustomConnector />}
          >
            {steps.map((step, index) => (
              <Step key={step.label}>
                <StepLabel
                  StepIconComponent={CustomStepIcon}
                  onClick={() => handleStepClick(index)}
                  sx={{ cursor: 'pointer' }}
                >
                  {!isMobile && (
                    <Typography
                      variant="caption"
                      sx={{
                        fontWeight: activeStep === index ? 600 : 400,
                        color: activeStep === index ? 'primary.main' : 'text.secondary',
                      }}
                    >
                      {step.label}
                    </Typography>
                  )}
                </StepLabel>
              </Step>
            ))}
          </Stepper>
        </CardContent>
      </Card>

      {/* Form Content */}
      <Card>
        <CardContent sx={{ py: 4 }}>
          {renderStepContent()}
        </CardContent>
      </Card>

      {/* Navigation Buttons */}
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          mt: 3,
          flexWrap: 'wrap',
          gap: 2,
        }}
      >
        <Button
          variant="outlined"
          startIcon={<ArrowBackIcon />}
          onClick={handleBack}
          disabled={activeStep === 0}
        >
          Previous
        </Button>
        <Box sx={{ display: 'flex', gap: 2 }}>
          <Button
            variant="outlined"
            startIcon={<SaveIcon />}
            onClick={handleSaveDraft}
            disabled={isSaving}
          >
            {isSaving ? 'Saving...' : 'Save Draft'}
          </Button>
          {activeStep === steps.length - 1 ? (
            <Button
              variant="contained"
              startIcon={<CheckCircleIcon />}
              onClick={handleSubmit}
            >
              Submit Application
            </Button>
          ) : (
            <Button
              variant="contained"
              endIcon={<ArrowForwardIcon />}
              onClick={handleNext}
            >
              Next Step
            </Button>
          )}
        </Box>
      </Box>
    </Box>
  );
}

// Placeholder step components
function BusinessDetailsStep({ formData, setFormData }: { formData: FormData; setFormData: (data: FormData) => void }) {
  return (
    <Box>
      <Typography variant="h5" fontWeight={600} gutterBottom>
        Business Details
      </Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
        Enter your company's registration information
      </Typography>
      <Alert severity="info" sx={{ mb: 2 }}>
        Business details form fields will be implemented here with MUI TextField components.
      </Alert>
    </Box>
  );
}

function AccountTypeStep({ formData, setFormData }: { formData: FormData; setFormData: (data: FormData) => void }) {
  return (
    <Box>
      <Typography variant="h5" fontWeight={600} gutterBottom>
        Account Type Selection
      </Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
        Choose the types of accounts you want to open
      </Typography>
      <Alert severity="info" sx={{ mb: 2 }}>
        Account type selection will be implemented here with MUI checkboxes and cards.
      </Alert>
    </Box>
  );
}
