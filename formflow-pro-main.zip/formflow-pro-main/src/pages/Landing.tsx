import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Search, Plus, Building2, FileText, Clock, CheckCircle2, XCircle, Edit3, Eye, UserPlus } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { getAllDrafts, searchDrafts, DraftApplication } from '@/data/drafts';
import { format } from 'date-fns';
import { OnboardingModal } from '@/components/OnboardingModal';

const statusConfig = {
  draft: { label: 'Draft', icon: Edit3, variant: 'secondary' as const, className: 'bg-muted text-muted-foreground' },
  submitted: { label: 'Submitted', icon: Clock, variant: 'default' as const, className: 'bg-primary/10 text-primary' },
  approved: { label: 'Approved', icon: CheckCircle2, variant: 'default' as const, className: 'bg-success/10 text-success' },
  rejected: { label: 'Rejected', icon: XCircle, variant: 'destructive' as const, className: 'bg-destructive/10 text-destructive' },
};

function ApplicationCard({ application }: { application: DraftApplication }) {
  const status = statusConfig[application.status];
  const StatusIcon = status.icon;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4 }}
      transition={{ duration: 0.2 }}
    >
      <Card className="group hover:shadow-lg hover:border-primary/30 transition-all duration-300">
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-3 min-w-0">
              <div className="p-2 rounded-lg bg-primary/10 text-primary shrink-0">
                <Building2 className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <CardTitle className="text-lg font-semibold truncate">
                  {application.businessDetails.registeredName}
                </CardTitle>
                <p className="text-sm text-muted-foreground mt-0.5">
                  {application.businessDetails.registrationNumber}
                </p>
              </div>
            </div>
            <Badge className={`shrink-0 ${status.className}`}>
              <StatusIcon className="w-3 h-3 mr-1" />
              {status.label}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div>
              <p className="text-muted-foreground">Business Type</p>
              <p className="font-medium truncate">{application.businessDetails.businessType}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Contact</p>
              <p className="font-medium truncate">{application.primaryContact.fullName}</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2 text-xs text-muted-foreground pt-2 border-t border-border">
            <Clock className="w-3 h-3" />
            <span>Updated {format(new Date(application.updatedAt), 'MMM d, yyyy')}</span>
          </div>

          <div className="flex gap-2 pt-2">
            <Button asChild variant="outline" size="sm" className="flex-1">
              <Link to={`/view/${application.id}`}>
                <Eye className="w-4 h-4 mr-2" />
                View
              </Link>
            </Button>
            {application.status === 'draft' && (
              <Button asChild size="sm" className="flex-1">
                <Link to={`/edit/${application.id}`}>
                  <Edit3 className="w-4 h-4 mr-2" />
                  Edit
                </Link>
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

export default function Landing() {
  const [searchQuery, setSearchQuery] = useState('');
  const [showOnboarding, setShowOnboarding] = useState(false);
  
  const filteredApplications = useMemo(() => {
    return searchDrafts(searchQuery);
  }, [searchQuery]);

  const stats = useMemo(() => {
    const allDrafts = getAllDrafts();
    return {
      total: allDrafts.length,
      draft: allDrafts.filter(a => a.status === 'draft').length,
      submitted: allDrafts.filter(a => a.status === 'submitted').length,
      approved: allDrafts.filter(a => a.status === 'approved').length,
    };
  }, [filteredApplications]);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/80">
        <div className="container max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-gradient-to-br from-primary to-primary/80 text-primary-foreground">
                <FileText className="w-6 h-6" />
              </div>
              <div>
                <h1 className="text-xl font-bold font-display">Business Applications</h1>
                <p className="text-sm text-muted-foreground">Manage your account applications</p>
              </div>
            </div>
            <Button onClick={() => setShowOnboarding(true)}>
              <UserPlus className="w-4 h-4 mr-2" />
              Onboard New Customer
            </Button>
          </div>

          <OnboardingModal open={showOnboarding} onOpenChange={setShowOnboarding} />
        </div>
      </header>

      <main className="container max-w-6xl mx-auto px-4 py-8">
        {/* Stats */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8"
        >
          <Card className="bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20">
            <CardContent className="pt-6">
              <div className="text-3xl font-bold text-primary">{stats.total}</div>
              <p className="text-sm text-muted-foreground">Total Applications</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-3xl font-bold">{stats.draft}</div>
              <p className="text-sm text-muted-foreground">Drafts</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-3xl font-bold text-primary">{stats.submitted}</div>
              <p className="text-sm text-muted-foreground">Submitted</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-3xl font-bold text-success">{stats.approved}</div>
              <p className="text-sm text-muted-foreground">Approved</p>
            </CardContent>
          </Card>
        </motion.div>

        {/* Search */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-8"
        >
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search by company name, UEN, or contact..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 h-12"
            />
          </div>
        </motion.div>

        {/* Results */}
        {filteredApplications.length > 0 ? (
          <div className="grid md:grid-cols-2 gap-6">
            {filteredApplications.map((application, index) => (
              <motion.div
                key={application.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 + index * 0.05 }}
              >
                <ApplicationCard application={application} />
              </motion.div>
            ))}
          </div>
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-16"
          >
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-muted mb-4">
              <Search className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold mb-2">No applications found</h3>
            <p className="text-muted-foreground mb-6">
              Try adjusting your search query or create a new application.
            </p>
            <Button onClick={() => setShowOnboarding(true)}>
              <UserPlus className="w-4 h-4 mr-2" />
              Onboard New Customer
            </Button>
          </motion.div>
        )}
      </main>
    </div>
  );
}
