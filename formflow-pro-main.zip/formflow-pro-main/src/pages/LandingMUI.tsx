import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Typography,
  Button,
  Card,
  CardContent,
  Chip,
  IconButton,
  TextField,
  InputAdornment,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  LinearProgress,
  Stack,
  Alert,
  Tabs,
  Tab,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Divider,
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import SearchIcon from '@mui/icons-material/Search';
import VisibilityIcon from '@mui/icons-material/Visibility';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import UploadFileIcon from '@mui/icons-material/UploadFile';
import ComputerIcon from '@mui/icons-material/Computer';
import DescriptionIcon from '@mui/icons-material/Description';
import TrendingUpIcon from '@mui/icons-material/TrendingUp';
import PeopleIcon from '@mui/icons-material/People';
import AccountBalanceIcon from '@mui/icons-material/AccountBalance';
import SaveIcon from '@mui/icons-material/Save';
import CodeIcon from '@mui/icons-material/Code';
import ListAltIcon from '@mui/icons-material/ListAlt';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import { getAllDrafts, DraftApplication } from '@/data/drafts';
import { parsePDF, getExtractionSummary, ExtractedSignature } from '@/lib/pdfParser';
import { FormData, initialFormData } from '@/types/form';
import DrawIcon from '@mui/icons-material/Draw';

const statsData = [
  { title: 'Total Applications', value: '156', change: '+12%', icon: <DescriptionIcon /> },
  { title: 'Pending Review', value: '23', change: '-5%', icon: <TrendingUpIcon /> },
  { title: 'Active Customers', value: '89', change: '+8%', icon: <PeopleIcon /> },
  { title: 'Accounts Opened', value: '67', change: '+15%', icon: <AccountBalanceIcon /> },
];

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel({ children, value, index }: TabPanelProps) {
  return (
    <div hidden={value !== index} style={{ height: '100%' }}>
      {value === index && <Box sx={{ height: '100%' }}>{children}</Box>}
    </div>
  );
}

export default function LandingMUI() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [onboardingOpen, setOnboardingOpen] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [processingStatus, setProcessingStatus] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [extractedData, setExtractedData] = useState<FormData | null>(null);
  const [jsonText, setJsonText] = useState('');
  const [rawText, setRawText] = useState('');
  const [ocrUsed, setOcrUsed] = useState(false);
  const [extractionSummary, setExtractionSummary] = useState('');
  const [jsonError, setJsonError] = useState<string | null>(null);
  const [viewTab, setViewTab] = useState(0);
  const [step, setStep] = useState<'choose' | 'preview'>('choose');
  const [extractedSignatures, setExtractedSignatures] = useState<ExtractedSignature[]>([]);

  const allDrafts = getAllDrafts();
  const filteredDrafts = allDrafts.filter(
    (draft) =>
      draft.businessDetails.registeredName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      draft.businessDetails.registrationNumber.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'submitted': return 'primary';
      case 'approved': return 'success';
      case 'pending': return 'warning';
      default: return 'default';
    }
  };

  const handleOnlineApplication = () => {
    setOnboardingOpen(false);
    navigate('/new');
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    setProcessingStatus('Loading PDF...');
    setUploadProgress(0);
    setJsonError(null);

    try {
      const result = await parsePDF(file, (status, progress) => {
        setProcessingStatus(status);
        setUploadProgress(progress);
      });

      if (result && result.formData) {
        setExtractedData(result.formData);
        setJsonText(JSON.stringify(result.formData, null, 2));
        setRawText(result.rawText || '');
        setOcrUsed(result.ocrUsed || false);
        setExtractionSummary(getExtractionSummary(result));
        setExtractedSignatures(result.extractedSignatures || []);
        setIsUploading(false);
        setStep('preview');
      } else {
        throw new Error('No data extracted from PDF');
      }
    } catch (error) {
      console.error('PDF parsing error:', error);
      setProcessingStatus(`Error: ${error instanceof Error ? error.message : 'Failed to parse PDF'}`);
      setIsUploading(false);
      // Don't transition - stay on choose step with error
    }
  };

  const handleJsonChange = (newValue: string) => {
    setJsonText(newValue);
    try {
      const parsed = JSON.parse(newValue);
      setExtractedData(parsed);
      setJsonError(null);
    } catch (e) {
      setJsonError('Invalid JSON format');
    }
  };

  const handleSaveAndEdit = () => {
    if (!extractedData || jsonError) return;
    setOnboardingOpen(false);
    navigate('/new', { state: { prefillData: extractedData } });
  };

  const handleSaveAsDraft = () => {
    if (!extractedData || jsonError) return;

    const draftId = `draft-${Date.now()}`;
    const now = new Date().toISOString();
    const draft = {
      id: draftId,
      status: 'draft' as const,
      createdAt: now,
      updatedAt: now,
      ...extractedData,
    };

    const existingDrafts = localStorage.getItem('user_drafts');
    const drafts = existingDrafts ? JSON.parse(existingDrafts) : [];
    drafts.push(draft);
    localStorage.setItem('user_drafts', JSON.stringify(drafts));

    setOnboardingOpen(false);
    navigate(`/view/${draftId}`);
  };

  const handleEditDraft = (draft: DraftApplication) => {
    // Convert DraftApplication to FormData format
    const formData: FormData = {
      businessDetails: draft.businessDetails,
      primaryContact: draft.primaryContact,
      secondaryContact: draft.secondaryContact,
      accountType: draft.accountType,
      accountParticulars: draft.accountParticulars,
      beneficialOwners: draft.beneficialOwners,
      signingCondition: draft.signingCondition,
      boardResolution: draft.boardResolution,
      taxDeclarationEntity: draft.taxDeclarationEntity,
      taxDeclarationIndividual: draft.taxDeclarationIndividual,
      businessBankingServices: draft.businessBankingServices,
      businessDebitCard: draft.businessDebitCard,
      giroApplication: draft.giroApplication,
      eAlerts: draft.eAlerts,
      agreement: draft.agreement,
      agreeToTerms: draft.agreeToTerms,
    };
    navigate('/new', { state: { prefillData: formData, draftId: draft.id } });
  };

  const resetModal = () => {
    setStep('choose');
    setExtractedData(null);
    setJsonText('');
    setRawText('');
    setJsonError(null);
    setUploadProgress(0);
    setProcessingStatus('');
    setOcrUsed(false);
    setExtractionSummary('');
    setViewTab(0);
  };

  // Render form fields in a readable format
  const renderFormFields = (data: FormData) => {
    const sections = [
      { title: 'Business Details', data: data.businessDetails },
      { title: 'Primary Contact', data: data.primaryContact },
      { title: 'Secondary Contact', data: data.secondaryContact },
      { title: 'Account Type', data: data.accountType },
      { title: 'Account Particulars', data: data.accountParticulars },
      { title: 'Signing Condition', data: data.signingCondition },
      { title: 'Beneficial Owners', data: data.beneficialOwners },
    ];

    return (
      <Box sx={{ maxHeight: 400, overflow: 'auto' }}>
        {sections.map((section, idx) => (
          <Accordion key={idx} defaultExpanded={idx === 0}>
            <AccordionSummary expandIcon={<ExpandMoreIcon />}>
              <Typography fontWeight={600}>{section.title}</Typography>
            </AccordionSummary>
            <AccordionDetails>
              {Array.isArray(section.data) ? (
                section.data.length > 0 ? (
                  section.data.map((item, i) => (
                    <Box key={i} sx={{ mb: 2, p: 2, bgcolor: 'grey.50', borderRadius: 1 }}>
                      <Typography variant="caption" color="text.secondary">Item {i + 1}</Typography>
                      {Object.entries(item).map(([key, value]) => (
                        <Box key={key} sx={{ display: 'flex', py: 0.5 }}>
                          <Typography variant="body2" color="text.secondary" sx={{ minWidth: 150 }}>
                            {key}:
                          </Typography>
                          <Typography variant="body2">
                            {typeof value === 'object' ? JSON.stringify(value) : String(value || '-')}
                          </Typography>
                        </Box>
                      ))}
                    </Box>
                  ))
                ) : (
                  <Typography color="text.secondary" variant="body2">No items</Typography>
                )
              ) : (
                Object.entries(section.data || {}).map(([key, value]) => (
                  <Box key={key} sx={{ display: 'flex', py: 0.5, borderBottom: '1px solid', borderColor: 'divider' }}>
                    <Typography variant="body2" color="text.secondary" sx={{ minWidth: 180 }}>
                      {key}:
                    </Typography>
                    <Typography variant="body2">
                      {typeof value === 'object' ? JSON.stringify(value) : String(value || '-')}
                    </Typography>
                  </Box>
                ))
              )}
            </AccordionDetails>
          </Accordion>
        ))}
      </Box>
    );
  };

  return (
    <Box>
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" fontWeight={700} gutterBottom>Welcome Back</Typography>
        <Typography variant="body1" color="text.secondary">Manage your business account applications.</Typography>
      </Box>

      {/* Stats */}
      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr', md: 'repeat(4, 1fr)' }, gap: 3, mb: 4 }}>
        {statsData.map((stat, index) => (
          <Card key={index}>
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                <Box>
                  <Typography variant="body2" color="text.secondary">{stat.title}</Typography>
                  <Typography variant="h4" fontWeight={700}>{stat.value}</Typography>
                  <Chip label={stat.change} size="small" color={stat.change.startsWith('+') ? 'success' : 'error'} sx={{ mt: 1 }} />
                </Box>
                <Box sx={{ width: 48, height: 48, borderRadius: 2, bgcolor: 'primary.light', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  {stat.icon}
                </Box>
              </Box>
            </CardContent>
          </Card>
        ))}
      </Box>

      {/* Applications Table */}
      <Card>
        <CardContent>
          <Box sx={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between', gap: 2, mb: 3 }}>
            <Typography variant="h6" fontWeight={600}>Recent Applications</Typography>
            <Stack direction="row" spacing={2}>
              <TextField size="small" placeholder="Search..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)}
                InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon /></InputAdornment> }} />
              <Button variant="contained" startIcon={<AddIcon />} onClick={() => setOnboardingOpen(true)}>New Application</Button>
            </Stack>
          </Box>
          <TableContainer component={Paper} variant="outlined">
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Company Name</TableCell>
                  <TableCell>UEN</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell>Date</TableCell>
                  <TableCell align="right">Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {filteredDrafts.length === 0 ? (
                  <TableRow><TableCell colSpan={5} align="center" sx={{ py: 4 }}><Typography color="text.secondary">No applications found.</Typography></TableCell></TableRow>
                ) : filteredDrafts.map((draft) => (
                  <TableRow key={draft.id} hover>
                    <TableCell><Typography fontWeight={500}>{draft.businessDetails.registeredName || 'Unnamed'}</Typography></TableCell>
                    <TableCell>{draft.businessDetails.registrationNumber || '-'}</TableCell>
                    <TableCell><Chip label={draft.status} color={getStatusColor(draft.status)} size="small" /></TableCell>
                    <TableCell>{new Date(draft.updatedAt).toLocaleDateString()}</TableCell>
                    <TableCell align="right">
                      <IconButton size="small" onClick={() => navigate(`/view/${draft.id}`)} title="View">
                        <VisibilityIcon fontSize="small" />
                      </IconButton>
                      <IconButton size="small" onClick={() => handleEditDraft(draft)} color="primary" title="Edit & Continue">
                        <EditIcon fontSize="small" />
                      </IconButton>
                      <IconButton size="small" color="error" title="Delete">
                        <DeleteIcon fontSize="small" />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </CardContent>
      </Card>

      {/* Onboarding Dialog */}
      <Dialog 
        open={onboardingOpen} 
        onClose={() => { setOnboardingOpen(false); resetModal(); }} 
        maxWidth={step === 'preview' ? 'lg' : 'sm'} 
        fullWidth
      >
        <DialogTitle>
          <Typography variant="h5" fontWeight={600}>
            {step === 'choose' ? 'New Business Account Application' : 'Review Extracted Data'}
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>
            {step === 'choose' 
              ? 'Choose how you want to proceed with the application'
              : 'Edit the extracted JSON data before continuing'}
          </Typography>
        </DialogTitle>
        <DialogContent>
          {step === 'choose' && (
            <>
              {isUploading ? (
                <Box sx={{ py: 4 }}>
                  <Typography align="center" gutterBottom>{processingStatus}</Typography>
                  <LinearProgress variant="determinate" value={uploadProgress} sx={{ mt: 2 }} />
                </Box>
              ) : (
                <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' }, gap: 2, mt: 2 }}>
                  <Card sx={{ cursor: 'pointer', '&:hover': { borderColor: 'primary.main', boxShadow: 4 } }} onClick={handleOnlineApplication}>
                    <CardContent sx={{ textAlign: 'center', py: 4 }}>
                      <Box sx={{ width: 64, height: 64, borderRadius: 3, bgcolor: 'primary.light', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', mx: 'auto', mb: 2 }}>
                        <ComputerIcon sx={{ fontSize: 32 }} />
                      </Box>
                      <Typography variant="h6" fontWeight={600}>Online Application</Typography>
                      <Typography variant="body2" color="text.secondary">Fill out the form digitally</Typography>
                    </CardContent>
                  </Card>
                  <Card component="label" sx={{ cursor: 'pointer', '&:hover': { borderColor: 'primary.main', boxShadow: 4 } }}>
                    <input type="file" accept=".pdf" onChange={handleFileUpload} style={{ display: 'none' }} />
                    <CardContent sx={{ textAlign: 'center', py: 4 }}>
                      <Box sx={{ width: 64, height: 64, borderRadius: 3, bgcolor: 'secondary.light', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', mx: 'auto', mb: 2 }}>
                        <UploadFileIcon sx={{ fontSize: 32 }} />
                      </Box>
                      <Typography variant="h6" fontWeight={600}>Upload Scanned PDF</Typography>
                      <Typography variant="body2" color="text.secondary">Extract data from PDF</Typography>
                    </CardContent>
                  </Card>
                </Box>
              )}
            </>
          )}

          {step === 'preview' && extractedData && (
            <Box sx={{ mt: 2 }}>
              {/* Success message */}
              <Alert severity="success" icon={<CheckCircleIcon />} sx={{ mb: 2 }}>
                PDF data extracted successfully
                {ocrUsed && ' (OCR was used for scanned pages)'}
              </Alert>

              {/* Extraction summary */}
              {extractionSummary && (
                <Alert severity="info" sx={{ mb: 2 }}>
                  <Typography variant="body2" sx={{ whiteSpace: 'pre-line' }}>
                    {extractionSummary}
                  </Typography>
                </Alert>
              )}

              {/* Tabs for viewing/editing */}
              <Tabs value={viewTab} onChange={(_, v) => setViewTab(v)} sx={{ borderBottom: 1, borderColor: 'divider', mb: 2 }}>
                <Tab icon={<ListAltIcon />} iconPosition="start" label="Form View" />
                <Tab icon={<CodeIcon />} iconPosition="start" label="JSON Editor" />
                <Tab 
                  icon={<DrawIcon />} 
                  iconPosition="start" 
                  label={`Signatures (${extractedSignatures.length})`}
                  disabled={extractedSignatures.length === 0}
                />
              </Tabs>

              <TabPanel value={viewTab} index={0}>
                {renderFormFields(extractedData)}
              </TabPanel>

              <TabPanel value={viewTab} index={1}>
                <Box sx={{ position: 'relative' }}>
                  {jsonError && (
                    <Alert severity="error" sx={{ mb: 2 }}>{jsonError}</Alert>
                  )}
                  <TextField
                    multiline
                    fullWidth
                    rows={16}
                    value={jsonText}
                    onChange={(e) => handleJsonChange(e.target.value)}
                    sx={{
                      '& .MuiInputBase-root': {
                        fontFamily: 'monospace',
                        fontSize: '0.8rem',
                      },
                    }}
                  />
                </Box>
              </TabPanel>

              <TabPanel value={viewTab} index={2}>
                <Box>
                  {extractedSignatures.length === 0 ? (
                    <Alert severity="info">No signatures detected in the PDF</Alert>
                  ) : (
                    <>
                      <Alert severity="success" sx={{ mb: 2 }}>
                        {extractedSignatures.length} signature(s) detected and extracted. 
                        These have been automatically assigned to form fields.
                      </Alert>
                      <Box sx={{ 
                        display: 'grid', 
                        gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr', md: '1fr 1fr 1fr' }, 
                        gap: 2 
                      }}>
                        {extractedSignatures.map((sig, index) => (
                          <Card key={sig.id} variant="outlined">
                            <CardContent>
                              <Typography variant="subtitle2" gutterBottom>
                                Signature {index + 1}
                              </Typography>
                              <Typography variant="caption" color="text.secondary" display="block" gutterBottom>
                                Page {sig.pageNumber} • Confidence: {Math.round(sig.confidence * 100)}%
                              </Typography>
                              <Box
                                sx={{
                                  border: '1px solid',
                                  borderColor: 'divider',
                                  borderRadius: 1,
                                  bgcolor: 'grey.50',
                                  p: 1,
                                  display: 'flex',
                                  alignItems: 'center',
                                  justifyContent: 'center',
                                  minHeight: 80,
                                }}
                              >
                                <img
                                  src={sig.imageData}
                                  alt={`Signature ${index + 1}`}
                                  style={{
                                    maxWidth: '100%',
                                    maxHeight: 80,
                                    objectFit: 'contain',
                                  }}
                                />
                              </Box>
                              <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: 'block' }}>
                                Position: ({sig.bounds.x}, {sig.bounds.y}) • Size: {sig.bounds.width}x{sig.bounds.height}
                              </Typography>
                            </CardContent>
                          </Card>
                        ))}
                      </Box>
                    </>
                  )}
                </Box>
              </TabPanel>

              {/* Raw text accordion */}
              <Accordion sx={{ mt: 2 }}>
                <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                  <Typography variant="body2" color="text.secondary">View Raw Extracted Text</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <Box sx={{ maxHeight: 200, overflow: 'auto', bgcolor: 'grey.100', p: 2, borderRadius: 1 }}>
                    <Typography variant="body2" sx={{ fontFamily: 'monospace', fontSize: '0.75rem', whiteSpace: 'pre-wrap' }}>
                      {rawText || 'No text extracted'}
                    </Typography>
                  </Box>
                </AccordionDetails>
              </Accordion>
            </Box>
          )}
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 3 }}>
          {step === 'choose' ? (
            <Button onClick={() => { setOnboardingOpen(false); resetModal(); }}>Cancel</Button>
          ) : (
            <>
              <Button onClick={() => setStep('choose')}>Back</Button>
              <Box sx={{ flex: 1 }} />
              <Button 
                variant="outlined" 
                startIcon={<SaveIcon />} 
                onClick={handleSaveAsDraft}
                disabled={!!jsonError}
              >
                Save as Draft
              </Button>
              <Button 
                variant="contained" 
                startIcon={<EditIcon />} 
                onClick={handleSaveAndEdit}
                disabled={!!jsonError}
              >
                Edit & Continue
              </Button>
            </>
          )}
        </DialogActions>
      </Dialog>
    </Box>
  );
}
