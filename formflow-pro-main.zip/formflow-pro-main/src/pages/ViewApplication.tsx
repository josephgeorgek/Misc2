import { useParams, Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  ArrowLeft, 
  Building2, 
  User, 
  CreditCard, 
  FileText, 
  Users, 
  Edit3, 
  CheckCircle2, 
  Clock, 
  XCircle, 
  Printer,
  Globe,
  Monitor,
  Receipt,
  Bell,
  Wallet,
  PenLine
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { FormHeader } from '@/components/form/FormHeader';
import { format } from 'date-fns';
import { PDFExportButton } from '@/components/PDFExportButton';
import { ViewSignaturesSection } from '@/components/form/ViewSignaturesSection';
import { useApplicationStorage } from '@/hooks/useApplicationStorage';

const statusConfig = {
  draft: { label: 'Draft', icon: Edit3, className: 'bg-muted text-muted-foreground' },
  submitted: { label: 'Submitted', icon: Clock, className: 'bg-primary/10 text-primary' },
  approved: { label: 'Approved', icon: CheckCircle2, className: 'bg-success/10 text-success' },
  rejected: { label: 'Rejected', icon: XCircle, className: 'bg-destructive/10 text-destructive' },
};

function InfoRow({ label, value }: { label: string; value: string | boolean | null | undefined }) {
  const displayValue = typeof value === 'boolean' 
    ? (value ? 'Yes' : 'No') 
    : (value || '-');
  
  return (
    <div className="py-2">
      <dt className="text-sm text-muted-foreground">{label}</dt>
      <dd className="font-medium">{displayValue}</dd>
    </div>
  );
}

function Section({ title, icon: Icon, children }: { title: string; icon: React.ElementType; children: React.ReactNode }) {
  return (
    <Card className="overflow-hidden">
      <CardHeader className="bg-muted/50 border-b border-border">
        <CardTitle className="flex items-center gap-2 text-lg">
          <Icon className="w-5 h-5 text-primary" />
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-4">
        {children}
      </CardContent>
    </Card>
  );
}

export default function ViewApplication() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { application, isLoading, saveSignatures } = useApplicationStorage(id);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <FormHeader />
        <main className="container max-w-4xl mx-auto px-4 py-16 text-center">
          <p className="text-muted-foreground">Loading application...</p>
        </main>
      </div>
    );
  }

  if (!application) {
    return (
      <div className="min-h-screen bg-background">
        <FormHeader />
        <main className="container max-w-4xl mx-auto px-4 py-16 text-center">
          <h1 className="text-2xl font-bold mb-4">Application Not Found</h1>
          <p className="text-muted-foreground mb-6">The application you're looking for doesn't exist.</p>
          <Button asChild>
            <Link to="/">Back to Dashboard</Link>
          </Button>
        </main>
      </div>
    );
  }

  const status = statusConfig[application.status];
  const StatusIcon = status.icon;

  return (
    <div className="min-h-screen bg-background">
      <FormHeader />
      
      <main className="container max-w-4xl mx-auto px-4 py-6 md:py-10">
        {/* Back & Actions */}
        <motion.div 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between gap-4 mb-6"
        >
          <Button variant="ghost" size="sm" onClick={() => navigate('/')}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
          <div className="flex items-center gap-2">
            <PDFExportButton formData={application} />
            <Button variant="outline" size="sm" onClick={() => window.print()}>
              <Printer className="w-4 h-4 mr-2" />
              Print
            </Button>
            {application.status === 'draft' && (
              <Button asChild size="sm">
                <Link to={`/edit/${application.id}`}>
                  <Edit3 className="w-4 h-4 mr-2" />
                  Edit Application
                </Link>
              </Button>
            )}
          </div>
        </motion.div>

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold font-display">
                {application.businessDetails.registeredName}
              </h1>
              <p className="text-muted-foreground mt-1">
                Application ID: {application.id}
              </p>
            </div>
            <Badge className={`${status.className} text-sm px-3 py-1`}>
              <StatusIcon className="w-4 h-4 mr-1.5" />
              {status.label}
            </Badge>
          </div>
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <span>Created: {format(new Date(application.createdAt), 'MMM d, yyyy')}</span>
            <span>•</span>
            <span>Updated: {format(new Date(application.updatedAt), 'MMM d, yyyy')}</span>
          </div>
        </motion.div>

        {/* Content */}
        <div className="space-y-6">
          {/* Business Details */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
            <Section title="Business Details" icon={Building2}>
              <div className="grid md:grid-cols-2 gap-x-8 gap-y-1">
                <InfoRow label="Registered Name" value={application.businessDetails.registeredName} />
                <InfoRow label="Registration Number (UEN)" value={application.businessDetails.registrationNumber} />
                <InfoRow label="Business Type" value={application.businessDetails.businessType} />
                <InfoRow label="Nature of Business" value={application.businessDetails.natureOfBusiness} />
                <InfoRow label="Country of Domicile" value={application.businessDetails.countryOfDomicile} />
                <InfoRow label="GST Registered" value={application.businessDetails.gstRegistered} />
                <InfoRow label="Office Number" value={application.businessDetails.officeNumber} />
                <InfoRow label="Fax Number" value={application.businessDetails.faxNumber} />
              </div>
            </Section>
          </motion.div>

          {/* Contact Persons */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}>
            <Section title="Contact Persons" icon={User}>
              <div className="grid md:grid-cols-2 gap-8">
                <div>
                  <h4 className="font-semibold mb-3 text-primary">Primary Contact</h4>
                  <div className="space-y-1">
                    <InfoRow label="Full Name" value={application.primaryContact.fullName} />
                    <InfoRow label="NRIC/Passport" value={application.primaryContact.nricPassport} />
                    <InfoRow label="Email" value={application.primaryContact.email} />
                    <InfoRow label="Mobile" value={application.primaryContact.mobileNumber} />
                    <InfoRow label="Office" value={application.primaryContact.officeNumber} />
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold mb-3 text-primary">Secondary Contact</h4>
                  <div className="space-y-1">
                    <InfoRow label="Full Name" value={application.secondaryContact.fullName} />
                    <InfoRow label="NRIC/Passport" value={application.secondaryContact.nricPassport} />
                    <InfoRow label="Email" value={application.secondaryContact.email} />
                    <InfoRow label="Mobile" value={application.secondaryContact.mobileNumber} />
                    <InfoRow label="Office" value={application.secondaryContact.officeNumber} />
                  </div>
                </div>
              </div>
            </Section>
          </motion.div>

          {/* Account Type */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
            <Section title="Account Type" icon={CreditCard}>
              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-2">SGD Accounts</h4>
                  <div className="flex flex-wrap gap-2">
                    {application.accountType.sgdAccounts.length > 0 ? (
                      application.accountType.sgdAccounts.map((account) => (
                        <Badge key={account} variant="outline">{account}</Badge>
                      ))
                    ) : (
                      <span className="text-muted-foreground">None selected</span>
                    )}
                  </div>
                </div>
                <Separator />
                <div>
                  <h4 className="font-semibold mb-2">Foreign Currency Accounts</h4>
                  <div className="flex flex-wrap gap-2">
                    {application.accountType.foreignCurrencyAccounts.length > 0 ? (
                      application.accountType.foreignCurrencyAccounts.map((account) => (
                        <Badge key={account} variant="outline">{account}</Badge>
                      ))
                    ) : (
                      <span className="text-muted-foreground">None selected</span>
                    )}
                  </div>
                </div>
                {application.accountType.currencies.length > 0 && (
                  <>
                    <Separator />
                    <div>
                      <h4 className="font-semibold mb-2">Selected Currencies</h4>
                      <div className="flex flex-wrap gap-2">
                        {application.accountType.currencies.map((currency) => (
                          <Badge key={currency} variant="secondary">{currency}</Badge>
                        ))}
                      </div>
                    </div>
                  </>
                )}
              </div>
            </Section>
          </motion.div>

          {/* Account Particulars */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 }}>
            <Section title="Account Particulars" icon={Wallet}>
              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-2">Source of Capital</h4>
                  <div className="flex flex-wrap gap-2">
                    {application.accountParticulars.sourceOfCapital.map((source) => (
                      <Badge key={source} variant="outline">{source}</Badge>
                    ))}
                  </div>
                </div>
                <Separator />
                <div className="grid md:grid-cols-2 gap-x-8 gap-y-1">
                  <InfoRow label="Account Name" value={application.accountParticulars.accountName} />
                  <InfoRow label="Mailing Address" value={application.accountParticulars.mailingAddress} />
                  <InfoRow label="PayNow Sign-up" value={application.accountParticulars.payNowSignUp} />
                  <InfoRow label="SGQR Sign-up" value={application.accountParticulars.sgqrSignUp} />
                  {application.accountParticulars.sgqrSignUp && (
                    <>
                      <InfoRow label="SGQR Option" value={application.accountParticulars.sgqrOption} />
                    </>
                  )}
                </div>
                {application.accountParticulars.sgqrSignUp && application.accountParticulars.outlets.length > 0 && (
                  <>
                    <Separator />
                    <div>
                      <h4 className="font-semibold mb-2">SGQR Outlets</h4>
                      <div className="space-y-2">
                        {application.accountParticulars.outlets.filter(o => o.outletName).map((outlet, idx) => (
                          <div key={idx} className="p-3 rounded-lg bg-muted/50">
                            <p className="font-medium">{outlet.outletName}</p>
                            <p className="text-sm text-muted-foreground">
                              Postal Code: {outlet.postalCode} | Level/Unit: {outlet.levelUnit}
                            </p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </>
                )}
              </div>
            </Section>
          </motion.div>

          {/* Beneficial Owners */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
            <Section title="Beneficial Owners & Signatories" icon={Users}>
              <div className="space-y-4">
                {application.beneficialOwners.map((owner, index) => (
                  <div key={owner.id}>
                    {index > 0 && <Separator className="my-4" />}
                    <div className="flex items-center gap-2 mb-3">
                      <h4 className="font-semibold">Person {index + 1}: {owner.fullName}</h4>
                      <div className="flex gap-1">
                        {owner.isBeneficialOwner && (
                          <Badge variant="secondary" className="text-xs">Beneficial Owner</Badge>
                        )}
                        {owner.isAuthorisedSignatory && (
                          <Badge variant="outline" className="text-xs">Signatory</Badge>
                        )}
                        {owner.grouping && (
                          <Badge variant="default" className="text-xs">Group {owner.grouping}</Badge>
                        )}
                      </div>
                    </div>
                    <div className="grid md:grid-cols-2 gap-x-8 gap-y-1">
                      <InfoRow label="NRIC/Passport" value={owner.nricPassport} />
                      <InfoRow label="Designation" value={owner.designation} />
                      <InfoRow label="Email" value={owner.email} />
                      <InfoRow label="Mobile" value={owner.mobileNumber} />
                      <InfoRow label="Office" value={owner.officeNumber} />
                    </div>
                  </div>
                ))}
                <Separator className="my-4" />
                <div>
                  <h4 className="font-semibold mb-2">Signing Condition</h4>
                  <p className="text-muted-foreground">
                    {application.signingCondition.type === 'singly' && 'Any signatory may sign singly'}
                    {application.signingCondition.type === 'anyTwo' && 'Any two signatories to sign jointly'}
                    {application.signingCondition.type === 'grouping' && application.signingCondition.details}
                  </p>
                  <InfoRow label="Apply to All Accounts" value={application.signingCondition.applyToAllAccounts} />
                </div>
              </div>
            </Section>
          </motion.div>

          {/* Board Resolution */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.35 }}>
            <Section title="Board Resolution" icon={FileText}>
              <div className="space-y-4">
                <div className="grid md:grid-cols-2 gap-x-8 gap-y-1">
                  <InfoRow label="Company Name" value={application.boardResolution.companyName} />
                  <InfoRow label="Meeting Date" value={application.boardResolution.meetingDate} />
                  <InfoRow label="Resolution Passed" value={application.boardResolution.resolutionPassed} />
                  <InfoRow label="Company Secretary" value={application.boardResolution.companySecretaryName} />
                  <InfoRow label="Certification Date" value={application.boardResolution.certificationDate} />
                </div>
                <Separator />
                <div>
                  <h4 className="font-semibold mb-2">Authorised Activities</h4>
                  <div className="flex flex-wrap gap-2">
                    {application.boardResolution.openCloseAccounts && <Badge variant="outline">Open/Close Accounts</Badge>}
                    {application.boardResolution.applyBankingServices && <Badge variant="outline">Apply Banking Services</Badge>}
                    {application.boardResolution.appointAuthorisedUsers && <Badge variant="outline">Appoint Users</Badge>}
                    {application.boardResolution.appointAuthorisedSignatories && <Badge variant="outline">Appoint Signatories</Badge>}
                    {application.boardResolution.borrowingAndSecurity && <Badge variant="outline">Borrowing & Security</Badge>}
                    {application.boardResolution.corporateCreditCard && <Badge variant="outline">Corporate Credit Card</Badge>}
                    {application.boardResolution.electronicSigning && <Badge variant="outline">Electronic Signing</Badge>}
                  </div>
                </div>
                {application.boardResolution.authorisedPersons.length > 0 && (
                  <>
                    <Separator />
                    <div>
                      <h4 className="font-semibold mb-2">Authorised Persons</h4>
                      <div className="space-y-2">
                        {application.boardResolution.authorisedPersons.map((person, idx) => (
                          <div key={person.id || idx} className="p-2 rounded bg-muted/50">
                            <p className="font-medium">{person.fullName}</p>
                            <p className="text-sm text-muted-foreground">{person.designation} • {person.nricPassport}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </>
                )}
                <Separator />
                <div className="grid md:grid-cols-2 gap-x-8 gap-y-1">
                  <InfoRow label="Signing Mandate" value={application.boardResolution.signingMandate} />
                  <InfoRow label="Signing Limits" value={application.boardResolution.signingLimits} />
                </div>
              </div>
            </Section>
          </motion.div>

          {/* Tax Declaration */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
            <Section title="Tax Declaration (FATCA/CRS)" icon={Globe}>
              <div className="space-y-4">
                <div className="grid md:grid-cols-2 gap-x-8 gap-y-1">
                  <InfoRow label="Entity Name" value={application.taxDeclarationEntity.registeredName} />
                  <InfoRow label="Registration No." value={application.taxDeclarationEntity.registrationNumber} />
                  <InfoRow label="Registered Address" value={application.taxDeclarationEntity.registeredAddress} />
                  <InfoRow label="Country" value={application.taxDeclarationEntity.country} />
                  <InfoRow label="Postal Code" value={application.taxDeclarationEntity.postalCode} />
                  <InfoRow 
                    label="Entity Type" 
                    value={application.taxDeclarationEntity.entityType === 'financialInstitution' ? 'Financial Institution' : 'Non-Financial Institution'} 
                  />
                  {application.taxDeclarationEntity.entityType === 'notFinancialInstitution' && (
                    <InfoRow label="Non-FI Type" value={application.taxDeclarationEntity.nonFIType} />
                  )}
                  <InfoRow label="FATCA Status" value={application.taxDeclarationEntity.fatcaStatus} />
                  <InfoRow label="CRS Status" value={application.taxDeclarationEntity.crsStatus} />
                </div>
                {application.taxDeclarationEntity.taxResidencies.length > 0 && (
                  <>
                    <Separator />
                    <div>
                      <h4 className="font-semibold mb-2">Tax Residencies</h4>
                      <div className="space-y-2">
                        {application.taxDeclarationEntity.taxResidencies.map((tax, idx) => (
                          <div key={tax.id || idx} className="p-2 rounded bg-muted/50">
                            <p className="font-medium">{tax.country}</p>
                            <p className="text-sm text-muted-foreground">TIN: {tax.tin || 'Not provided'}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </>
                )}
                {application.taxDeclarationEntity.controllingPersons.length > 0 && (
                  <>
                    <Separator />
                    <div>
                      <h4 className="font-semibold mb-2">Controlling Persons</h4>
                      <div className="space-y-2">
                        {application.taxDeclarationEntity.controllingPersons.map((person, idx) => (
                          <div key={person.id || idx} className="p-2 rounded bg-muted/50">
                            <p className="font-medium">{person.fullName}</p>
                            <p className="text-sm text-muted-foreground">
                              {person.nricPassport} • {person.countryOfBirth} • {person.controllingPersonType}
                            </p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </>
                )}
              </div>
            </Section>
          </motion.div>

          {/* Business Banking Services */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.45 }}>
            <Section title="Business Banking Services (Velocity)" icon={Monitor}>
              <div className="space-y-4">
                <InfoRow label="Apply for OCBC Velocity" value={application.businessBankingServices.applyForVelocity} />
                {application.businessBankingServices.applyForVelocity && (
                  <>
                    <Separator />
                    <div className="grid md:grid-cols-2 gap-x-8 gap-y-1">
                      <InfoRow label="Organisation ID" value={application.businessBankingServices.organisationId} />
                      <InfoRow label="Contact Person" value={application.businessBankingServices.contactPersonName} />
                      <InfoRow label="Contact Email" value={application.businessBankingServices.contactPersonEmail} />
                      <InfoRow label="Contact Mobile" value={application.businessBankingServices.contactPersonMobile} />
                      <InfoRow label="Service Package" value={application.businessBankingServices.servicePackage} />
                      <InfoRow 
                        label="2FA Method" 
                        value={application.businessBankingServices.twoFactorMethod === 'digital' ? 'Digital Token' : 'Hardware Token'} 
                      />
                      <InfoRow label="e-Statement Enabled" value={application.businessBankingServices.eStatementEnabled} />
                      <InfoRow label="Link All Trade Accounts" value={application.businessBankingServices.linkAllTradeAccounts} />
                    </div>
                    {application.businessBankingServices.velocityUsers.length > 0 && (
                      <>
                        <Separator />
                        <div>
                          <h4 className="font-semibold mb-2">Velocity Users</h4>
                          <div className="space-y-2">
                            {application.businessBankingServices.velocityUsers.map((user, idx) => (
                              <div key={user.id || idx} className="p-2 rounded bg-muted/50">
                                <p className="font-medium">{user.fullName}</p>
                                <p className="text-sm text-muted-foreground">
                                  {user.role} • {user.email} • User ID: {user.userId}
                                </p>
                              </div>
                            ))}
                          </div>
                        </div>
                      </>
                    )}
                  </>
                )}
              </div>
            </Section>
          </motion.div>

          {/* Debit Card */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}>
            <Section title="Business Debit Card" icon={CreditCard}>
              <div className="space-y-4">
                <InfoRow label="Apply for Debit Card" value={application.businessDebitCard.applyForDebitCard} />
                {application.businessDebitCard.applyForDebitCard && (
                  <>
                    <Separator />
                    <div className="grid md:grid-cols-2 gap-x-8 gap-y-1">
                      <InfoRow label="Linked Account Number" value={application.businessDebitCard.linkedAccountNumber || 'New Account'} />
                      <InfoRow label="New Account" value={application.businessDebitCard.isNewAccount} />
                    </div>
                    {application.businessDebitCard.cardholders.length > 0 && (
                      <>
                        <Separator />
                        <div>
                          <h4 className="font-semibold mb-2">Cardholders</h4>
                          <div className="space-y-2">
                            {application.businessDebitCard.cardholders.map((holder, idx) => (
                              <div key={holder.id || idx} className="p-3 rounded bg-muted/50">
                                <p className="font-medium">{holder.fullName}</p>
                                <p className="text-sm text-muted-foreground">
                                  Name on Card: {holder.nameOnCard} • {holder.email}
                                </p>
                                <p className="text-sm text-muted-foreground">
                                  NETS ATM Limit: ${holder.netsAtmLimit} • NETS Payment Limit: ${holder.netsPaymentLimit}
                                </p>
                              </div>
                            ))}
                          </div>
                        </div>
                      </>
                    )}
                  </>
                )}
              </div>
            </Section>
          </motion.div>

          {/* GIRO & eAlerts */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.55 }}>
            <Section title="GIRO Application" icon={Receipt}>
              <div className="space-y-4">
                <InfoRow label="Apply for GIRO" value={application.giroApplication.applyForGIRO} />
                {application.giroApplication.applyForGIRO && (
                  <>
                    <Separator />
                    <div className="grid md:grid-cols-2 gap-x-8 gap-y-1">
                      <InfoRow label="Debit Account Number" value={application.giroApplication.debitAccountNumber} />
                    </div>
                    {application.giroApplication.billingOrganizations.length > 0 && (
                      <>
                        <Separator />
                        <div>
                          <h4 className="font-semibold mb-2">Billing Organizations</h4>
                          <div className="space-y-2">
                            {application.giroApplication.billingOrganizations.map((org, idx) => (
                              <div key={org.id || idx} className="p-2 rounded bg-muted/50">
                                <p className="font-medium">{org.organizationName}</p>
                                <p className="text-sm text-muted-foreground">
                                  Type: {org.type} • Account: {org.accountNumber}
                                </p>
                              </div>
                            ))}
                          </div>
                        </div>
                      </>
                    )}
                  </>
                )}
              </div>
            </Section>
          </motion.div>

          {/* eAlerts */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }}>
            <Section title="eAlerts" icon={Bell}>
              <div className="space-y-4">
                <InfoRow label="Apply for eAlerts" value={application.eAlerts.applyForEAlerts} />
                {application.eAlerts.applyForEAlerts && (
                  <>
                    <InfoRow label="Linked Account Number" value={application.eAlerts.linkedAccountNumber} />
                    {application.eAlerts.alertUsers.length > 0 && (
                      <>
                        <Separator />
                        <div>
                          <h4 className="font-semibold mb-2">Alert Users</h4>
                          <div className="space-y-2">
                            {application.eAlerts.alertUsers.map((user, idx) => (
                              <div key={user.id || idx} className="p-2 rounded bg-muted/50">
                                <p className="font-medium">{user.name}</p>
                                <p className="text-sm text-muted-foreground">
                                  {user.deliveryMethod.toUpperCase()} • Language: {user.language} • 
                                  Per Transaction: ${user.perTransactionThreshold} • Cumulative: ${user.cumulativeThreshold}
                                </p>
                              </div>
                            ))}
                          </div>
                        </div>
                      </>
                    )}
                  </>
                )}
              </div>
            </Section>
          </motion.div>

          {/* Agreement */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.65 }}>
            <Section title="Agreement & Declaration" icon={CheckCircle2}>
              <div className="space-y-4">
                <div className="grid md:grid-cols-2 gap-x-8 gap-y-1">
                  <InfoRow label="Agree to Terms" value={application.agreement.agreeToTerms} />
                  <InfoRow label="Agree to Data Protection" value={application.agreement.agreeToDataProtection} />
                  <InfoRow label="Agree to FATCA" value={application.agreement.agreeToFATCA} />
                  <InfoRow label="Agree to CRS" value={application.agreement.agreeToCRS} />
                  <InfoRow label="Signature Date" value={application.agreement.signatureDate} />
                </div>
              </div>
            </Section>
          </motion.div>

          {/* Editable Signatures Section */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.7 }}>
            <ViewSignaturesSection
              signatures={application.agreement.agreementSignatures}
              onSave={saveSignatures}
              title="Authorized Signatures"
              disabled={application.status === 'approved'}
            />
          </motion.div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border mt-12 py-6">
        <div className="container max-w-4xl mx-auto px-4">
          <p className="text-sm text-muted-foreground text-center">
            © 2025 Business Banking Services. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}