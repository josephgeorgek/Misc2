export interface BusinessDetails {
  registeredName: string;
  registrationNumber: string;
  officeNumber: string;
  faxNumber: string;
  natureOfBusiness: string;
  gstRegistered: boolean | null;
  countryOfDomicile: string;
  businessType: string;
}

export interface ContactPerson {
  nricPassport: string;
  fullName: string;
  email: string;
  mobileNumber: string;
  officeNumber: string;
}

export interface AccountType {
  sgdAccounts: string[];
  foreignCurrencyAccounts: string[];
  currencies: string[];
}

export interface SGQROutlet {
  outletName: string;
  sgqrId: string;
  postalCode: string;
  levelUnit: string;
  terminalId: string;
  referenceNo: string;
}

export interface AccountParticulars {
  sourceOfCapital: string[];
  accountName: string;
  mailingAddress: string;
  payNowSignUp: boolean;
  sgqrSignUp: boolean;
  sgqrOption: 'create' | 'update' | 'none';
  outlets: SGQROutlet[];
  // Legacy fields for backwards compatibility
  outletName1: string;
  outletName2: string;
}

export interface BeneficialOwner {
  id: string;
  fullName: string;
  nricPassport: string;
  designation: string;
  isBeneficialOwner: boolean;
  isAuthorisedSignatory: boolean;
  mobileNumber: string;
  officeNumber: string;
  email: string;
  grouping: string;
  signature: string;
}

export interface SigningCondition {
  type: 'singly' | 'anyTwo' | 'grouping';
  details: string;
  applyToAllAccounts: boolean;
}

// Board Resolution types
export interface BoardResolution {
  companyName: string;
  meetingDate: string;
  resolutionPassed: boolean;
  // Authorized activities
  openCloseAccounts: boolean;
  applyBankingServices: boolean;
  appointAuthorisedUsers: boolean;
  appointAuthorisedSignatories: boolean;
  borrowingAndSecurity: boolean;
  corporateCreditCard: boolean;
  electronicSigning: boolean;
  // Schedule of Authorised Persons
  authorisedPersons: AuthorisedPerson[];
  signingMandate: string;
  signingLimits: string;
  // Signatures
  directorSignatures: DirectorSignature[];
  companySecretarySignature: string;
  companySecretaryName: string;
  certificationDate: string;
}

export interface AuthorisedPerson {
  id: string;
  fullName: string;
  nricPassport: string;
  designation: string;
  signature: string;
}

export interface DirectorSignature {
  id: string;
  name: string;
  signature: string;
  date: string;
}

// Tax Declaration - Entity
export interface TaxDeclarationEntity {
  registeredName: string;
  registrationNumber: string;
  registeredAddress: string;
  country: string;
  postalCode: string;
  // Entity Type
  entityType: 'notFinancialInstitution' | 'financialInstitution';
  // FATCA/CRS Status for non-FI
  nonFIType: 'activeBusiness' | 'publicSector' | 'publiclyListed' | 'passiveInvestment' | 'other';
  fatcaStatus: string;
  crsStatus: string;
  // For publicly listed
  securitiesMarketName: string;
  entityNameOnMarket: string;
  // Financial Institution options
  fiType: 'depository' | 'investmentNonParticipating' | 'investmentOther' | 'trustNotManaged';
  // Tax residency
  taxResidencies: TaxResidency[];
  // Controlling persons (for passive entities)
  controllingPersons: ControllingPerson[];
  // Agreement
  declarationDate: string;
  declarationSignature: string;
}

export interface TaxResidency {
  id: string;
  country: string;
  tin: string;
  noTinReason: 'notIssued' | 'notRequired' | 'other';
  noTinExplanation: string;
}

export interface ControllingPerson {
  id: string;
  fullName: string;
  nricPassport: string;
  dateOfBirth: string;
  countryOfBirth: string;
  residentialAddress: string;
  country: string;
  postalCode: string;
  taxResidencies: TaxResidency[];
  controllingPersonType: string;
}

// Tax Declaration - Individual (for Sole Proprietorship)
export interface TaxDeclarationIndividual {
  fullName: string;
  nricPassport: string;
  countryOfBirth: string;
  dateOfBirth: string;
  residentialAddress: string;
  country: string;
  postalCode: string;
  // US Tax documents if applicable
  hasUSCertificateLossNationality: boolean;
  hasFormI407: boolean;
  // Tax residency
  isSingaporeTaxResident: boolean;
  singaporeTin: string;
  isUSTaxResident: boolean;
  usTin: string;
  taxResidencies: TaxResidency[];
  // Indicators of other tax residency
  residentialAddressIndicator: string;
  mailingAddressIndicator: string;
  registeredAddressIndicator: string;
  domicileIndicator: string;
  // Agreement
  declarationDate: string;
  declarationSignature: string;
}

// Business Banking Services (OCBC Velocity)
export interface BusinessBankingServices {
  registeredName: string;
  registrationNumber: string;
  // OCBC Velocity
  applyForVelocity: boolean;
  debitAccountForToken: string;
  // Contact Person
  contactPersonName: string;
  contactPersonOfficeNumber: string;
  contactPersonMobile: string;
  contactPersonEmail: string;
  // Organisation ID
  organisationId: string;
  // Accounts to link
  linkedAccounts: LinkedAccount[];
  linkAllTradeAccounts: boolean;
  // e-Statement
  eStatementEnabled: boolean;
  // Service Package
  servicePackage: 'basic' | 'standard' | 'classic';
  // Authorised Users
  velocityUsers: VelocityUser[];
  // 2FA
  twoFactorMethod: 'digital' | 'hardware';
  // Signing configuration for Classic package
  classicSigningMode: 'single' | 'dual';
  // Approval workflow
  approvalMatrix: ApprovalMatrix;
  // Custom roles
  customRoles: CustomRole[];
}

export interface LinkedAccount {
  id: string;
  accountNumber: string;
  currency: string;
}

export interface VelocityUser {
  id: string;
  fullName: string;
  nricPassport: string;
  idType: 'nric' | 'passport';
  idIssueCountry: string;
  userId: string;
  mobileNumber: string;
  email: string;
  // Permissions
  canViewStatement: boolean;
  canCreateTransactions: boolean;
  canApproveTransactions: boolean;
  canBookFX: boolean;
  role: 'viewer' | 'maker' | 'authoriser' | 'makerAuthoriser' | 'custom';
  // Custom role configuration
  customRoleName: string;
  // Transaction types user can make
  transactionTypes: TransactionTypePermissions;
}

export interface TransactionTypePermissions {
  localTransfers: boolean;
  payNow: boolean;
  giro: boolean;
  telegraphicTransfers: boolean;
  billPayments: boolean;
  bulkPayments: boolean;
  payrollPayments: boolean;
  tradeServices: boolean;
  fxConversions: boolean;
}

export interface ApprovalMatrix {
  approvalType: 'single' | 'dual' | 'matrix';
  singleApproverThreshold: string;
  dualApproverThreshold: string;
  matrixRules: ApprovalMatrixRule[];
}

export interface ApprovalMatrixRule {
  id: string;
  transactionType: string;
  amountFrom: string;
  amountTo: string;
  requiredApprovers: number;
  approverGrouping: string;
}

export interface CustomRole {
  id: string;
  roleName: string;
  description: string;
  capabilities: RoleCapabilities;
}

export interface RoleCapabilities {
  viewStatements: boolean;
  viewTransactionHistory: boolean;
  createLocalTransfers: boolean;
  createInternationalTransfers: boolean;
  createPayNow: boolean;
  createGiro: boolean;
  createBillPayments: boolean;
  createBulkPayments: boolean;
  createPayroll: boolean;
  approveTransactions: boolean;
  approveWithLimit: boolean;
  approvalLimit: string;
  manageUsers: boolean;
  manageAccounts: boolean;
  bookFX: boolean;
  downloadReports: boolean;
}

// Business Debit Card
export interface BusinessDebitCard {
  applyForDebitCard: boolean;
  registeredName: string;
  registrationNumber: string;
  linkedAccountNumber: string;
  isNewAccount: boolean;
  cardholders: Cardholder[];
}

export interface Cardholder {
  id: string;
  fullName: string;
  title: 'Dr' | 'Mr' | 'Mrs' | 'Ms' | 'Mdm';
  dateOfBirth: string;
  nricNumber: string;
  passportNumber: string;
  passportCountry: string;
  residentialAddress: string;
  postalCode: string;
  nationality: 'singaporean' | 'singaporeanPR' | 'foreigner';
  nationalityCountry: string;
  email: string;
  occupation: 'salesExecutive' | 'director' | 'generalManager' | 'financialOfficer' | 'other';
  occupationOther: string;
  mobileNumber: string;
  // Daily limits
  netsAtmLimit: string;
  netsPaymentLimit: string;
  // Name on card
  nameOnCard: string;
  // Signature
  signature: string;
}

// GIRO Application
export interface GIROApplication {
  applyForGIRO: boolean;
  registeredName: string;
  registrationNumber: string;
  debitAccountNumber: string;
  // Billing Organizations
  billingOrganizations: BillingOrganization[];
  // Authorised signatures
  signatures: GIROSignature[];
}

export interface BillingOrganization {
  id: string;
  type: 'government' | 'telecom' | 'insurance';
  organizationName: string;
  accountNumber: string;
  policyNumber: string;
}

export interface GIROSignature {
  id: string;
  name: string;
  signature: string;
  date: string;
}

// eAlerts
export interface EAlerts {
  applyForEAlerts: boolean;
  linkedAccountNumber: string;
  alertUsers: AlertUser[];
}

export interface AlertUser {
  id: string;
  name: string;
  nricPassport: string;
  language: 'english' | 'chinese';
  deliveryMethod: 'sms' | 'email';
  // Thresholds
  perTransactionThreshold: '300' | '500' | '1000';
  cumulativeThreshold: '5000' | '20000' | '50000';
}

// Main Agreement
export interface Agreement {
  agreeToTerms: boolean;
  agreeToDataProtection: boolean;
  agreeToFATCA: boolean;
  agreeToCRS: boolean;
  signatureDate: string;
  // Authorized signatories
  agreementSignatures: AgreementSignature[];
}

export interface AgreementSignature {
  id: string;
  name: string;
  signature: string;
  date: string;
}

export interface FormData {
  businessDetails: BusinessDetails;
  primaryContact: ContactPerson;
  secondaryContact: ContactPerson;
  accountType: AccountType;
  accountParticulars: AccountParticulars;
  beneficialOwners: BeneficialOwner[];
  signingCondition: SigningCondition;
  // New sections from full PDF
  boardResolution: BoardResolution;
  taxDeclarationEntity: TaxDeclarationEntity;
  taxDeclarationIndividual: TaxDeclarationIndividual;
  businessBankingServices: BusinessBankingServices;
  businessDebitCard: BusinessDebitCard;
  giroApplication: GIROApplication;
  eAlerts: EAlerts;
  agreement: Agreement;
  // Legacy
  agreeToTerms: boolean;
}

// Default empty SGQR outlet
const emptyOutlet: SGQROutlet = {
  outletName: '',
  sgqrId: '',
  postalCode: '',
  levelUnit: '',
  terminalId: '',
  referenceNo: '',
};

// Default empty tax residency
const emptyTaxResidency: TaxResidency = {
  id: '',
  country: '',
  tin: '',
  noTinReason: 'notIssued',
  noTinExplanation: '',
};

export const initialFormData: FormData = {
  businessDetails: {
    registeredName: '',
    registrationNumber: '',
    officeNumber: '',
    faxNumber: '',
    natureOfBusiness: '',
    gstRegistered: null,
    countryOfDomicile: 'Singapore',
    businessType: '',
  },
  primaryContact: {
    nricPassport: '',
    fullName: '',
    email: '',
    mobileNumber: '',
    officeNumber: '',
  },
  secondaryContact: {
    nricPassport: '',
    fullName: '',
    email: '',
    mobileNumber: '',
    officeNumber: '',
  },
  accountType: {
    sgdAccounts: [],
    foreignCurrencyAccounts: [],
    currencies: [],
  },
  accountParticulars: {
    sourceOfCapital: [],
    accountName: '',
    mailingAddress: '',
    payNowSignUp: true,
    sgqrSignUp: true,
    sgqrOption: 'create',
    outlets: [{ ...emptyOutlet }, { ...emptyOutlet }],
    outletName1: '',
    outletName2: '',
  },
  beneficialOwners: [],
  signingCondition: {
    type: 'singly',
    details: '',
    applyToAllAccounts: true,
  },
  boardResolution: {
    companyName: '',
    meetingDate: '',
    resolutionPassed: false,
    openCloseAccounts: true,
    applyBankingServices: true,
    appointAuthorisedUsers: true,
    appointAuthorisedSignatories: true,
    borrowingAndSecurity: false,
    corporateCreditCard: false,
    electronicSigning: false,
    authorisedPersons: [],
    signingMandate: '',
    signingLimits: '',
    directorSignatures: [],
    companySecretarySignature: '',
    companySecretaryName: '',
    certificationDate: '',
  },
  taxDeclarationEntity: {
    registeredName: '',
    registrationNumber: '',
    registeredAddress: '',
    country: 'Singapore',
    postalCode: '',
    entityType: 'notFinancialInstitution',
    nonFIType: 'activeBusiness',
    fatcaStatus: '',
    crsStatus: '',
    securitiesMarketName: '',
    entityNameOnMarket: '',
    fiType: 'depository',
    taxResidencies: [],
    controllingPersons: [],
    declarationDate: '',
    declarationSignature: '',
  },
  taxDeclarationIndividual: {
    fullName: '',
    nricPassport: '',
    countryOfBirth: '',
    dateOfBirth: '',
    residentialAddress: '',
    country: 'Singapore',
    postalCode: '',
    hasUSCertificateLossNationality: false,
    hasFormI407: false,
    isSingaporeTaxResident: true,
    singaporeTin: '',
    isUSTaxResident: false,
    usTin: '',
    taxResidencies: [],
    residentialAddressIndicator: '',
    mailingAddressIndicator: '',
    registeredAddressIndicator: '',
    domicileIndicator: '',
    declarationDate: '',
    declarationSignature: '',
  },
  businessBankingServices: {
    registeredName: '',
    registrationNumber: '',
    applyForVelocity: false,
    debitAccountForToken: '',
    contactPersonName: '',
    contactPersonOfficeNumber: '',
    contactPersonMobile: '',
    contactPersonEmail: '',
    organisationId: '',
    linkedAccounts: [],
    linkAllTradeAccounts: false,
    eStatementEnabled: true,
    servicePackage: 'standard',
    velocityUsers: [],
    twoFactorMethod: 'digital',
    classicSigningMode: 'dual',
    approvalMatrix: {
      approvalType: 'single',
      singleApproverThreshold: '',
      dualApproverThreshold: '',
      matrixRules: [],
    },
    customRoles: [],
  },
  businessDebitCard: {
    applyForDebitCard: false,
    registeredName: '',
    registrationNumber: '',
    linkedAccountNumber: '',
    isNewAccount: true,
    cardholders: [],
  },
  giroApplication: {
    applyForGIRO: false,
    registeredName: '',
    registrationNumber: '',
    debitAccountNumber: '',
    billingOrganizations: [],
    signatures: [],
  },
  eAlerts: {
    applyForEAlerts: false,
    linkedAccountNumber: '',
    alertUsers: [],
  },
  agreement: {
    agreeToTerms: false,
    agreeToDataProtection: false,
    agreeToFATCA: false,
    agreeToCRS: false,
    signatureDate: '',
    agreementSignatures: [],
  },
  agreeToTerms: false,
};
